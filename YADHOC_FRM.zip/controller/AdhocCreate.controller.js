var that;
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"YADHOC_FRM/model/formatter"
], function (Controller, MessageBox, MessagePopover, MessagePopoverItem, formatter) {
	"use strict";

	var img_type;
	var copy_case;
	var create_case;
	var compCode;
	var display_case;
	var edit_case;
	var validate_error;
	var e_form_num = "";
	var eform_status = "Data Saved";
	var file_size;
	var index_counter = 0;
	var logger_name = "";
	var button_press;
	var aMockMessages;
	var currencyinp;
	var copy_lob;
	var copy_sublob;
	var copy_on_behalf_of;
	var copy;
	var req_type;
	var manual_approver;
	var i18ntext_bundle;
	var AdhocView;
	//REQ0600512:NSONI3:GWDK902137:09/22/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
	var checkboxSelectedCounter1 = 0;
	var checkboxSelectedCounter2 = 0;
	//REQ0600512:NSONI3:GWDK902137:09/22/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
	return Controller.extend("YADHOC_FRM.controller.AdhocCreate", {
		formatter: formatter,
		visibleFalse: function () {
			this.getView().byId("purpose").setVisible(false);
			this.getView().byId("instruction").setVisible(false);
			this.getView().byId("dateneeded").setVisible(false);
			this.getView().byId("vendorname").setVisible(false);
			this.getView().byId("vendoradd").setVisible(false);
			this.getView().byId("payingentity").setVisible(false);
			this.getView().byId("compcode").setVisible(false);
			this.getView().byId("glaccount").setVisible(false);
			this.getView().byId("wbs").setVisible(false);
			this.getView().byId("lob").setVisible(false);
			this.getView().byId("sublob").setVisible(false);
			this.getView().byId("amount").setVisible(false);
			this.getView().byId("AMOUNT_USD").setVisible(false);
			this.getView().byId("invoice").setVisible(false);
			this.getView().byId("territory").setVisible(false);
			this.getView().byId("approver_Date").setVisible(false);
			this.getView().byId("customer_company").setVisible(false);
			this.getView().byId("request_Desc").setVisible(false);
			this.byId('txtPosition').setProperty('visible', false);
			this.byId('ENTRY_SEQUENCE').setProperty('visible', false);
			this.getView().byId("fr_fin_req_type").setVisible(false);
			this.getView().byId("fr_approve_by_date").setVisible(false);
			this.getView().byId("fr_company").setVisible(false);
			this.getView().byId("fr_lob").setVisible(false);
			this.getView().byId("fr_fiscalmonth").setVisible(false);
			this.getView().byId("fr_fiscalyear").setVisible(false);
			this.getView().byId("fr_doclinks").setVisible(false);
			this.getView().byId("fr_refdocs").setVisible(false);
		},
		approve_eform: function (value) {
			var msg_returned = "";
			var sValue = jQuery.sap.getUriParameters().get("SOURCE");
			if (sValue == "INBOX") {
				var sDialogName = "Dialog13";
				window.eform_num_inbox = e_form_num;
				window.mode_inbox = "A";
				this.mDialogs = this.mDialogs || {};
				var oDialog = this.mDialogs[sDialogName];
				var oSource = value.getSource();
				var oBindingContext = oSource.getBindingContext();
				var sPath = oBindingContext ? oBindingContext.getPath() : null;
				var oView;
				// if (!oDialog) {
				this.getOwnerComponent().runAsOwner(function () {
					oView = sap.ui.xmlview({
						viewName: "YADHOC_FRM.view." + sDialogName
					});
					this.getView().addDependent(oView);
					oView.getController().setRouter(this.oRouter);
					oView.getController().setValueObject(e_form_num);
					oView.getController().setMode("A");
					oDialog = oView.getContent()[0];
					this.mDialogs[sDialogName] = oDialog;
				}.bind(this));
				// }
				return new Promise(function (fnResolve) {
					oDialog.attachEventOnce("afterOpen", null, fnResolve);
					oDialog.open();
					if (oView) {
						oDialog.attachAfterOpen(function () {
							oDialog.rerender();
						});
					} else {
						oView = oDialog.getParent();
					}
					var oModel = this.getView().getModel();
					if (oModel) {
						oView.setModel(oModel);
					}
					if (sPath) {
						var oParams = oView.getController().getBindingParameters();
						oView.bindObject({
							path: sPath,
							parameters: oParams
						});
					}
				}.bind(this)).catch(function (err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			} else {
				var url = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/";
				var oModelData = new sap.ui.model.odata.ODataModel(url, true);
				var eform_num = e_form_num;
				var relPath = "/eFormValidateApprovals?$filter=EFORM_NUM eq '" + eform_num + "' and ACTION eq 'A'";
				var that = this;
				var oSource = value.getSource();
				oModelData.read(relPath, null, [], false, function (oData, response) {
					var msg_type = response.data.results[0].MSG_TYPE;
					if (msg_type == "E") {
						//            MessageBox.error(response.data.results[0].MSG);
						msg_returned = response.data.results[0].MSG + ".";
					} else {
						msg_returned = i18ntext_bundle.getText("theeformhasbeensuccessfullyapproved");
					}
					var doyouwantto = i18ntext_bundle.getText("doyouwanttogotothefiorimyinboxapp");
					var confirm_navigation = i18ntext_bundle.getText("ConfirmNavigation");
					var yes = i18ntext_bundle.getText("Yes");
					var no = i18ntext_bundle.getText("No");
					new Promise(function (fnResolve) {
						sap.m.MessageBox.confirm(msg_returned + doyouwantto, {
							title: confirm_navigation,
							actions: [yes, no],
							onClose: function (sActionClicked) {
								if (sActionClicked === yes) {
									if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
										//S4R:PJAIN6: new URL changes:START
										// window.open("/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html#WorkflowTask-displayInbox", "_self");
										window.open("/sap/bc/ui2/flp#WorkflowTask-displayInbox", "_self");
										//S4R:PJAIN6: new URL changes:END   
									} else {
										//S4R:PJAIN6: new URL changes:START
										// window.open(
										// 	"/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html#Shell-runStandaloneApp?sap-ushell-SAPUI5.Component=cross.fnd.fiori.inbox&sap-ushell-url=/sap/bc/ui5_ui5/sap/ca_fiori_inbox",
										// 	"_self");
										window.open(
											"/sap/bc/ui2/flp#Shell-runStandaloneApp?sap-ushell-SAPUI5.Component=cross.fnd.fiori.inbox&sap-ushell-url=/sap/bc/ui5_ui5/sap/ca_fiori_inbox",
											"_self");
										//S4R:PJAIN6: new URL changes:END	
									}
								}
								if (sActionClicked === no) {
									if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
										window.close();
										window.open("https://sharepoint.spe.sony.com/myspe/", "_self");
									} else {
										window.history.go(-1);
									}
								}
							}
						});
					}).catch(function (err) {
						if (err !== undefined) {
							MessageBox.error(err);
						}
					});
				});
			}
		},
		reject_eform: function (value) {
			var msg_returned = "";
			var sValue = jQuery.sap.getUriParameters().get("SOURCE");
			if (sValue == "INBOX") {
				window.eform_num_inbox = e_form_num;
				window.mode_inbox = "R";
				var sDialogName = "Dialog13";
				this.mDialogs = this.mDialogs || {};
				var oDialog = this.mDialogs[sDialogName];
				var oSource = value.getSource();
				var oBindingContext = oSource.getBindingContext();
				var sPath = oBindingContext ? oBindingContext.getPath() : null;
				var oView;
				// if (!oDialog) {
				this.getOwnerComponent().runAsOwner(function () {
					oView = sap.ui.xmlview({
						viewName: "YADHOC_FRM.view." + sDialogName
					});
					this.getView().addDependent(oView);
					oView.getController().setRouter(this.oRouter);
					oView.getController().setValueObject(e_form_num);
					oView.getController().setMode("R");
					oDialog = oView.getContent()[0];
					this.mDialogs[sDialogName] = oDialog;
				}.bind(this));
				// }
				return new Promise(function (fnResolve) {
					oDialog.attachEventOnce("afterOpen", null, fnResolve);
					oDialog.open();
					if (oView) {
						oDialog.attachAfterOpen(function () {
							oDialog.rerender();
						});
					} else {
						oView = oDialog.getParent();
					}
					var oModel = this.getView().getModel();
					if (oModel) {
						oView.setModel(oModel);
					}
					if (sPath) {
						var oParams = oView.getController().getBindingParameters();
						oView.bindObject({
							path: sPath,
							parameters: oParams
						});
					}
				}.bind(this)).catch(function (err) {
					if (err !== undefined) {
						MessageBox.error(err.message);
					}
				});
			} else {
				var url = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/";
				var oModelData = new sap.ui.model.odata.ODataModel(url, true);
				var eform_num = e_form_num;
				var relPath = "/eFormValidateApprovals?$filter=EFORM_NUM eq '" + eform_num + "' and ACTION eq 'R'";
				var that = this;
				oModelData.read(relPath, null, [], false, function (oData, response) {
					var msg_type = response.data.results[0].MSG_TYPE;
					if (msg_type == "E") {
						//            MessageBox.error(response.data.results[0].MSG);
						msg_returned = response.data.results[0].MSG + ".";
					} else {
						eform_status = "Rejected";
						msg_returned = i18ntext_bundle.getText("theeformhasbeensuccessfullyrejected");
					}
					var doyouwantto = i18ntext_bundle.getText("doyouwanttogotothefiorimyinboxapp");
					var confirm_navigation = i18ntext_bundle.getText("ConfirmNavigation");
					var yes = i18ntext_bundle.getText("Yes");
					var no = i18ntext_bundle.getText("No");
					new Promise(function (fnResolve) {
						sap.m.MessageBox.confirm(msg_returned + doyouwantto, {
							title: confirm_navigation,
							actions: [yes, no],
							onClose: function (sActionClicked) {
								if (sActionClicked === yes) {
									if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
										//S4R:PJAIN6: new URL changes:START
										// window.open("/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html#WorkflowTask-displayInbox", "_self");
										window.open("/sap/bc/ui2/flp#WorkflowTask-displayInbox", "_self");
										//S4R:PJAIN6: new URL changes:END
									} else {
										//S4R:PJAIN6: new URL changes:START
										// window.open(
										// 	"/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html#Shell-runStandaloneApp?sap-ushell-SAPUI5.Component=cross.fnd.fiori.inbox&sap-ushell-url=/sap/bc/ui5_ui5/sap/ca_fiori_inbox",
										// 	"_self");
										window.open(
											"/sap/bc/ui2/flp#Shell-runStandaloneApp?sap-ushell-SAPUI5.Component=cross.fnd.fiori.inbox&sap-ushell-url=/sap/bc/ui5_ui5/sap/ca_fiori_inbox",
											"_self");
										//S4R:PJAIN6: new URL changes:END		
									}
								}
								if (sActionClicked === no) {
									if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
										window.close();
										window.open("https://sharepoint.spe.sony.com/myspe/", "_self");
									} else {
										window.history.go(-1);
									}
								}
							}
						});
					}).catch(function (err) {
						if (err !== undefined) {
							MessageBox.error(err);
						}
					});
				});
			}
		},
		_onNavigateHome: function (value) {
			//S4R:PJAIN6: new URL changes:START
			// window.location.href = "/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html";
			window.location.href = "/sap/bc/ui2/flp";
			//S4R:PJAIN6: new URL changes:END
		},
		onLinkChange: function (oEvent) {
			var s = oEvent.getSource().getValue();
			var prefix1 = 'http://';
			var prefix2 = 'https://';
			var prefix3 = 'HTTP://';
			var prefix4 = 'HTTPS://';
			var prefix5 = 'Http://';
			var prefix6 = 'Https://';
			if ((s.substr(0, prefix1.length) !== prefix1) && (s.substr(0, prefix2.length) !== prefix2) &&
				(s.substr(0, prefix3.length) !== prefix3) && (s.substr(0, prefix4.length) !== prefix4) &&
				(s.substr(0, prefix5.length) !== prefix5) && (s.substr(0, prefix6.length) !== prefix6)) {
				s = prefix1 + s;
			}
			oEvent.getSource().setValue(s);
		},
		onChangeOnBehalfOf: function () {
			var user = this.getView().byId("input_on_behalf_of").getSelectedItem().getAdditionalText();
			if (user) {
				var model = this.getOwnerComponent().getModel("oData");
				var that3 = this;
				model.read("/eFormProductionAccts('" + user + "')", {
					success: function (oData, response) {
						that3.getView().byId("input_business_phone").setValue(oData.PHONE);
						that3.getView().byId("input_emailid").setValue(oData.EMAIL);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		},

		onChangeLOB: function (oEvent) {
			if (oEvent != undefined) {
				this.getView().byId("input_sublob").setValue("");
			}
			var model = this.getOwnerComponent().getModel("oData");
			var that1 = this;
			var lob = this.getView().byId("input_lob").getValue();
			var oFilter = new sap.ui.model.Filter(
				"LOB",
				sap.ui.model.FilterOperator.EQ, lob
			);
			model.read("/eFormLobs", {
				filters: [oFilter],
				success: function (oData, response) {
					var counter = response.data.results.length;
					var i = 0;
					var oModel = that1.getView().getModel();
					var aRows = oModel.getProperty("/SUBLOBS");
					var no_of_items = aRows.length;
					var t = no_of_items - 1;
					for (i = t; i >= 0; i--) {
						aRows.splice(i, 1);
					}
					oModel.setProperty("/SUBLOBS", aRows);
					var aRows = oModel.getProperty("/SUBLOBS");
					for (i = 0; i < counter; i++) {
						var item = {
							SUBLOB: response.data.results[i].SUBLOB,
							SLOB_DESCRIPTION: response.data.results[i].SLOB_DESCRIPTION
						};
						aRows.push(item);
					}
					oModel.setProperty("/SUBLOBS", aRows);
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------Start of Change Description: Set default value for Sublob field
					//************************************************************************************************************
					if ((that1.getView().byId("input_RequestType").getValue() === "SPTN ProCard Payment Request") && lob === "SPT - NETW") {
						//REQ0737819:DPATEL11:FPDK900063:Batch-2:Adhoc lob/sublob changes : START
						//that1.getView().byId("input_sublob").setSelectedKey("CRACKLE, MOVIE CHANNEL & OTHER NETWORKS");
						that1.getView().byId("input_sublob").setValue("CRACKLE, MOVIE CHANNEL & OTHER NETWORKS");
						//REQ0737819:DPATEL11:FPDK900063:Batch-2:Adhoc lob/sublob changes : STOP
					}
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------End of Change Description: Set default value for Sublob field
					//************************************************************************************************************
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		onChangeCombo: function (oEvent) {
			var newval = oEvent.getParameter("newValue");
			var key = oEvent.getSource().getSelectedItem();
			if (newval !== "" && key === null) {
				oEvent.getSource().setValue("");
				oEvent.getSource().setValueState("Error");
			} else {
				oEvent.getSource().setValueState("None");
			}
		},
		onChangeComboBox: function (oEvent) {
			var newval = oEvent.getParameter("newValue");
			var key = oEvent.getSource().getSelectedItem();
			if (newval !== "" && key === null) {
				oEvent.getSource().setValue("");
				oEvent.getSource().setValueState("Error");
			} else {
				oEvent.getSource().setValueState("None");
			}
		},
		navigate_inbox: function () {

			//S4R:PJAIN6: new URL changes:START
			//window.open("/sap/bc/ui5_ui5/ui2/ushell/shells/abap/Fiorilaunchpad.html", "_self");
			window.open("/sap/bc/ui2/flp", "_self");
			//S4R:PJAIN6: new URL changes:END
			window.close();
		},
		hideSummary: function () {
			this.getView().byId("purpose_s").setVisible(false);
			this.getView().byId("instruction_s").setVisible(false);
			this.getView().byId("dateneeded_s").setVisible(false);
			this.getView().byId("vendorname_s").setVisible(false);
			this.getView().byId("vendoradd_s").setVisible(false);
			this.getView().byId("payingentity_s").setVisible(false);
			this.getView().byId("compcode_s").setVisible(false);
			this.getView().byId("glaccount_s").setVisible(false);
			this.getView().byId("wbs_s").setVisible(false);
			this.getView().byId("amount_s").setVisible(false);
			this.getView().byId("amount_s1").setVisible(false);
			this.getView().byId("invoice_s").setVisible(false);
			this.getView().byId("lob_s").setVisible(false);
			this.getView().byId("sublob_s").setVisible(false);
			this.getView().byId("fr_fin_req_type").setVisible(false);
			this.getView().byId("fr_approve_by_date_s").setVisible(false);
			this.getView().byId("fr_company_s").setVisible(false);
			this.getView().byId("fr_lob_s").setVisible(false);
			this.getView().byId("fr_fiscalmonth_s").setVisible(false);
			this.getView().byId("fr_fiscalyear_s").setVisible(false);
			this.getView().byId("fr_doclinks_s").setVisible(false);
			this.getView().byId("fr_refdocs_s").setVisible(false);
		},
		handleIconPress: function () {
			var detailAmtText = this.byId('input_amount').getValue();
			var selectedCmbx = this.byId('CURRENCY').getValue();
		},
		_onLobValueHelpRequest: function () {
			var lob = this.getView().byId("input_lob");
			var choosevalueforcofalob = i18ntext_bundle.getText("ChooseValueforCOFALob");
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: choosevalueforcofalob,
				items: {
					path: "/eFormLobs",
					template: new sap.m.StandardListItem({
						title: "{LOB}",
						description: "{SLOB_DESCRIPTION}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"SLOB_DESCRIPTION",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				liveChange: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"SLOB_DESCRIPTION",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						lob.setValue(oSelectedItem.getTitle());
						lob.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		_onSubLobValueHelpRequest: function () {
			var sublob = this.getView().byId("input_sublob");
			var lob = this.getView().byId("input_lob").getValue();
			var choosevalueforcofasublob = i18ntext_bundle.getText("ChooseValueforCOFASubLob");
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosevalueforcofasublob,
				items: {
					path: "/eFormLobs",
					filters: [new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter({
							path: "LOB",
							operator: sap.ui.model.FilterOperator.EQ,
							value1: lob
						})],
						and: true
					})],
					template: new sap.m.StandardListItem({
						title: "{SUBLOB}",
						description: "{SLOB_DESCRIPTION}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"SLOB_DESCRIPTION",
						sap.ui.model.FilterOperator.EQ, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						sublob.setValue(oSelectedItem.getTitle());
						sublob.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js to
			// this value help
			// dialog
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open(); // Opening value help dialog once
			// data is binded to standard list
			// item
		},
		oMessagePopover: function (oEvent) {
			var msgPopover = sap.ui.getCore().byId('oMsgPopover');
			msgPopover.destroyItems();
			for (var j = 0; j < this.items.length; j++) {
				msgPopover.addItem(new sap.m.MessagePopoverItem({
					title: this.items[j]
				}));
			}
			this.oMessagePopover1.openBy(oEvent.getSource());
		},
		oMessagePopoverOpen: function () {
			var msgPopover = sap.ui.getCore().byId('oMsgPopover');
			msgPopover.destroyItems();
			for (var j = 0; j < that.items.length; j++) {
				msgPopover.addItem(new sap.m.MessagePopoverItem({
					title: that.items[j]
				}));
			}
		},
		onPrintPress: function () {
			var i;
			var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var sText = oBundle.getText("ProcurementApplicationCard", [""]);
			var commtTable = this.getView().byId("t_comment1").getItems();
			var appTable = this.getView().byId("approver_table").getItems();
			var attTable = this.getView().byId("t_attachment1").getItems();
			var dateNeeded = this.byId('DP2').getValue();
			if (dateNeeded.includes('/') === false && dateNeeded !== "") {
				var year = dateNeeded.substring(0, 4);
				var month = dateNeeded.substring(4, 6);
				var date = dateNeeded.substring(6, 8);
				dateNeeded = month + "/" + date + "/" + year;
			}
			var table1 = "";
			var tableApprover = "";
			var attachtable = "";
			if (commtTable.length > 0) {
				table1 =
					"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Comments") + "</th></tr>" +
					"</thead><tr><td style='border:1px solid black;'>" + oBundle.getText("Id") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Comments") +
					"</td><td style='border:1px solid black;'>" +
					oBundle.getText("AddedBy") +
					" </td>" +
					"<td style='border:1px solid black;'>" + oBundle.getText("AddedOn") +
					"</td></tr>";
				for (var i = 0; i < commtTable.length; i++) {
					table1 = table1 + "<tr><td style='border:1px solid black;white-space:pre-wrap; word-wrap:break-word'nowrap >" + commtTable[i].mAggregations
						.cells[0].getText() +
						"</td><td style='border:1px solid black;white-space:pre-wrap; word-wrap:break-word' nowrap>" + commtTable[i].mAggregations.cells[
							1].getValue() +
						"</td><td style='border:1px solid black;white-space:pre-wrap; word-wrap:break-word' nowrap >" +
						commtTable[i].mAggregations.cells[2].getText() + "</td><td style='border:1px solid black;'>" +
						commtTable[i].mAggregations.cells[3].getText() + "</td>" +
						'</tr>';
				}
				table1 = table1 + '</table>';
			}
			if (appTable.length > 0) {
				var tableApprover =
					"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Approvers") + "</th></tr>" +
					"</thead><tr><td style='border:1px solid black;'>" + oBundle.getText("Approved/Rejected") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Approver") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("ReviewerType") + " </td>" +
					"<td style='border:1px solid black;'>" + oBundle.getText("Action By") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Date") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("Time(PST)") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("ManualAddition") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("AddedBy") + " </td>" + "<td style='border:1px solid black;'>" +
					oBundle.getText("AddedOn") + " </td>"
				"</tr>";
				for (var i = 0; i < appTable.length; i++) {
					var isApproved = "";
					var isManual = "";
					if (this.getView().getModel().getProperty("/approvers")[i].approved === "X") {
						isApproved = "Yes";
					} else {
						isApproved = "No";
					}
					if (this.getView().getModel().getProperty("/approvers")[i].approved === "Approved") {
						isApproved = "Yes";
					} else {
						isApproved = "No";
					}
					if (this.getView().getModel().getProperty("/approvers")[i].manual_addition === "X") {
						isManual = "Yes";
					} else {
						isManual = "No";
					}
					tableApprover = tableApprover +
						"<tr><td style='border:1px solid black;'>" + isApproved + "</td><td style='border:1px solid black;'> " + appTable[i].mAggregations
						.cells[1].getText() + "</td><td style='border:1px solid black;'>" +
						appTable[i].mAggregations.cells[2].getText() + "</td><td style='border:1px solid black;'>" +
						appTable[i].mAggregations.cells[3].getText() +
						"</td><td style='border:1px solid black;'>" + appTable[i].mAggregations.cells[4].getText() +
						"</td><td style='border:1px solid black;'>" + appTable[i].mAggregations.cells[5].getText() + " </td>" +
						"<td style='border:1px solid black;'>" + isManual + " </td><td style='border:1px solid black;'>" + appTable[i].mAggregations.cells[
							7].getText() + " </td><td style='border:1px solid black;'>" +
						appTable[i].mAggregations.cells[8].getText() + "</td></tr>";
				}
				tableApprover = tableApprover + "</table>"
			};
			if (attTable.length > 0) {
				attachtable =
					"<table width='100%'><thead align='left'><tr><th>" + oBundle.getText("Attachments") + "</th>" +
					"</tr></thead><tr><td style='border:1px solid black;'>" +
					oBundle.getText("FileName") + "</td><td style='border:1px solid black;'>" +
					oBundle.getText("CreationDate") + "</td><td style='border:1px solid black;'>" +
					oBundle.getText("CreationTime(PST)") +
					" </td>" +
					"<td style='border:1px solid black;'>" + oBundle.getText("FileSize") +
					"</td><td style='border:1px solid black;'>" + oBundle.getText("Creator") +
					"</td></tr>";
				for (var i = 0; i < attTable.length; i++) {
					attachtable = attachtable + "<tr><td style='border:1px solid black;'>" + attTable[i].mAggregations.cells[0].getText() +
						"</td><td style='border:1px solid black;'>" + attTable[i].mAggregations.cells[1].getText() +
						"</td><td style='border:1px solid black;'>" +
						attTable[i].mAggregations.cells[2].getText() + "</td><td style='border:1px solid black;'>" +
						attTable[i].mAggregations.cells[3].getText() + "</td>" + "<td style='border:1px solid black;'>" +
						attTable[i].mAggregations.cells[4].getText() + "</td>" +
						'</tr>';
				}
				attachtable = attachtable + '</table>';
			}
			if (this.getView().getModel().getProperty("/card_type") === "Ariba System Card") {
				var s = "<tr><td style='border:1px solid black;'>" + oBundle.getText("EMDTitle") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/emd_title") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("AribaCardName") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/ariba_card_name") + "</td></tr>";
			} else {
				var s = "";
			}
			var requestType = this.getView().getModel().getProperty("/REQUEST_TYPE");
			if ((requestType === 'Miscellaneous') || (requestType === 'Programming COFA') || (requestType === 'Sign-Off: BRD') || (requestType ===
					'Sign-Off: UAT') || (requestType === 'Sign-Off: Other') || (requestType === 'Sign-Off: FD/Level 7 Approval') || (requestType ===
					'Contract Approval Form') || (requestType === 'Residual Payment Control')) {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Purpose") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PURPOSE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Instruction") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/INSTRUCTIONS") + "</td></tr>"
			} else if ((requestType === 'Finance Request Form')) {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("fr_fin_req_type") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_FIN_REQ_TYPE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("ApproveByDate") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_APPROVE_BY_DATE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Company") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_COMPANY_CODE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("fr_lob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_LOB") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("fr_fiscalmonth") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_FISCAL_P_MONTH") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("fr_fiscalyear") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FISCAL_YEAR") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Purpose") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PURPOSE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Instruction") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/INSTRUCTIONS") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("fr_doclinks") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_DOC_LINK") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("fr_refdocs") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FR_SAP_REF_DOC") + "</td></tr>";
			} else if (requestType === 'Production Accounting Payment Request') {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Purpose") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PURPOSE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Instruction") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/INSTRUCTIONS") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("DateNeeded") + "</td><td style='border:1px solid black;'>" +
					dateNeeded + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("VendorName") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/VENDOR_NAME") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("VendorAddress") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/VENDOR_ADDRESS") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PayingEntity") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PAYING_ENTITY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("GLAccount") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/GENE_LEDGER") + "</td></tr>" + s +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("WBSElement") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/WBS_ELEMENT") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("amount&Currency") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/AMOUNT") + " (" + this.getView().getModel().getProperty("/CURRENCY") + ")" + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("AmountUSD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/AMOUNT_DONATION_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("InvoiceDesc") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/INVOICE_DESC") + "</td></tr>";
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Print functionality for SPTN ProCard Payment Request type
			//************************************************************************************************************
			else if (requestType === 'SPTN ProCard Payment Request') {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Purpose") + "</td><td style='border:1px solid black;'><pre>" +
					this.getView().getModel().getProperty("/PURPOSE") + "</pre></td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Instruction") + "</td><td style='border:1px solid black;'><pre>" +
					this.getView().getModel().getProperty("/INSTRUCTIONS") + "</pre></td></tr>" +

					"<tr><td style='border:1px solid black;'>" + oBundle.getText("CompanyCode") + "</td><td style='border:1px solid black;'>" +
					"" + this.getView().getModel().getProperty("/COMPANY_CODE") + "</td></tr><tr><td style='border:1px solid black;'>" +
					"Charge Date" + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/CHARGED_DATE") + "</td></tr>" +

					"<tr><td style='border:1px solid black;'>" + oBundle.getText("SapVendor") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/VENDOR_NAME") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Lob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/LOB") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("SubLob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/SUBLOB") + "</td></tr>" + s +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("GLAccount") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/GENE_LEDGER") + "</td></tr>";
				if (this.getView().getModel().getProperty("/WBS_ELEMENT") !== "") {
					header1 = header1 + "<tr><td style='border:1px solid black;'>" + oBundle.getText("WBSElement") +
						"</td><td style='border:1px solid black;'>" +
						this.getView().getModel().getProperty("/WBS_ELEMENT") + "</td></tr>";
				}
				if (this.getView().getModel().getProperty("/PCF_COST_CENTER") !== "") {
					header1 = header1 + "<tr><td style='border:1px solid black;'>" + oBundle.getText("FundingDept") +
						"</td><td style='border:1px solid black;'>" +
						this.getView().getModel().getProperty("/PCF_COST_CENTER") + "</td></tr>";

				}
				var oCurrency = new sap.ui.model.type.Currency({
					showMeasure: true
				});

				var amountSTPIN = oCurrency.formatValue([this.getView().getModel().getProperty("/AMOUNT"), this.getView().getModel().getProperty(
					"/CURRENCY")], "string");

				header1 = header1 + "<tr><td style='border:1px solid black;'>" + oBundle.getText("amount&Currency") +
					"</td><td style='border:1px solid black;'>" +
					amountSTPIN + "</td></tr>";
				if (this.getView().getModel().getProperty("/CURRENCY") !== "USD") {
					header1 = header1 + "<tr><td style='border:1px solid black;'>" + oBundle.getText("AmountUSD") +
						"</td><td style='border:1px solid black;'>" +
						this.getView().getModel().getProperty("/AMOUNT_DONATION_USD") + "</td></tr>";
				}
				header1 = header1 + "<tr><td style='border:1px solid black;'>" + oBundle.getText("InvoiceDesc") +
					"</td><td style='border:1px solid black;'><pre>" +
					this.getView().getModel().getProperty("/INVOICE_DESC") + "</pre></td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Business") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/BUSINESS_TXT") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PurchaseType") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PUR_TYPE_TXT") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("FormType") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/FORM_TYPE_TXT") + "</td></tr>";
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of <Change Description:>
			//************************************************************************************************************
			else if (requestType === 'SPHE Media Budget Authorization') {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Purpose") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PURPOSE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Instruction") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/INSTRUCTIONS") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PayingEntity") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PAYING_ENTITY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("amount&Currency") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/AMOUNT") + " (" + this.getView().getModel().getProperty("/CURRENCY") + ")" + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("AmountUSD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/AMOUNT_DONATION_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("InvoiceDesc") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/INVOICE_DESC") + "</td></tr>";
			} else if (requestType === 'OPC Exception') {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("CompanyCode") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/COMPANY_CODE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Lob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/LOB") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("SubLob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/SUBLOB") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Description") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/REQ_DESC") + "</td></tr>";
			} else if (requestType === 'Japan TV Channels') {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("CompanyCode") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/COMPANY_CODE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Lob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/LOB") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("SubLob") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/SUBLOB") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("territory") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/TERRITORY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("approver_date") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/APPROVE_BY_DATE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("customer_Company") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/CUSTOMER_COMPANY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("amount&Currency") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/AMOUNT") + " (" + this.getView().getModel().getProperty("/CURRENCY") + ")" + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("AmountUSD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/AMOUNT_DONATION_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("Description") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/REQ_DESC") + "</td></tr>";
			} else if (requestType === 'Worldwide Facilities-PCF') {
				var header1 =
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_TFADATE") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_TFADATE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_LOB") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_LOB") + "</td></tr>" +

					// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_RECOMMAND") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_RECOMMAND") + "</td></tr>" +
					// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END

					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_STATE") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_STATE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_COUNTRY") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_COUNTRY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_CITY") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_CITY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_POSTAL_CODE") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_POSTAL_CODE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_LOCATION") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_LOCATION") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_AREASM") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_AREASM") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_AREASF") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_AREASF") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_COMPANY_CODE") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_COMPANY_CODE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_PROFIT_CENTER") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_PROFIT_CENTER") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_COST_CENTER") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_COST_CENTER") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_LEASE") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_LEASE") + "</td></tr>" +

					// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_EXIT") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_EXIT") + "</td></tr>" +
					// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END

					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_LOCCURRENCY") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_LOCCURRENCY") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_OCC_COST") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_OCC_COST") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_CAP_COST") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_CAP_COST") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_OT_COST") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_OT_COST") + "</td></tr>" +
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New field added:START
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_REINSTATEMENT_COST") +
					"</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_REINSTATEMENT_COST") + "</td></tr>" +
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New field added:END
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_OTHER_MISC") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_OTHER_MISC") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_GRAND_TOTAL") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_GRAND_TOTAL") + "</td></tr>" +
					//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_EXCHANGE_RATE") + "</td><td style='border:1px solid black;'>" +
					//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END
					this.getView().getModel().getProperty("/PCF_EXCHANGE_RATE") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_OCC_COST_USD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_OCC_COST_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_CAP_COST_USD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_CAP_COST_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_OT_COST_USD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_OT_COST_USD") + "</td></tr>" +
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New field added:START
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_REINSTATEMENT_COST_USD") +
					"</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_REINSTATEMENT_COST_USD") + "</td></tr>" +
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New field added:END
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_OTHER_MISC_USD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_OTHER_MISC_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_GRAND_TOTAL_USD") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_GRAND_TOTAL_USD") + "</td></tr>" +
					"<tr><td style='border:1px solid black;'>" + oBundle.getText("PCF_DESC_JUST") + "</td><td style='border:1px solid black;'>" +
					this.getView().getModel().getProperty("/PCF_DESC_JUST") + "</td></tr>";
			}
			var header =
				"<body><table width='100%' ><tr><th style='border:1px solid black; background-color: #dddddd;'>" + this.getView().byId("page").getText() +
				"</th></tr></table>" +
				"<table width='100%' ><tr><th style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/TITLE") +
				"</td></tr></table><table width='100%' ><tr><td style='border:1px solid black;'>" + oBundle.getText("Description") +
				"</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/DESC") + "</td></tr>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"Preparer") + "</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/PREPARER") + "</td></tr>" + "<tr><td style='border:1px solid black;'>" + oBundle.getText(
					"RequestDate") + "</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/REQUEST_DATE") + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("OnBehalfof") + "</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/ON_BEHALF_OF") + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("E-MailAddress") + "</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/REQUESTER_EMAIL") + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("ReqPhoneNumber") + "</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/REQUESTER_PHONE") + "</td></tr>" +
				"<tr><td style='border:1px solid black;'>" + oBundle.getText("RequestType") + "</td><td style='border:1px solid black;'>" +
				this.getView().getModel().getProperty("/REQUEST_TYPE") + "</td></tr>" +
				header1 +
				"</body>";
			var cltstrng = "width=500px,height=600px";
			var wind = window.open("", cltstrng);
			wind.document.write(header + tableApprover + attachtable + table1);
			// wind.save();
			wind.print();
		},
		handleMessagePopoverPress: function (oEvent) {
			oMessagePopover.toggle(oEvent.getSource());
		},
		handleAmoutFormatterByTotal: function (oEvent) {
			var sAmount, a;
			if (oEvent.getSource().sId === this.getView().byId("input_amount").sId) {
				sAmount = this.getView().getModel().getProperty("/AMOUNT");
				a = sAmount + "";
			} else {
				sAmount = oEvent.getParameter("value");
				a = sAmount.split(',').join('');
			}

			var str1;
			var str2;
			var regx = /[^0-9]/g;
			var res = regx.test(a);
			if (res === false) {
				var totalUsd = new Intl.NumberFormat('en-US').format(a);
				sap.ui.getCore().byId(oEvent.getParameter("id")).setValue(totalUsd);
			} else {
				var result = a.match(regx);
				var substr = a.replace(result, '');
				var totalUsd;
				if (a.indexOf(".") !== -1) {
					var index = a.indexOf(".");
					str1 = a.substr(0, index);
					str2 = a.substr(index);
					var result1 = str1.match(regx);
					if (result1 !== null) {
						str1.replace(result1, '');
					}
					var result2 = str2.match(regx);
					if (result2[0] === "." && result2[1] !== null) {
						str2.replace(result2[1], '');
					}
					totalUsd = new Intl.NumberFormat('en-US').format(str1);
					totalUsd = totalUsd + str2;
				} else {
					totalUsd = new Intl.NumberFormat('en-US').format(substr);
				}
				if (oEvent.getSource().sId !== this.getView().byId("input_amount").sId) {
					sap.ui.getCore().byId(oEvent.getParameter("id")).setValue(totalUsd);
				}
			}
			if (this.getView().byId("input_amount").sId === oEvent.getSource().sId) {
				//  this.getView().getModel().setProperty("/AMOUNT", totalUsd);
				this._onCurrencyChange();
			}
			if (this.getView().byId("PCF_AREASF").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_AREASF", totalUsd);
			}
			if (this.getView().byId("PCF_AREASM").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_AREASM", totalUsd);
			}
			if (this.getView().byId("PCF_OCC_COST").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_OCC_COST", totalUsd);
				currencyinp = "PCF_OCC_COST";
				this._onPCFCurrencyChange();
			}
			if (this.getView().byId("PCF_CAP_COST").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_CAP_COST", totalUsd);
				currencyinp = "PCF_CAP_COST";
				this._onPCFCurrencyChange();
			}
			if (this.getView().byId("PCF_OT_COST").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_OT_COST", totalUsd);
				currencyinp = "PCF_OT_COST";
				this._onPCFCurrencyChange();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
			if (this.getView().byId("PCF_REINSTATEMENT_COST").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_REINSTATEMENT_COST", totalUsd);
				currencyinp = "PCF_REINSTATEMENT_COST";
				this._onPCFCurrencyChange();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END

			if (this.getView().byId("PCF_OTHER_MISC").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_OTHER_MISC", totalUsd);
				currencyinp = "PCF_OTHER_MISC";
				this._onPCFCurrencyChange();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Fields added as Input control:START
			if (this.getView().byId("PCF_OCC_COST_USD").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_OCC_COST_USD", totalUsd);
				currencyinp = "PCF_OCC_COST_USD";
				this._onPCFCurrencyChange();
			}
			if (this.getView().byId("PCF_CAP_COST_USD").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_CAP_COST_USD", totalUsd);
				currencyinp = "PCF_CAP_COST_USD";
				this._onPCFCurrencyChange();
			}
			if (this.getView().byId("PCF_OT_COST_USD").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_OT_COST_USD", totalUsd);
				currencyinp = "PCF_OT_COST_USD";
				this._onPCFCurrencyChange();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
			if (this.getView().byId("PCF_REINSTATEMENT_COST_USD").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_REINSTATEMENT_COST_USD", totalUsd);
				currencyinp = "PCF_REINSTATEMENT_COST_USD";
				this._onPCFCurrencyChange();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END

			if (this.getView().byId("PCF_OTHER_MISC_USD").sId === oEvent.getSource().sId) {
				this.getView().getModel().setProperty("/PCF_OTHER_MISC_USD", totalUsd);
				currencyinp = "PCF_OTHER_MISC_USD";
				this._onPCFCurrencyChange();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Fields added as Input control:END
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Amount validation for more than 60,000 USD
			//************************************************************************************************************
			var cReqType = (this.getView().byId("input_RequestType").getValue() === "SPTN ProCard Payment Request");
			var cLOB = (this.getView().byId("input_lob").getValue() === "SPT - NETW");
			var cSubLOB = (this.getView().byId("input_sublob").getValue() === "CRACKLE, MOVIE CHANNEL & OTHER NETWORKS");
			var cAmount = (Number(a) > 60000);
			var cCurrency = (this.getView().byId("CURRENCY").getValue() === "USD");

			if (cReqType && cLOB && cSubLOB && cAmount && cCurrency) {
				oEvent.getSource().setValueState('Error');
				oEvent.getSource().setValueStateText('Please enter an amount less than $60,000.');
				var error = i18ntext_bundle.getText("Error");
				var messageText = i18ntext_bundle.getText("amountValidation");
				// sap.m.MessageToast.show(messageText, {
				//  title: error,
				//  icon: sap.m.MessageBox.Icon.ERROR
				// });
				return;
			} else {
				oEvent.getSource().setValueState('None');
				oEvent.getSource().setValueStateText('');
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Amount validation for more than 60,000 USD
			//************************************************************************************************************
		},
		_onObjectMatched: function (oEvent) {
			// Displaying handled
			this.flag;
			AdhocView = this;

			//REQ0600512:NSONI3:GWDK902137:09/22/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
			checkboxSelectedCounter1 = 0;
			checkboxSelectedCounter2 = 0;
			//REQ0600512:NSONI3:GWDK902137:09/22/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START

			this.getView().byId("submit_button").setVisible(true);
			this.getView().byId("withdraw_button").setVisible(true);
			// Reset display of Approve & reject buttons
			this.getView().byId("b_approve").setVisible(false);
			this.getView().byId("b_reject").setVisible(false);

			// Reset Attachment Delete button
			this.getView().byId("button_delete_attachment").setVisible(true);
			this.getView().byId("button_attachment_delete_summary").setVisible(true);

			this.getView().byId("buton_update_cmt").setVisible(true);
			this.getView().byId("button_delete_cmt").setVisible(true);

			this.getView().byId("buton_update_cmt_sum").setVisible(true);
			this.getView().byId("button_delete_cmt_sum").setVisible(true);
			// this.getView().byId("i_comment_txt").setEditable(true);
			// this.getView().byId("i_comment_txt_sum").setEditable(true);

			// i18ntext_bundle =
			// this.getView().getModel("i18n").getResourceBundle();
			i18ntext_bundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			var eform_dsp = oEvent.getParameters().arguments.context;
			$.sap.eform_dsp = eform_dsp;
			if (eform_dsp !== undefined) {
				if (eform_dsp.toLowerCase().indexOf("copy") > -1) {
					// Copy scenario
					var array = eform_dsp.split('#');
					eform_dsp = array[0];
					e_form_num = eform_dsp;
					copy_case = "X";
					copy = "X";
				} else {
					// Display scenario
					copy_case = "";
					e_form_num = eform_dsp;
				}
				this.displayfields();
			} else {
				var localData = {
					POP_TITLE: "",
					EFORM_NUM: "",
					TITLE: "",
					DESC: "",
					ON_BEHALF_OF: "",
					PREPARER: "",
					REQUESTER_PHONE: "",
					REQUESTER_EMAIL: "",
					REQUEST_TYPE: "",
					// REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
					ATTACHMENT_CHECKBOXES: false,
					// REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
					PURPOSE: "",
					TERRITORY: "",
					REQ_DESC: "",
					APPROVE_BY_DATE: "",
					CUSTOMER_COMPANY: "",
					INSTRUCTIONS: "",
					LOB: "",
					SUBLOB: "",
					REQUEST_DATE: "",
					DATE_NEEDED: "",
					VENDOR_NAME: "",
					VENDOR_ADDRESS: "",
					PAYING_ENTITY: "",
					COMPANY_CODE: "",
					COMPANY_NAME: "",
					GENE_LEDGER: "",
					WBS_ELEMENT: "",
					AMOUNT: "",
					INVOICE_DESC: "",
					AMOUNT_DONATION: "",
					AMOUNT_DONATION_USD: "",
					CURRENCY: "USD",
					COUNTRY_NAME: "",
					countryName: [{
						name: "Australia"
					}, {
						name: "Phillipines"
					}, {
						name: "Japan"
					}],
					localcurrency: [{
						name: "",
						exch: ""
					}],
					USERS: [{
						USERID: "",
						NAME: ""
					}],
					FR_FISCAL_P_YEAR: [{
						FISCAL_YEAR: "",
					}],
					LOBS: [{
						LOB: "",
						SLOB_DESCRIPTION: ""
					}],
					SUBLOBS: [{
						SUBLOB: "",
						SLOB_DESCRIPTION: ""
					}],
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------Start of Change Description: Setting model for new fields 
					//************************************************************************************************************
					BUSINESSTYPE: [],
					PURCHASETYPE: [],
					FORMTYPE: [],
					BUSINESS: "",
					PUR_TYPE: "",
					FORM_TYPE: "",
					BUSINESS_TXT: "",
					PUR_TYPE_TXT: "",
					FORM_TYPE_TXT: "",
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------End of Change Description: Setting model for new fields
					//************************************************************************************************************
					requestmode: Boolean(1),
					PCFField: Boolean(0),
					//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
					PCFField_img1: Boolean(0),
					PCFField_img2: Boolean(0),
					//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
					PCF_TFADATE: "",
					PCF_LOB: "",
					//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
					PCF_RECOMMAND: "",
					//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END
					PCF_STATE: "",
					PCF_COUNTRY: "",
					PCF_CITY: "",
					PCF_POSTAL_CODE: "",
					PCF_LOCATION: "",
					PCF_AREASM: "",
					PCF_AREASF: "",
					PCF_LEASE: "",
					// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
					PCF_EXIT: "",
					// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END
					PCF_LOCCURRENCY: "",
					PCF_OCC_COST: "",
					PCF_CAP_COST: "",
					PCF_OT_COST: "",
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
					PCF_REINSTATEMENT_COST: "",
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
					PCF_OTHER_MISC: "",
					PCF_GRAND_TOTAL: "",
					//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
					PCF_EXCHANGE_RATE: "",
					//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END
					PCF_OCC_COST_USD: "",
					PCF_CAP_COST_USD: "",
					PCF_OT_COST_USD: "",
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
					PCF_REINSTATEMENT_COST_USD: "",
					//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
					PCF_OTHER_MISC_USD: "",
					PCF_GRAND_TOTAL_USD: "",
					PCF_DESC_JUST: "",
					PCF_COMPANY_CODE: "",
					PCF_PROFIT_CENTER: "",
					PCF_COST_CENTER: "",
					FR_APPROVE_BY_DATE: "",
					FR_COMPANY_CODE: "",
					FR_LOB: "",
					FR_FISCAL_P_MONTH: "",
					FR_DOC_LINK: "",
					FR_SAP_REF_DOC: "",
					FR_FIN_REQ_TYPE: "",
					COUNTRIES: [{
						COUNTRY: "",
						NAME: ""
					}],
					approvers: [{
						approved: "",
						approver: "",
						reviewer_type: "",
						approved_by: "",
						approval_date: "",
						approval_time: "",
						manual_addition: false,
						added_by: "",
						added_on: "",
						can_edit: Boolean(0)
					}],
				};
				this.visibleFalse();
				this.hideSummary();
				localData.approvers.splice(0, 1);
				var oModelTab = new sap.ui.model.json.JSONModel();
				oModelTab.setData(localData);
				oModelTab.setSizeLimit(1000);
				this.getView().setModel(oModelTab);
				this.getView().byId("save_button").setVisible(true);
				this.getView().byId("withdraw_button").setVisible(false);
				this.getView().byId("submit_button").setVisible(true);
				this.getView().byId("print_button").setEnabled(true);
				this.getView().byId("b_delete").setVisible(false);
				this.getView().byId("b_edit").setVisible(false);
				//  AdhocView.approve_reject_button_dsp();
				// this.getView().byId("b_approve").setVisible(false);
				// this.getView().byId("b_reject").setVisible(false);
				//S4R:PJAIN6:Home icon not visible:START
				// this.getView().byId("HOME").setVisible(false);
				//S4R:PJAIN6:Home icon not visible:END
				e_form_num = "";
				// calling initial info method to prefill data
				var model = this.getOwnerComponent().getModel("oData");
				var that = this;
				model.read("/eFormInitialInfos('1')", {
					success: function (oData, response) {
						var name = oData.NAME;
						var adhoc = i18ntext_bundle.getText("adhoc");
						var title = name + '-' + adhoc;
						logger_name = oData.NAME;
						that.getView().byId("input_title").setValue(title);
						that.getView().byId("text_request_date").setText(oData.DATE);
						that.getView().byId("input_on_behalf_of").setValue(name);
						that.getView().byId("text_Preparer").setText(name);
						that.getView().byId("input_emailid").setValue(oData.EMAIL);
						that.getView().byId("input_business_phone").setValue(oData.PHONE);
						//REQ0563167:NSONI3:GWDK902037:03/31/2020:Title update after select on behalf of:START
						that.defaultTitle = that.getView().byId("input_title").getValue();
						//REQ0563167:NSONI3:GWDK902037:03/31/2020:Title update after select on behalf of:END
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				var that1 = this;
				model.read("/eFormCountries", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/COUNTRIES");
						for (i = 0; i < counter; i++) {
							var item = {
								COUNTRY: response.data.results[i].COUNTRY,
								NAME: response.data.results[i].NAME
							};
							aRows.push(item);
						}
						oModel.setProperty("/COUNTRIES", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				var that1 = this;
				model.read("/eFormProductionAccts", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/USERS");
						for (i = 0; i < counter; i++) {
							var item = {
								USERID: response.data.results[i].USERID,
								NAME: response.data.results[i].NAME
							};
							aRows.push(item);
						}
						oModel.setProperty("/USERS", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				var that1 = this;
				model.read("/eFormLobs", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/LOBS");
						for (i = 0; i < counter; i++) {
							var item = {
								LOB: response.data.results[i].LOB,
								SLOB_DESCRIPTION: response.data.results[i].SLOB_DESCRIPTION
							};
							aRows.push(item);
						}
						oModel.setProperty("/LOBS", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				//************************************************************************************************************
				//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
				//-------Start of Change Description: Odata call to get the data for Business/Purchase type/ Form type
				//************************************************************************************************************
				var that1 = this;
				model.read("/eformAdhocBusinesses", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/BUSINESSTYPE");
						for (i = 0; i < counter; i++) {
							var item = {
								BUSINESS: response.data.results[i].BUSINESS,
								BUSINESS_TXT: response.data.results[i].BUSINESS_TXT
							};
							aRows.push(item);
						}
						oModel.setProperty("/BUSINESSTYPE", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});

				var that1 = this;
				model.read("/eformAdhocPurchaseTypeS", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/PURCHASETYPE");
						for (i = 0; i < counter; i++) {
							var item = {
								PUR_TYPE: response.data.results[i].PUR_TYPE,
								PUR_TYPE_TXT: response.data.results[i].PUR_TYPE_TXT
							};
							aRows.push(item);
						}
						oModel.setProperty("/PURCHASETYPE", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});

				var that1 = this;
				model.read("/eformAdhocFormTypeS", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/FORMTYPE");
						for (i = 0; i < counter; i++) {
							var item = {
								FORM_TYPE: response.data.results[i].FORM_TYPE,
								FORM_TYPE_TXT: response.data.results[i].FORM_TYPE_TXT
							};
							aRows.push(item);
						}
						oModel.setProperty("/FORMTYPE", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});

				// hide newly created fields of SPTN ProCard Payment Request
				this.hideSTPNFields(this);
				//************************************************************************************************************
				//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
				//-------End of Change Description: Odata call to get the data for Business/Purchase type/ Form type
				//************************************************************************************************************

				var that1 = this;
				model.read("/eFormFiscalYearS", {
					success: function (oData, response) {
						var counter = response.data.results.length;
						var i = 0;
						var oModel = that1.getView().getModel();
						var aRows = oModel.getProperty("/FR_FISCAL_P_YEAR");
						for (i = 0; i < counter; i++) {
							var item = {
								FISCAL_YEAR: response.data.results[i].FISCAL_PERIOD_YEAR,
							};
							aRows.push(item);
						}
						oModel.setProperty("/FR_FISCAL_P_YEAR", aRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				this.bindingCurrency();
				this.resetFields();
				this.resetAttachments();
				this.resetComments();
				e_form_num = "";
				eform_status = "Data Saved";
				var oResourceModel = this.getView().getModel("i18n").getResourceBundle();
				var oText = oResourceModel.getText("AdhocApprovableForm", [e_form_num]);
				this.getView().byId("page").setText(oText);
			}
		},
		onBusinessPhoneLiveChange: function (oEvent) {
			var value = oEvent.getParameter("value");
			if (value !== "") {
				var regx = /[^0-9-]/g;
				var res = regx.test(value);
				if (res === true) {
					var result = value.match(regx);
					var substr = value.replace(result, '');
					oEvent.getSource().setValue(substr);
				}
			}
		},
		handleAmountFormatting: function (value) {
			if (value && this.flag !== true) {
				var oValue = value.split(',').join('');;
				var totalUsd = new Intl.NumberFormat('en-US').format(oValue);
				return totalUsd;
			} else {
				return value;
			}
		},
		bindingCurrency: function () {
			var model = this.getOwnerComponent().getModel("oData");
			var that = this;
			model.read("/eFormLocCurrencys", {
				success: function (oData, response) {
					var counter = response.data.results.length;
					var i = 0;
					var oModel = that.getView().getModel();
					var aRows = oModel.getProperty("/localcurrency");
					for (i = 0; i < counter; i++) {
						var item = {
							name: response.data.results[i].NAME,
							exch: response.data.results[i].EXCH
						};
						aRows.push(item);
					}
					oModel.setProperty("/localcurrency", aRows);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onPCFCurrencyChange: function () {
			// This code was generated by the layout editor.
			if (currencyinp === "PCF_OCC_COST") {
				var total_Inp = this.getView().byId("PCF_OCC_COST").getValue();
			}
			if (currencyinp === "PCF_CAP_COST") {
				var total_Inp = this.getView().byId("PCF_CAP_COST").getValue();
			}
			if (currencyinp === "PCF_OT_COST") {
				var total_Inp = this.getView().byId("PCF_OT_COST").getValue();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START

			if (currencyinp === "PCF_REINSTATEMENT_COST") {
				var total_Inp = this.getView().byId("PCF_REINSTATEMENT_COST").getValue();
			}
			if (currencyinp === "PCF_REINSTATEMENT_COST_USD") {
				var total_Inp = this.getView().byId("PCF_REINSTATEMENT_COST_USD").getValue();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END

			if (currencyinp === "PCF_OTHER_MISC") {
				var total_Inp = this.getView().byId("PCF_OTHER_MISC").getValue();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Checking Input field:START
			if (currencyinp === "PCF_OCC_COST_USD") {
				var total_Inp = this.getView().byId("PCF_OCC_COST_USD").getValue();
			}
			if (currencyinp === "PCF_CAP_COST_USD") {
				var total_Inp = this.getView().byId("PCF_CAP_COST_USD").getValue();
			}
			if (currencyinp === "PCF_OT_COST_USD") {
				var total_Inp = this.getView().byId("PCF_OT_COST_USD").getValue();
			}
			if (currencyinp === "PCF_OTHER_MISC_USD") {
				var total_Inp = this.getView().byId("PCF_OTHER_MISC_USD").getValue();
			}
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Checking Input field:END
			var loccurrency = this.getView().byId("PCF_LOCCURRENCY").getValue();
			if (total_Inp != undefined) {
				var total_Inp1 = total_Inp.split(',').join('');
			}
			if (currencyinp == "") {
				// case of currency change call all conversions
				var s = {};
				s.EXCH = String(this.getView().byId("PCF_OCC_COST").getValue().split(',').join(''));
				s.NAME = loccurrency;
				var model = this.getOwnerComponent().getModel("oData");
				var that = this;
				model.create("/eFormLocCurrencys", s, { // POST call to OData
					// with reportheader
					// JSON object
					async: false,
					success: function (oData, response) {
						var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:START
						// that.getView().byId("PCF_OCC_COST_USD").setText(temp);
						that.getView().byId("PCF_OCC_COST_USD").setValue(temp);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:END
						var t = 0;
						t = Number(that.getView().byId("PCF_OCC_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_CAP_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OT_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_REINSTATEMENT_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));
						that.getView().byId("PCF_GRAND_TOTAL").setText(new Intl.NumberFormat('en-US').format(t));
						that.getView().byId("PCF_GRAND_TOTAL_USD").setText(new Intl.NumberFormat('en-US').format(t));
						// Call again same odata create to get updated total
						// grand USD
						var that9 = that;
						var p = {};
						p.EXCH = String(that9.getView().byId("PCF_GRAND_TOTAL").getText().split(',').join(''));
						p.NAME = that.getView().byId("PCF_LOCCURRENCY").getValue();
						var model = that9.getOwnerComponent().getModel("oData");
						model.create("/eFormLocCurrencys", p, { // POST call to
							// OData with
							// reportheader
							// JSON object
							async: false,
							success: function (oData, response) {
								var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
								that9.getView().byId("PCF_GRAND_TOTAL_USD").setText(temp);
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				var s = {};
				s.EXCH = String(this.getView().byId("PCF_CAP_COST").getValue().split(',').join(''));
				s.NAME = loccurrency;
				var model = this.getOwnerComponent().getModel("oData");
				var that = this;
				model.create("/eFormLocCurrencys", s, { // POST call to OData
					// with reportheader
					// JSON object
					async: false,
					success: function (oData, response) {
						var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:START
						// that.getView().byId("PCF_CAP_COST_USD").setText(temp);
						that.getView().byId("PCF_CAP_COST_USD").setValue(temp);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:END
						var t = 0;
						t = Number(that.getView().byId("PCF_OCC_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_CAP_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OT_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));
						that.getView().byId("PCF_GRAND_TOTAL").setText(new Intl.NumberFormat('en-US').format(t));
						that.getView().byId("PCF_GRAND_TOTAL_USD").setText(new Intl.NumberFormat('en-US').format(t));
						// Call again same odata create to get updated total
						// grand USD
						var that9 = that;
						var p = {};
						p.EXCH = String(that9.getView().byId("PCF_GRAND_TOTAL").getText().split(',').join(''));
						p.NAME = that.getView().byId("PCF_LOCCURRENCY").getValue();
						var model = that9.getOwnerComponent().getModel("oData");
						model.create("/eFormLocCurrencys", p, { // POST call to
							// OData with
							// reportheader
							// JSON object
							async: false,
							success: function (oData, response) {
								var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
								that9.getView().byId("PCF_GRAND_TOTAL_USD").setText(temp);
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				var s = {};
				s.EXCH = String(this.getView().byId("PCF_OT_COST").getValue().split(',').join(''));
				s.NAME = loccurrency;
				var model = this.getOwnerComponent().getModel("oData");
				var that = this;
				model.create("/eFormLocCurrencys", s, { // POST call to OData
					// with reportheader
					// JSON object
					async: false,
					success: function (oData, response) {
						var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:START
						// that.getView().byId("PCF_OT_COST_USD").setText(temp);
						that.getView().byId("PCF_OT_COST_USD").setValue(temp);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:END
						var t = 0;
						t = Number(that.getView().byId("PCF_OCC_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_CAP_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OT_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));
						that.getView().byId("PCF_GRAND_TOTAL").setText(new Intl.NumberFormat('en-US').format(t));
						that.getView().byId("PCF_GRAND_TOTAL_USD").setText(new Intl.NumberFormat('en-US').format(t));
						// Call again same odata create to get updated total
						// grand USD
						var that9 = that;
						var p = {};
						p.EXCH = String(that9.getView().byId("PCF_GRAND_TOTAL").getText().split(',').join(''));
						p.NAME = that.getView().byId("PCF_LOCCURRENCY").getValue();
						var model = that9.getOwnerComponent().getModel("oData");
						model.create("/eFormLocCurrencys", p, { // POST call to
							// OData with
							// reportheader
							// JSON object
							async: false,
							success: function (oData, response) {
								var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
								that9.getView().byId("PCF_GRAND_TOTAL_USD").setText(temp);
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
				var s = {};
				s.EXCH = String(this.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));
				s.NAME = loccurrency;
				var model = this.getOwnerComponent().getModel("oData");
				var that = this;
				model.create("/eFormLocCurrencys", s, { // POST call to OData
					// with reportheader
					// JSON object
					async: false,
					success: function (oData, response) {
						var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:START
						// that.getView().byId("PCF_OTHER_MISC_USD").setText(temp);
						that.getView().byId("PCF_OTHER_MISC_USD").setValue(temp);
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from text to input:END
						var t = 0;
						t = Number(that.getView().byId("PCF_OCC_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_CAP_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OT_COST").getValue().split(',').join('')) +
							Number(that.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));
						that.getView().byId("PCF_GRAND_TOTAL").setText(new Intl.NumberFormat('en-US').format(t));
						that.getView().byId("PCF_GRAND_TOTAL_USD").setText(new Intl.NumberFormat('en-US').format(t));
						// Call again same odata create to get updated total
						// grand USD
						var that9 = that;
						var p = {};
						p.EXCH = String(that9.getView().byId("PCF_GRAND_TOTAL").getText().split(',').join(''));
						p.NAME = that.getView().byId("PCF_LOCCURRENCY").getValue();
						var model = that9.getOwnerComponent().getModel("oData");
						model.create("/eFormLocCurrencys", p, { // POST call to
							// OData with
							// reportheader
							// JSON object
							async: false,
							success: function (oData, response) {
								var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
								that9.getView().byId("PCF_GRAND_TOTAL_USD").setText(temp);
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
			} else {
				if (total_Inp1 == undefined) {
					return;
				}
				//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Commented As logic no longer required:START
				// var s = {};
				// s.EXCH = String(total_Inp1);
				// s.NAME = loccurrency;
				// var model = this.getOwnerComponent().getModel("oData");
				// var that = this;
				// model.create("/eFormLocCurrencys", s, { // POST call to OData with
				// 	// reportheader JSON object
				// 	async: false,
				// 	success: function (oData, response) {
				// 		var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
				// 		if (currencyinp === "PCF_OCC_COST") {
				// 			
				// 			//that.getView().byId("PCF_OCC_COST_USD").setText(temp);
				// 			that.getView().byId("PCF_OCC_COST_USD").setValue(temp);
				// 			
				// 		}
				// 		if (currencyinp === "PCF_CAP_COST") {
				// 			
				// 			// that.getView().byId("PCF_CAP_COST_USD").setText(temp);
				// 			that.getView().byId("PCF_CAP_COST_USD").setValue(temp);
				// 			
				// 		}
				// 		if (currencyinp === "PCF_OT_COST") {
				// 			
				// 			// that.getView().byId("PCF_OT_COST_USD").setText(temp);
				// 			that.getView().byId("PCF_OT_COST_USD").setValue(temp);
				// 			
				// 		}
				// 		if (currencyinp === "PCF_OTHER_MISC") {
				// 			
				// 			// that.getView().byId("PCF_OTHER_MISC_USD").setText(temp);
				// 			that.getView().byId("PCF_OTHER_MISC_USD").setValue(temp);
				// 			
				// 		}
				// 		currencyinp = "";
				// Updating Grand total

				// var that = this;
				// var t = 0;
				// var u = 0;
				// 	
				// t = Number(that.getView().byId("PCF_OCC_COST_USD").getValue().split(',').join('')) +
				// 	Number(that.getView().byId("PCF_CAP_COST_USD").getValue().split(',').join('')) +
				// 	Number(that.getView().byId("PCF_OT_COST_USD").getValue().split(',').join('')) +
				// 	Number(that.getView().byId("PCF_OTHER_MISC_USD").getValue().split(',').join(''));
				// that.getView().byId("PCF_GRAND_TOTAL_USD").setText(new Intl.NumberFormat('en-US').format(t));
				// //adhoc changes end

				// 	u = Number(that.getView().byId("PCF_OCC_COST").getValue().split(',').join('')) +
				// 	Number(that.getView().byId("PCF_CAP_COST").getValue().split(',').join('')) +
				// 	Number(that.getView().byId("PCF_OT_COST").getValue().split(',').join('')) +
				// 	Number(that.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));

				// that.getView().byId("PCF_GRAND_TOTAL").setText(new Intl.NumberFormat('en-US').format(u));
				// Call again same odata create to get updated total grand USD
				// 	var that9 = that;
				// 	var p = {};
				// 	p.EXCH = String(that9.getView().byId("PCF_GRAND_TOTAL").getText().split(',').join(''));
				// 	p.NAME = that.getView().byId("PCF_LOCCURRENCY").getValue();
				// 	var model = that9.getOwnerComponent().getModel("oData");
				// 	model.create("/eFormLocCurrencys", p, { // POST call to OData
				// 		// with reportheader
				// 		// JSON object
				// 		async: false,
				// 		success: function (oData, response) {
				// 			var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
				// 			that9.getView().byId("PCF_GRAND_TOTAL_USD").setText(temp);
				// 		},
				// 		error: function (oError) {
				// 			var response = JSON.parse(oError.responseText);
				// 			MessageBox.show(
				// 				response.error.message.value,
				// 				MessageBox.Icon.ERROR,
				// 				"Error"
				// 			);
				// 			sap.ui.core.BusyIndicator.hide();
				// 		}
				// 	});
				// },
				// error: function (oError) {
				// 	var response = JSON.parse(oError.responseText);
				// 	MessageBox.show(
				// 		response.error.message.value,
				// 		MessageBox.Icon.ERROR,
				// 		"Error"
				// 	);
				// 	sap.ui.core.BusyIndicator.hide();
				// }
				//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Commented As logic no longer required:END	
				//REQ0589824:PJAIN6:GWDK902102:08/04/2020:For Grand total:START	
				var that = this;
				var t = 0;
				var u = 0;

				t = Number(that.getView().byId("PCF_OCC_COST_USD").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_CAP_COST_USD").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_OT_COST_USD").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_REINSTATEMENT_COST_USD").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_OTHER_MISC_USD").getValue().split(',').join(''));
				that.getView().byId("PCF_GRAND_TOTAL_USD").setText(new Intl.NumberFormat('en-US').format(t));

				u = Number(that.getView().byId("PCF_OCC_COST").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_CAP_COST").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_OT_COST").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_REINSTATEMENT_COST").getValue().split(',').join('')) +
					Number(that.getView().byId("PCF_OTHER_MISC").getValue().split(',').join(''));

				that.getView().byId("PCF_GRAND_TOTAL").setText(new Intl.NumberFormat('en-US').format(u));
				//REQ0589824:PJAIN6:GWDK902102:08/04/2020:For Grand total:END
			}
		},
		_onCurrencyChange: function () {
			// This code was generated by the layout editor.
			var total_Inp = this.getView().byId("input_amount").getValue();
			var loccurrency = this.getView().byId("CURRENCY").getValue();
			if (loccurrency === 'USD') {
				this.getView().byId("AMOUNT_USD").setVisible(false);
				this.getView().byId("amount_s1").setVisible(false);
			} else {
				this.getView().byId("AMOUNT_USD").setVisible(true);
				this.getView().byId("amount_s1").setVisible(true);
			}
			var total_Inp1 = total_Inp.split(',').join('');
			var s = {};
			s.EXCH = String(total_Inp1);
			s.NAME = loccurrency;
			var model = this.getOwnerComponent().getModel("oData");
			var that = this;
			model.create("/eFormLocCurrencys", s, { // POST call to OData with
				// reportheader JSON object
				async: false,
				success: function (oData, response) {
					var temp = new Intl.NumberFormat('en-US').format(oData.EXCH);
					that.getView().byId("AMOUNT_DONATION_USD").setText(temp);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		showData: function () {
			// create scenerio begins here
			// creating local json model
			var localData = {
				EFORM_NUM: "",
				TITLE: "",
				DESC: "",
				ON_BEHALF_OF: "",
				REQUESTER_PHONE: "",
				REQUESTER_EMAIL: "",
				REQUEST_TYPE: "",
				// REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
				ATTACHMENT_CHECKBOXES: false,
				ATTACH: "",
				// REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
				PURPOSE: "",
				TERRITORY: "",
				APPROVE_BY_DATE: "",
				CUSTOMER_COMPANY: "",
				INSTRUCTIONS: "",
				REQUEST_DATE: "",
				DATE_NEEDED: "",
				VENDOR_NAME: "",
				VENDOR_ADDRESS: "",
				PAYING_ENTITY: "",
				COMPANY_CODE: "",
				COMPANY_NAME: "",
				GENE_LEDGER: "",
				WBS_ELEMENT: "",
				AMOUNT: "",
				INVOICE_DESC: "",
				AMOUNT_DONATION: "",
				AMOUNT_DONATION_USD: "",
				CURRENCY: "USD",
				localcurrency: [{
					name: "",
					exch: ""
				}],
				USERS: [{
					USERID: "",
					NAME: ""
				}],
				LOBS: [{
					LOB: "",
					SLOB_DESCRIPTION: ""
				}],
				SUBLOBS: [{
					SUBLOB: "",
					SLOB_DESCRIPTION: ""
				}],
				requestmode: Boolean(1),
				PCFField: Boolean(0),
				//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
				PCFField_img1: Boolean(0),
				PCFField_img2: Boolean(0),
				//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
				PCF_TFADATE: "",
				PCF_LOB: "",
				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
				PCF_RECOMMAND: "",
				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END
				PCF_STATE: "",
				PCF_COUNTRY: "",
				PCF_CITY: "",
				PCF_POSTAL_CODE: "",
				PCF_LOCATION: "",
				PCF_AREASM: "",
				PCF_AREASF: "",
				PCF_LEASE: "",
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
				PCF_EXIT: "",
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END
				PCF_LOCCURRENCY: "",
				PCF_OCC_COST: "",
				PCF_CAP_COST: "",
				PCF_OT_COST: "",
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
				PCF_REINSTATEMENT_COST: "",
				PCF_REINSTATEMENT_COST_USD: "",
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
				PCF_OTHER_MISC: "",
				PCF_GRAND_TOTAL: "",
				//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
				PCF_EXCHANGE_RATE: "",
				//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END
				PCF_OCC_COST_USD: "",
				PCF_CAP_COST_USD: "",
				PCF_OT_COST_USD: "",
				PCF_OTHER_MISC_USD: "",
				PCF_GRAND_TOTAL_USD: "",
				PCF_DESC_JUST: "",
				PCF_COMPANY_CODE: "",
				PCF_PROFIT_CENTER: "",
				PCF_COST_CENTER: "",
				COUNTRIES: [{
					COUNTRY: "",
					NAME: ""
				}],
				approvers: [{
					approved: "",
					approver: "",
					reviewer_type: "",
					approved_by: "",
					approval_date: "",
					approval_time: "",
					manual_addition: false,
					added_by: "",
					added_on: "",
					can_edit: Boolean(0)
				}],
			};
			var model = this.getOwnerComponent().getModel("oData");
			var that = this;
			model.read("/eFormLocCurrencys", {
				success: function (oData, response) {
					var counter = response.data.results.length;
					var i = 0;
					var oModel = that.getView().getModel();
					var aRows = oModel.getProperty("/localcurrency");
					for (i = 0; i < counter; i++) {
						var item = {
							name: response.data.results[i].NAME,
							exch: response.data.results[i].EXCH
						};
						aRows.push(item);
					}
					oModel.setProperty("/localcurrency", aRows);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
					// var model = that1.getOwnerComponent().getModel("oData");
					// var that1 = this;
					model.read("/eFormProductionAccts", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that.getView().getModel();
							var aRows = oModel.getProperty("/USERS");
							for (i = 0; i < counter; i++) {
								var item = {
									USERID: response.data.results[i].USERID,
									NAME: response.data.results[i].NAME
								};
								aRows.push(item);
							}
							oModel.setProperty("/USERS", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					model.read("/eFormCountries", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that.getView().getModel();
							var aRows = oModel.getProperty("/COUNTRIES");
							for (i = 0; i < counter; i++) {
								var item = {
									COUNTRY: response.data.results[i].COUNTRY,
									NAME: response.data.results[i].NAME
								};
								aRows.push(item);
							}
							oModel.setProperty("/COUNTRIES", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					// var model = that1.getOwnerComponent().getModel("oData");
					// var that1 = this;
					model.read("/eFormLobs", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that.getView().getModel();
							var aRows = oModel.getProperty("/LOBS");
							for (i = 0; i < counter; i++) {
								var item = {
									LOB: response.data.results[i].LOB,
									SLOB_DESCRIPTION: response.data.results[i].SLOB_DESCRIPTION
								};
								aRows.push(item);
							}
							oModel.setProperty("/LOBS", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
				}
			});
			var oModelTab = new sap.ui.model.json.JSONModel();
			oModelTab.setData(localData);
			oModelTab.setSizeLimit(1000);
			this.getView().setModel(oModelTab);
			this.getView().byId("save_button").setVisible(true);
			this.getView().byId("withdraw_button").setVisible(false);
			this.getView().byId("submit_button").setVisible(true);
			//AdhocView.approve_reject_button_dsp();
			this.getView().byId("print_button").setEnabled(true);
			this.getView().byId("b_delete").setVisible(false);
			this.getView().byId("b_edit").setVisible(false);
			//S4R:PJAIN6:Home icon not visible:START
			// this.getView().byId("HOME").setVisible(false);
			//S4R:PJAIN6:Home icon not visible:END
			e_form_num = "";
			// calling initial info method to prefill data
			var model = this.getOwnerComponent().getModel("oData");
			var that = this;
			model.read("/eFormInitialInfos('1')", {
				success: function (oData, response) {
					var name = oData.NAME;
					var adhoc = i18ntext_bundle.getText("adhoc");
					var title = name + '-' + adhoc;
					logger_name = oData.NAME;
					that.getView().byId("input_title").setValue(title);
					that.getView().byId("text_request_date").setText(oData.DATE);
					that.getView().byId("input_on_behalf_of").setValue(name);
					that.getView().byId("text_Preparer").setText(name);
					that.getView().byId("input_emailid").setValue(oData.EMAIL);
					that.getView().byId("input_business_phone").setValue(oData.PHONE);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
			this.resetFields();
			this.resetAttachments();
			this.resetComments();
			e_form_num = "";
			eform_status = "Data Saved";
			var oResourceModel = this.getView().getModel("i18n").getResourceBundle();
			var oText = oResourceModel.getText("AdhocApprovableForm", [e_form_num]);
			this.getView().byId("page").setText(oText);
			if (this.getView().byId("CURRENCY").getValue() == 'USD') {
				this.getView().byId("AMOUNT_USD").setVisible(false);
			} else {
				this.getView().byId("AMOUNT_USD").setVisible(true);
			}
		},
		onBeforeRendering: function () {
			if (this.oMessagePopover1 === undefined) {
				this.oMessagePopover1 = sap.ui.xmlfragment("YADHOC_FRM.view.MessagePopover", this);
				this.getView().addDependent(this.oMessagePopover1);
			}
		},
		onInit: function () {
			that = this;
			//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING PASTE FUNCTION FOR IMAGE:START
			window.addEventListener("paste", function (e) {
				return new Promise(function (resolve, reject) {
					if (e.clipboardData && e.clipboardData.items) {
						var aItems = e.clipboardData.items;
						var bImageFound = false;
						for (var i = 0; i < aItems.length; i++) {
							// Skip content if not image
							if (aItems[i].type.indexOf("image") == -1) {
								continue;
							}
							bImageFound = true;
							// Retrieve image on clipboard as blob
							var oBlob = aItems[i].getAsFile();
							img_type = aItems[i].getAsFile().type;
							var name = oBlob.name;

							var oReader = new FileReader();
							oReader.readAsDataURL(oBlob);
							oReader.onloadend = function () {
								var sBase64data = oReader.result;
								resolve(sBase64data);
							};
						}
						if (!bImageFound) {
							reject("noImageInClipboard");
						}
					} else {
						reject("noItemFound");
					}
				}).then(function (sBase64) {
					that.getView().byId("F_PCF_FIN_ANALYSIS").setVisible(false);

					that.getView().byId("F_PCF_FIN_ANALYSIS1").setVisible(true);

					that.getView().byId("ss").setSrc(sBase64);
					that.getView().byId("ss1").setSrc(sBase64);
				}, false);
			});
			//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING PASTE FUNCTION FOR IMAGE:END
			this.btnIncrementAfter = 0;
			var oModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oModel, "viewData");
			this.getView().getModel("viewData").setProperty("/Footval", []);
			sap.m.DatePicker.prototype.onAfterRendering = function (e) {
				$('#' + e.srcControl.getId() + "-inner").prop('readonly', true);
			};
			this.mBindingOptions = {};
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);
		},
		//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FOR IMAGE:START
		_onhandleValueChangeImage: function () {
			var oFileUploader = this.getView().byId("i_fileUploader");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			img_type = domRef.files[0].type;
			var that = this;
			this.fileName = file.name;
			var oReader = new FileReader();
			oReader.readAsDataURL(file);
			oReader.onloadend = function () {
				var sBase64data = oReader.result;
				that.getView().byId("F_PCF_FIN_ANALYSIS").setVisible(false);
				that.getView().byId("F_PCF_FIN_ANALYSIS1").setVisible(true);

				that.getView().byId("ss").setSrc(sBase64data);
				that.getView().byId("ss1").setSrc(sBase64data);
			};
		},
		onReset: function () {
			img_type = "";
			this.getView().byId("ss").setSrc("");
			//this.getView().byId("ss1").setSrc("");
			this.getView().byId("F_PCF_FIN_ANALYSIS1").setVisible(false);
			this.getView().byId("F_PCF_FIN_ANALYSIS").setVisible(true);

		},
		//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FOR IMAGE:END
		copyfields: function () {},
		_onEditPress: function (oEvent) {
			var model = this.getOwnerComponent().getModel("oData");
			var that = this;
			model.read("/eFormInitialInfos('" + e_form_num + "')", {
				success: function (oData, response) {
					if (response.data.STATUS == "Not Authorised") {
						// edit is allowed
						var youcannotedit = i18ntext_bundle.getText("YoucannoteditthiseForm");
						MessageBox.alert(youcannotedit);
						return;
					}
					if (response.data.STATUS == "Data Saved" || response.data.STATUS == "Rejected" || response.data.STATUS == "Withdrawn") {
						// edit is allowed
						var oModel = that.getView().getModel();
						var editmode = oModel.getProperty("/requestmode");
						editmode = Boolean(1);
						oModel.setProperty("/requestmode", editmode);
						var youcanedit = i18ntext_bundle.getText("YoucaneditthiseForm");
						MessageBox.alert(youcanedit);
						that.getView().byId("b_save").setVisible(true);
						that.getView().byId("b_submit").setEnabled(true);
						that.getView().byId("b_withdraw").setVisible(false);
						that.getView().byId("b_print").setEnabled(true);
					}
					if (response.data.STATUS == "Rejected") {
						// edit is allowed
						var oModel = that.getView().getModel();
						var editmode = oModel.getProperty("/requestmode");
						editmode = Boolean(1);
						oModel.setProperty("/requestmode", editmode);
						var youcanedit = i18ntext_bundle.getText("YoucaneditthiseForm");
						MessageBox.alert(youcanedit);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						that.getView().byId("b_save").setVisible(true);
						that.getView().byId("b_submit").setEnabled(false);
						that.getView().byId("b_withdraw").setVisible(true);
						that.getView().byId("b_print").setEnabled(true);
						that.getView().byId("approve").setVisible(true);
						that.getView().byId("reject").setEnabled(false);
					}
					if (response.data.STATUS == "In Approval") {
						that._onWithdrawPress();
					}
					if (response.data.STATUS == "Approved") {
						var youcannotedit = i18ntext_bundle.getText("YoucannoteditthiseForm");
						MessageBox.alert(youcannotedit);
						return;
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		fillComments: function (that) {
			var relPath = "/eFormComments";
			var model = that.getOwnerComponent().getModel("oData");
			var that1 = that;
			var oFilter = new sap.ui.model.Filter(
				"FORM_NO",
				sap.ui.model.FilterOperator.EQ, e_form_num
			);
			model.read(relPath, {
				filters: [oFilter],
				success: function (oData, response) {
					that1.getView().byId("t_comment1").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table = that1.getView().byId("t_comment1");
						var vedit = oData.results[i].EDIT;
						if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
							vedit = Boolean(0);
						}
						var data = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									text: oData.results[i].SEQUENCE
								}),
								new sap.m.TextArea({
									value: oData.results[i].COMMENTS,
									rows: 2,
									cols: 70,
									enabled: vedit
								}),
								new sap.m.Text({
									text: oData.results[i].CREATOR
								}),
								new sap.m.Text({
									text: oData.results[i].CR_DATE
								})
							]
						});
						table.addItem(data);
					} // for
					that1.getView().byId("t_comment2").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table = that1.getView().byId("t_comment2");
						var vedit = oData.results[i].EDIT;
						if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
							vedit = Boolean(0);
						}
						var data = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Text({
									text: oData.results[i].SEQUENCE
								}),
								new sap.m.TextArea({
									value: oData.results[i].COMMENTS,
									rows: 2,
									cols: 70,
									enabled: vedit
								}),
								new sap.m.Text({
									text: oData.results[i].CREATOR
								}),
								new sap.m.Text({
									text: oData.results[i].CR_DATE
								})
							]
						});
						table.addItem(data);
					} // for
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		fillAttachments: function (that_1) {
			var model = that_1.getOwnerComponent().getModel("oData");
			var relPath = "/eFormAttachments";
			var that = that_1;
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, e_form_num
			);
			model.read(relPath, {
				filters: [oFilter],
				success: function (oData, response) {
					that.getView().byId("t_attachment1").destroyItems();
					that.getView().byId("t_attachment2").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table1 = that.getView().byId("t_attachment1");
						var table2 = that.getView().byId("t_attachment2");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									wrapping: Boolean(1),
									press: function (oEvent) {
										var that2 = that;
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/eFormAttachments(EFORM_NUM='" + e_form_num + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATED_BY
								}),
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
								new sap.m.CheckBox({
									visible: that.getView().getModel().getProperty("/ATTACHMENT_CHECKBOXES"),
									selected: function () {
										if (response.data.results[i].ATTACH === 'X') {
											checkboxSelectedCounter1++;
										}
										return response.data.results[i].ATTACH;
									}.call() === '' ? false : true,
									select: function (oEvent) {
										var oSource = oEvent.getSource();
										var isSelectedOrNot = this.getSelected();
										if (isSelectedOrNot === true) {
											if (checkboxSelectedCounter1 > 0) {
												MessageBox.alert("Please choose only one attachment.");
												this.setSelected(false);
												return;
											} else {
												checkboxSelectedCounter1++;
											}
										}
										if (isSelectedOrNot == false) {
											checkboxSelectedCounter1--;
										}
										var attach_value = isSelectedOrNot === false ? "" : "X";
										var c = {};
										var file_Name = response.data.results[oSource.data("rowID")].FILE_NAME;
										// 										c.EFORM_NUM = e_form_num;
										c.FILE_NAME = file_Name;
										c.ATTACH = attach_value; //eFormAttachments
										model.update("/eFormAttachments(EFORM_NUM='" + e_form_num + "',FILE_NAME='" + file_Name + "')", c, null, {
											async: false,
											success: function (oData, response) {
												console.log("Success to create call in eFormAttachments entity set");
											},
											error: function (oError) {
												var response = JSON.parse(oError.responseText);
												MessageBox.show(
													response.error.message.value,
													MessageBox.Icon.ERROR,
													"Error"
												);
												sap.ui.core.BusyIndicator.hide();
											}
										});
									}
								}).data("rowID", i)
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
							]
						});
						var data2 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									wrapping: Boolean(1),
									press: function (oEvent) {
										var that2 = that;
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/eFormAttachments(EFORM_NUM='" + e_form_num + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATED_BY
								}),
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
								new sap.m.CheckBox({
									visible: that.getView().getModel().getProperty("/ATTACHMENT_CHECKBOXES"),
									selected: function () {
										if (response.data.results[i].ATTACH === 'X') {
											checkboxSelectedCounter2++;
										}
										return response.data.results[i].ATTACH;
									}.call() === '' ? false : true,
									select: function (oEvent) {
										var oSource = oEvent.getSource();
										var isSelectedOrNot = this.getSelected();
										if (isSelectedOrNot === true) {
											if (checkboxSelectedCounter2 > 0) {
												MessageBox.alert("Please choose only one attachment.");
												this.setSelected(false);
												return;
											} else {
												checkboxSelectedCounter2++;
											}
										}
										if (isSelectedOrNot == false) {
											checkboxSelectedCounter2--;
										}
										var attach_value = isSelectedOrNot === false ? "" : "X";
										var c = {};
										var file_Name = response.data.results[oSource.data("rowID")].FILE_NAME;
										// 										c.EFORM_NUM = e_form_num;
										c.FILE_NAME = file_Name;
										c.ATTACH = attach_value; //eFormAttachments
										model.update("/eFormAttachments(EFORM_NUM='" + e_form_num + "',FILE_NAME='" + file_Name + "')", c, null, {
											async: false,
											success: function (oData, response) {
												console.log("Success to create call in eFormAttachments entity set");
											},
											error: function (oError) {
												var response = JSON.parse(oError.responseText);
												MessageBox.show(
													response.error.message.value,
													MessageBox.Icon.ERROR,
													"Error"
												);
												sap.ui.core.BusyIndicator.hide();
											}
										});
									}
								}).data("rowID", i)
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
							]
						});
						table1.addItem(data1);
						table2.addItem(data2);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		approve_reject_button_dsp: function () {
			// Check and display Approve and Reject buttons if applicable
			var url = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/";
			var oModelData = new sap.ui.model.odata.ODataModel(url, true);
			var eform_num = e_form_num;
			var relPath = "/eFormDetermineApproverLogins?$filter=EFORM_NUM eq '" + eform_num + "'";
			var that = AdhocView;
			that.modelData = oModelData;
			that.eformnum = eform_num;
			oModelData.read(relPath, null, [], false, function (oData, response) {
				var msg_type = response.data.results[0].MSG_TYPE;
				if (msg_type == "S") {
					that.getView().byId("b_approve").setVisible(true);
					that.getView().byId("b_reject").setVisible(true);
					if (response.data.results[1]) {
						if (response.data.results[1].MSG_TYPE !== "C") {
							//  that.modelData.read("/eFormInitialInfos('" + that.eformnum + "')", null, [], false, function(oData1, response1) {
							//if ( response1.data.STATUS === "Rejected" || response1.data.STATUS === "Withdrawn" || response1.data.STATUS === "Not Authorised") {

							//that.getView().byId("save_button").setVisible(false);

							that.getView().byId("submit_button").setVisible(false);
							that.getView().byId("withdraw_button").setVisible(false);

							//    }
							//  });
						}
					}

				} else {
					that.getView().byId("b_approve").setVisible(false);
					that.getView().byId("b_reject").setVisible(false);
					if (response.data.results[1]) {
						if (response.data.results[1].MSG_TYPE === "C") {
							//  that.getView().byId("submit_button").setVisible(true);
						} else {
							that.getView().byId("submit_button").setVisible(false);
							that.getView().byId("withdraw_button").setVisible(false);

							that.modelData.read("/eFormInitialInfos('" + that.eformnum + "')", null, [], false, function (oData1, response1) {
								if (response1.data.STATUS === "Rejected" || response1.data.STATUS === "Withdrawn" || response1.data.STATUS ===
									"Not Authorised") {

									//that.getView().byId("save_button").setVisible(false);

									that.getView().byId("b_approve").setVisible(false);
									that.getView().byId("b_reject").setVisible(false);

								}
							});

						}
					}

				}
			});
		},
		displayfields: function () {
			this.getView().byId("b_delete").setVisible(true);
			this.getView().byId("b_edit").setVisible(true);
			this.getView().byId("textarea_comments").setValue("");
			this.getView().byId("textarea_comments2").setValue("");
			if (copy_case !== "X") {
				this.approve_reject_button_dsp();

			}
			var model = this.getOwnerComponent().getModel("oData");
			// if(this.getView().byId("input_RequestType"))
			// model.setProperty("/displayAttachmentColumn", false);
			var relPath = "/eFormAdhocForms";
			var that1 = this;
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, e_form_num
			);
			model.read(relPath, {
				filters: [oFilter],
				urlParameters: {
					"$expand": "AdhocForm_Approvers"
				},
				success: function (oData, response) {
					// creating local json model
					//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FIELD FOR IMAGE:START
					if (copy_case == "X") {
						var b64 = "";

						// localData.PCF_IMAGE_TYPE="";
					} else {
						var image_type = oData.results[0].PCF_IMAGE_TYPE;
						if (image_type == "") {
							var b64 = "";
						} else {
							var b64 = "data:" + image_type + ";base64,";
							b64 = b64.concat(oData.results[0].PCF_IMAGE);
						}
					}
					//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FIELD FOR IMAGE:END
					var localData = {
						PCF_IMAGE: b64,
						EFORM_NUM: oData.results[0].EFORM_NUM,
						TITLE: oData.results[0].TITLE,
						DESC: oData.results[0].DESC,
						REQUEST_DATE: oData.results[0].REQUEST_DATE,
						CHARGED_DATE: oData.results[0].CHARGED_DATE,
						PREPARER: oData.results[0].PREPARER,
						ON_BEHALF_OF: oData.results[0].ON_BEHALF_OF,
						REQUESTER_PHONE: oData.results[0].REQUESTER_PHONE,
						REQUESTER_EMAIL: oData.results[0].REQUESTER_EMAIL,
						REQUEST_TYPE: oData.results[0].REQUEST_TYPE,
						// REQ0600512:NSONI3:GWDK902137:09/17/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
						ATTACHMENT_CHECKBOXES: oData.results[0].REQUEST_TYPE === "Worldwide Facilities-PCF" ? true : false,
						// ATTACH: oData.results[0].ATTACH === "" ? false : true,
						// REQ0600512:NSONI3:GWDK902137:09/17/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
						PURPOSE: oData.results[0].PURPOSE,
						INSTRUCTIONS: oData.results[0].INSTRUCTIONS,
						LOB: oData.results[0].LOB,
						SUBLOB: oData.results[0].SUBLOB,
						TERRITORY: oData.results[0].TERRITORY,
						APPROVE_BY_DATE: oData.results[0].APPROVE_BY_DATE,
						CUSTOMER_COMPANY: oData.results[0].CUST_COMPANY,
						REQ_DESC: oData.results[0].REQUEST_DESC,
						DATE_NEEDED: oData.results[0].DATE_NEEDED,
						VENDOR_NAME: oData.results[0].VENDOR_NAME,
						VENDOR_ADDRESS: oData.results[0].VENDOR_ADDRESS,
						COMPANY_CODE: oData.results[0].COMPANY_CODE,
						PAYING_ENTITY: oData.results[0].PAYING_ENTITY,
						COMPANY_NAME: oData.results[0].COMPANY_NAME,
						AMOUNT_DONATION_USD: new Intl.NumberFormat('en-US').format(oData.results[0].AMOUNT_CONVERTED),
						CURRENCY: oData.results[0].CURRENCY,
						GENE_LEDGER: oData.results[0].GENE_LEDGER,
						WBS_ELEMENT: oData.results[0].WBS_ELEMENT,
						//  AMOUNT: new Intl.NumberFormat('en-US').format(oData.results[0].AMOUNT),
						AMOUNT: oData.results[0].AMOUNT,
						INVOICE_DESC: oData.results[0].INVOICE_DESC,
						requestmode: Boolean(0),
						PCFField: Boolean(0),
						//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
						PCFField_img1: Boolean(0),
						PCFField_img2: Boolean(0),
						///REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:END
						PCF_TFADATE: oData.results[0].PCF_TFADATE,
						PCF_LOB: oData.results[0].PCF_LOB,
						// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
						PCF_RECOMMAND: oData.results[0].PCF_RECOMMAND,
						// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END
						PCF_STATE: oData.results[0].PCF_STATE,
						PCF_COUNTRY: oData.results[0].PCF_COUNTRY,
						PCF_CITY: oData.results[0].PCF_CITY,
						PCF_POSTAL_CODE: oData.results[0].PCF_POSTAL_CODE,
						PCF_LOCATION: oData.results[0].PCF_LOCATION,
						PCF_AREASM: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_AREASM),
						PCF_AREASF: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_AREASF),
						PCF_LEASE: oData.results[0].PCF_LEASE,
						// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
						PCF_EXIT: oData.results[0].PCF_EXIT,
						// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END
						PCF_LOCCURRENCY: oData.results[0].PCF_LOCCURRENCY,
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
						PCF_EXCHANGE_RATE: oData.results[0].PCF_EXCHANGE_RATE,
						//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END
						PCF_OCC_COST: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_OCC_COST),
						PCF_CAP_COST: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_CAP_COST),
						PCF_OT_COST: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_OT_COST),
						PCF_OTHER_MISC: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_OTHER_MISC),
						PCF_GRAND_TOTAL: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_GRAND_TOTAL),
						PCF_OCC_COST_USD: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_OCC_COST_USD),
						PCF_CAP_COST_USD: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_CAP_COST_USD),
						PCF_OT_COST_USD: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_OT_COST_USD),
						PCF_OTHER_MISC_USD: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_OTHER_MISC_USD),
						PCF_GRAND_TOTAL_USD: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_GRAND_TOTAL_USD),
						//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
						PCF_REINSTATEMENT_COST: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_REINSTATEMENT_COST),
						PCF_REINSTATEMENT_COST_USD: new Intl.NumberFormat('en-US').format(oData.results[0].PCF_REINSTATEMENT_COST_USD),
						//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
						PCF_DESC_JUST: oData.results[0].PCF_DESC_JUST,
						PCF_COMPANY_CODE: oData.results[0].PCF_COMPANY_CODE,
						PCF_PROFIT_CENTER: oData.results[0].PCF_PROFIT_CENTER,
						PCF_COST_CENTER: oData.results[0].PCF_COST_CENTER,
						FR_APPROVE_BY_DATE: oData.results[0].FR_APPROVE_BY_DATE,
						FR_COMPANY_CODE: oData.results[0].FR_COMPANY_CODE,
						FR_LOB: oData.results[0].FR_LOB,
						FR_FISCAL_P_MONTH: oData.results[0].FR_FISCAL_P_MONTH,
						FISCAL_YEAR: oData.results[0].FR_FISCAL_P_YEAR,
						FR_DOC_LINK: oData.results[0].FR_DOC_LINK,
						FR_SAP_REF_DOC: oData.results[0].FR_SAP_REF_DOC,
						FR_FIN_REQ_TYPE: oData.results[0].FR_FIN_REQ_TYPE,
						localcurrency: [{
							name: "",
							exch: ""
						}],
						FR_FISCAL_P_YEAR: [{
							FISCAL_YEAR: "",
						}],
						USERS: [{
							USERID: "",
							NAME: ""
						}],
						LOBS: [{
							LOB: "",
							SLOB_DESCRIPTION: ""
						}],
						COUNTRIES: [{
							COUNTRY: "",
							NAME: ""
						}],
						SUBLOBS: [{
							SUBLOB: "",
							SLOB_DESCRIPTION: ""
						}],
						approvers: [{
							approved: "",
							approver: "",
							reviewer_type: "",
							approved_by: "",
							approval_date: "",
							approval_time: "",
							manual_addition: false,
							added_by: "",
							added_on: "",
							can_edit: Boolean(0)
						}],

						//************************************************************************************************************
						//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
						//-------Start of Change Description: Setting model for STPN request form after fetching data
						//************************************************************************************************************
						BUSINESSTYPE: [],
						PURCHASETYPE: [],
						FORMTYPE: [],
						BUSINESS: oData.results[0].BUSINESS,
						PUR_TYPE: oData.results[0].PUR_TYPE,
						FORM_TYPE: oData.results[0].FORM_TYPE,
						BUSINESS_TXT: oData.results[0].BUSINESS_TXT,
						PUR_TYPE_TXT: oData.results[0].PUR_TYPE_TXT,
						FORM_TYPE_TXT: oData.results[0].FORM_TYPE_TXT
					};
					if (oData.results[0].REQUEST_TYPE === "SPTN ProCard Payment Request") {
						if (oData.results[0].COMPANY_CODE !== "") {
							localData.COMPANY_CODE = oData.results[0].COMPANY_CODE + " (" + oData.results[0].COMPANY_NAME + ")";
						} else {
							localData.COMPANY_CODE = oData.results[0].COMPANY_CODE;
						}
						if (oData.results[0].GENE_LEDGER !== "") {
							localData.GENE_LEDGER = oData.results[0].GENE_LEDGER + " (" + oData.results[0].TXT20_SKAT + ")";
						} else {
							localData.GENE_LEDGER = oData.results[0].GENE_LEDGER;
						}
						if (localData.WBS_ELEMENT !== "") {
							localData.WBS_ELEMENT = oData.results[0].WBS_ELEMENT + " (" + oData.results[0].WBS_ELEMENT_TXT + ")";
						} else {
							localData.WBS_ELEMENT = oData.results[0].WBS_ELEMENT;
						}
						if (localData.PCF_COST_CENTER !== "") {
							localData.PCF_COST_CENTER = oData.results[0].PCF_COST_CENTER + " (" + oData.results[0].FUNDING_DEPT_DESC + ")";
						} else {
							localData.PCF_COST_CENTER = oData.results[0].PCF_COST_CENTER;
						}
						localData.AMOUNT_DONATION_USD = new Intl.NumberFormat('en-US', {
							maximumFractionDigits: 2
						}).format(oData.results[0].AMOUNT_CONVERTED);
						// localData.AMOUNT = new Intl.NumberFormat('en-US', {
						//  maximumFractionDigits: 2
						// }).format(oData.results[0].AMOUNT);

						that1.getView().byId("stpn_cb_business").data("sItemId", oData.results[0].BUSINESS);
						that1.getView().byId("stpn_cb_purchaseType").data("sItemId", oData.results[0].PUR_TYPE);
						that1.getView().byId("stpn_cb_formType").data("sItemId", oData.results[0].FORM_TYPE);
					}

					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------End of Change Description: Setting model for STPN request form after fetching data
					//************************************************************************************************************
					var oModelTab = new sap.ui.model.json.JSONModel();
					oModelTab.setData(localData);
					oModelTab.setSizeLimit(1000);
					that1.getView().setModel(oModelTab);
					eform_status = oData.results[0].STATUS;
					if (copy_case !== "X") {
						if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
							that1.getView().byId("button_delete_attachment").setVisible(false);
							that1.getView().byId("button_attachment_delete_summary").setVisible(false);

							that1.getView().byId("buton_update_cmt").setVisible(false);
							that1.getView().byId("button_delete_cmt").setVisible(false);

							that1.getView().byId("buton_update_cmt_sum").setVisible(false);
							that1.getView().byId("button_delete_cmt_sum").setVisible(false);
							// that1.getView().byId("i_comment_txt").setEditable(false);
							// that1.getView().byId("i_comment_txt_sum").setEditable(false);

						}
					}
					copy_lob = oData.results[0].LOB;
					copy_sublob = oData.results[0].SUBLOB;
					copy_on_behalf_of = oData.results[0].ON_BEHALF_OF;
					req_type = oData.results[0].REQUEST_TYPE;
					var model = that1.getOwnerComponent().getModel("oData");
					model.read("/eFormProductionAccts", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that1.getView().getModel();
							var aRows = oModel.getProperty("/USERS");
							for (i = 0; i < counter; i++) {
								var item = {
									USERID: response.data.results[i].USERID,
									NAME: response.data.results[i].NAME
								};
								aRows.push(item);
							}
							oModel.setProperty("/USERS", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					var model = that1.getOwnerComponent().getModel("oData");
					model.read("/eFormFiscalYearS", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that1.getView().getModel();
							var aRows = oModel.getProperty("/FR_FISCAL_P_YEAR");
							for (i = 0; i < counter; i++) {
								var item = {
									FISCAL_YEAR: response.data.results[i].FISCAL_PERIOD_YEAR,
								};
								aRows.push(item);
							}
							oModel.setProperty("/FR_FISCAL_P_YEAR", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					var model = that1.getOwnerComponent().getModel("oData");
					var that2 = that1;
					model.read("/eFormCountries", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that2.getView().getModel();
							var aRows = oModel.getProperty("/COUNTRIES");
							for (i = 0; i < counter; i++) {
								var item = {
									COUNTRY: response.data.results[i].COUNTRY,
									NAME: response.data.results[i].NAME
								};
								aRows.push(item);
							}
							oModel.setProperty("/COUNTRIES", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					var model = that1.getOwnerComponent().getModel("oData");
					var that2 = that1;
					model.read("/eFormLobs", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that1.getView().getModel();
							var aRows = oModel.getProperty("/LOBS");
							for (i = 0; i < counter; i++) {
								var item = {
									LOB: response.data.results[i].LOB,
									SLOB_DESCRIPTION: response.data.results[i].SLOB_DESCRIPTION
								};
								aRows.push(item);
							}
							oModel.setProperty("/LOBS", aRows);
							that1.onChangeLOB();
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------Start of Change Description: oData call for data of Business/ Purchase type/ Form type
					//************************************************************************************************************
					model.read("/eformAdhocBusinesses", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that1.getView().getModel();
							var aRows = oModel.getProperty("/BUSINESSTYPE");
							for (i = 0; i < counter; i++) {
								var item = {
									BUSINESS: response.data.results[i].BUSINESS,
									BUSINESS_TXT: response.data.results[i].BUSINESS_TXT
								};
								aRows.push(item);
							}
							oModel.setProperty("/BUSINESSTYPE", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});

					model.read("/eformAdhocPurchaseTypeS", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that1.getView().getModel();
							var aRows = oModel.getProperty("/PURCHASETYPE");
							for (i = 0; i < counter; i++) {
								var item = {
									PUR_TYPE: response.data.results[i].PUR_TYPE,
									PUR_TYPE_TXT: response.data.results[i].PUR_TYPE_TXT
								};
								aRows.push(item);
							}
							oModel.setProperty("/PURCHASETYPE", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});

					model.read("/eformAdhocFormTypeS", {
						success: function (oData, response) {
							var counter = response.data.results.length;
							var i = 0;
							var oModel = that1.getView().getModel();
							var aRows = oModel.getProperty("/FORMTYPE");
							for (i = 0; i < counter; i++) {
								var item = {
									FORM_TYPE: response.data.results[i].FORM_TYPE,
									FORM_TYPE_TXT: response.data.results[i].FORM_TYPE_TXT
								};
								aRows.push(item);
							}
							oModel.setProperty("/FORMTYPE", aRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------End of Change Description: oData call for data of Business/ Purchase type/ Form type
					//************************************************************************************************************

					that1.byId('oSelectCountry').setValue(localData.TERRITORY);
					that1.bindingCurrency();
					e_form_num = oData.results[0].EFORM_NUM;
					eform_status = oData.results[0].STATUS;
					if (eform_status === "Approved") {
						that1.getView().byId("save_button").setVisible(false);
						that1.getView().byId("submit_button").setVisible(false);
						that1.getView().byId("withdraw_button").setVisible(false);
						// that1.getView().byId("b_approve").setVisible(false);
						// that1.getView().byId("b_reject").setVisible(false);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
					} else if (eform_status === "Data Saved" || eform_status == "Withdrawn") {
						that1.getView().byId("save_button").setVisible(true);
						that1.getView().byId("submit_button").setVisible(true);
						that1.getView().byId("withdraw_button").setVisible(false);
						// that1.getView().byId("b_approve").setVisible(false);
						// that1.getView().byId("b_reject").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:START
						// this.getView().byId("HOME").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:END
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						that1.getView().byId("print_button").setEnabled(true);
						that1.approve_reject_button_dsp();
					} else if (eform_status === "Rejected") {
						that1.getView().byId("save_button").setVisible(true);
						that1.getView().byId("submit_button").setVisible(false);
						that1.getView().byId("withdraw_button").setVisible(true);
						that1.approve_reject_button_dsp();
						// that1.getView().byId("b_approve").setVisible(true);
						// that1.getView().byId("b_reject").setVisible(false);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						that1.getView().byId("print_button").setEnabled(true);
					}
					if (eform_status === "In Approval") {
						that1.getView().byId("withdraw_button").setVisible(true);
						that1.approve_reject_button_dsp();
						// that1.getView().byId("b_approve").setVisible(true);
						// that1.getView().byId("b_reject").setVisible(true);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						that1.getView().byId("save_button").setVisible(true);
						that1.getView().byId("submit_button").setVisible(false);
					}
					if (that1.getView().byId("CURRENCY").getValue() == 'USD') {
						that1.getView().byId("AMOUNT_USD").setVisible(false);
					} else {
						that1.getView().byId("AMOUNT_USD").setVisible(true);
					}
					if (copy_case == "X") {
						that1.getView().byId("b_delete").setVisible(false);
						that1.getView().byId("b_edit").setVisible(false);
						that1.getView().byId("approver_table").destroyItems();
						that1.fillApprovers_copy_case(that1);
						e_form_num = "";
						eform_status = "Data Saved";
						var oResourceModel = that1.getView().getModel("i18n").getResourceBundle();
						var oText = oResourceModel.getText("AdhocApprovableForm", [e_form_num]);
						that1.getView().byId("page").setText(oText);
						var oModel = that1.getView().getModel();
						var editmode = oModel.getProperty("/requestmode");
						editmode = Boolean(1);
						oModel.setProperty("/requestmode", editmode);
						that1.getView().byId("save_button").setVisible(true);
						that1.getView().byId("submit_button").setVisible(true);
						that1.getView().byId("withdraw_button").setVisible(false);
						that1.getView().byId("print_button").setEnabled(true);
						//change by jatin
						that1.getView().byId("b_approve").setVisible(false);
						that1.getView().byId("b_reject").setVisible(false);
						//end of change
						//S4R:PJAIN6:Home icon not visible:START
						// this.getView().byId("HOME").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:END
						var model = that1.getOwnerComponent().getModel("oData");
						var that = that1;
						model.read("/eFormInitialInfos('1')", {
							success: function (oData, response) {
								var name = oData.NAME;
								var adhoc = i18ntext_bundle.getText("adhoc");
								var title = name + '-' + adhoc;
								logger_name = oData.NAME;
								that.getView().byId("input_title").setValue(title);
								that.getView().byId("text_request_date").setText(oData.DATE);
								that.getView().byId("text_Preparer").setText(name);
								// that.getView().byId("input_on_behalf_of").setValue(name);
								// that.getView().byId("input_emailid").setValue(oData.EMAIL);
								// that.getView().byId("input_business_phone").setValue(oData.PHONE);
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					} else {
						// fill approvers from backend
						that1.fillApprovers(that1);
						// fill comments from backend
						that1.fillComments(that1);
						// fill attachments from backend
						that1.fillAttachments(that1);
						var model = that1.getOwnerComponent().getModel("oData");
						var that = that1;
						model.read("/eFormInitialInfos('1')", {
							success: function (oData, response) {
								logger_name = oData.NAME;
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					}
					var msg1 = e_form_num;
					var oResourceModel = that1.getView().getModel("i18n").getResourceBundle();
					var oText = oResourceModel.getText("AdhocApprovableForm", [msg1]);
					that1.getView().byId("page").setText(oText);
					var dateNeededs = that1.getView().byId("DP2");
					if (dateNeededs.getValue() === "00000000") {
						dateNeededs.setValue('');
						that1.getView().getModel().setProperty("/DATE_NEEDED", "");
					}
					var model = that1.getView().getModel();
					var editmode = model.getProperty("/PCFField");
					editmode = Boolean(0);
					model.setProperty("/PCFField", editmode);
					//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
					model.setProperty("/PCFField_img1", editmode);
					model.setProperty("/PCFField_img2", editmode);
					//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:END
					var oSelectedItem = that1.getView().byId("input_RequestType").getValue();
					if ((oSelectedItem === 'Miscellaneous') || (oSelectedItem === 'Programming COFA') || (oSelectedItem === 'Sign-Off: BRD') || (
							oSelectedItem === 'Sign-Off: UAT') || (oSelectedItem === 'Sign-Off: Other') || (oSelectedItem ===
							'Sign-Off: FD/Level 7 Approval') || (oSelectedItem === 'Contract Approval Form') || (oSelectedItem ===
							'Residual Payment Control')) {
						that1.hideSTPNFields(that1);
						that1.getView().byId("request_Desc_s").setVisible(false);
						that1.getView().byId("request_Desc").setVisible(false);
						that1.getView().byId("purpose").setVisible(true);
						that1.getView().byId("instruction").setVisible(true);
						that1.getView().byId("dateneeded").setVisible(false);
						that1.getView().byId("vendorname").setVisible(false);
						that1.getView().byId("vendoradd").setVisible(false);
						that1.getView().byId("payingentity").setVisible(false);
						that1.getView().byId("compcode").setVisible(false);
						that1.getView().byId("glaccount").setVisible(false);
						that1.getView().byId("wbs").setVisible(false);
						that1.getView().byId("amount_s1").setVisible(false);
						that1.getView().byId("AMOUNT_USD").setVisible(false);
						that1.getView().byId("amount").setVisible(false);
						that1.getView().byId("invoice").setVisible(false);
						that1.getView().byId("purpose_s").setVisible(true);
						that1.getView().byId("instruction_s").setVisible(true);
						that1.getView().byId("dateneeded_s").setVisible(false);
						that1.getView().byId("vendorname_s").setVisible(false);
						that1.getView().byId("vendoradd_s").setVisible(false);
						that1.getView().byId("payingentity_s").setVisible(false);
						that1.getView().byId("compcode_s").setVisible(false);
						that1.getView().byId("glaccount_s").setVisible(false);
						that1.getView().byId("wbs_s").setVisible(false);
						that1.getView().byId("amount_s").setVisible(false);
						that1.getView().byId("invoice_s").setVisible(false);
					} else if (oSelectedItem === 'Production Accounting Payment Request') {
						that1.hideSTPNFields(that1);
						that1.getView().byId("request_Desc_s").setVisible(false);
						that1.getView().byId("request_Desc").setVisible(false);
						that1.getView().byId("purpose").setVisible(true);
						that1.getView().byId("instruction").setVisible(true);
						that1.getView().byId("dateneeded").setVisible(true);
						that1.getView().byId("vendorname").setVisible(true);
						that1.getView().byId("vendoradd").setVisible(true);
						that1.getView().byId("payingentity").setVisible(true);
						that1.getView().byId("compcode").setVisible(false);
						that1.getView().byId("glaccount").setVisible(true);
						that1.getView().byId("wbs").setVisible(true);
						that1.getView().byId("amount").setVisible(true);
						that1.getView().byId("amount_s").setVisible(true);
						if (that1.byId('AMOUNT_DONATION_USD').getText() !== "") {
							that1.getView().byId("AMOUNT_USD").setVisible(true);
							that1.getView().byId("amount_s1").setVisible(true);
						} else if (that1.byId('AMOUNT_DONATION_USD').getText() === "") {
							that1.getView().byId("AMOUNT_USD").setVisible(false);
							that1.getView().byId("amount_s1").setVisible(false);
						}
						that1.getView().byId("invoice").setVisible(true);
						that1.getView().byId("purpose_s").setVisible(true);
						that1.getView().byId("instruction_s").setVisible(true);
						that1.getView().byId("dateneeded_s").setVisible(true);
						that1.getView().byId("vendorname_s").setVisible(true);
						that1.getView().byId("vendoradd_s").setVisible(true);
						that1.getView().byId("payingentity_s").setVisible(true);
						that1.getView().byId("compcode_s").setVisible(false);
						that1.getView().byId("glaccount_s").setVisible(true);
						that1.getView().byId("wbs_s").setVisible(true);
						that1.getView().byId("invoice_s").setVisible(true);
					} else if (oSelectedItem === 'SPHE Media Budget Authorization') {
						that1.hideSTPNFields(that1);
						that1.getView().byId("request_Desc_s").setVisible(false);
						that1.getView().byId("request_Desc").setVisible(false);
						that1.getView().byId("purpose").setVisible(true);
						that1.getView().byId("instruction").setVisible(true);
						that1.getView().byId("dateneeded").setVisible(false);
						that1.getView().byId("vendorname").setVisible(false);
						that1.getView().byId("vendoradd").setVisible(false);
						that1.getView().byId("payingentity").setVisible(true);
						that1.getView().byId("compcode").setVisible(false);
						that1.getView().byId("glaccount").setVisible(false);
						that1.getView().byId("wbs").setVisible(false);
						that1.getView().byId("lob_s").setVisible(false);
						that1.getView().byId("sublob_s").setVisible(false);
						that1.getView().byId("lob").setVisible(false);
						that1.getView().byId("sublob").setVisible(false);
						that1.getView().byId("CURRENCY").setVisible(true);
						var loccurrency = that1.getView().byId("CURRENCY").getValue();
						if (loccurrency === 'USD') {
							that1.getView().byId("AMOUNT_USD").setVisible(false);
							that1.getView().byId("amount_s1").setVisible(false);
						} else {
							that1.getView().byId("AMOUNT_USD").setVisible(true);
							that1.getView().byId("amount_s1").setVisible(true);
						}
						that1.getView().byId("amount").setVisible(true);
						that1.getView().byId("amount_s").setVisible(true);
						that1.getView().byId("invoice").setVisible(true);
						that1.getView().byId("purpose_s").setVisible(true);
						that1.getView().byId("instruction_s").setVisible(true);
						that1.getView().byId("dateneeded_s").setVisible(false);
						that1.getView().byId("vendorname_s").setVisible(false);
						that1.getView().byId("vendoradd_s").setVisible(false);
						that1.getView().byId("payingentity_s").setVisible(true);
						that1.getView().byId("compcode_s").setVisible(false);
						that1.getView().byId("glaccount_s").setVisible(false);
						that1.getView().byId("wbs_s").setVisible(false);
						that1.getView().byId("invoice_s").setVisible(true);
					} else if ((oSelectedItem === 'Finance Request Form')) {
						that1.hideSTPNFields(that1);
						that1.getView().byId("request_Desc_s").setVisible(false);
						that1.getView().byId("request_Desc").setVisible(false);
						that1.getView().byId("territory").setVisible(false);
						that1.getView().byId("approver_Date").setVisible(false);
						that1.getView().byId("customer_company").setVisible(false);
						that1.getView().byId("territory_s").setVisible(false);
						that1.getView().byId("approver_Date_s").setVisible(false);
						that1.getView().byId("customer_company_s").setVisible(false);
						that1.getView().byId("purpose").setVisible(true);
						that1.getView().byId("fr_approve_by_date").setVisible(true);
						that1.getView().byId("fr_company").setVisible(true);
						that1.getView().byId("fr_lob").setVisible(true);
						that1.getView().byId("fr_fiscalmonth").setVisible(true);
						that1.getView().byId("fr_fiscalyear").setVisible(true);
						that1.getView().byId("fr_doclinks").setVisible(true);
						that1.getView().byId("fr_refdocs").setVisible(true);
						that1.getView().byId("fr_approve_by_date_s").setVisible(true);
						that1.getView().byId("fr_company_s").setVisible(true);
						that1.getView().byId("fr_lob_s").setVisible(true);
						that1.getView().byId("fr_fiscalmonth_s").setVisible(true);
						that1.getView().byId("fr_fiscalyear_s").setVisible(true);
						that1.getView().byId("fr_doclinks_s").setVisible(true);
						that1.getView().byId("fr_refdocs_s").setVisible(true);
						that1.getView().byId("fr_fin_req_type").setVisible(true);
						that1.getView().byId("fr_fin_req_type_s").setVisible(true);
						that1.getView().byId("instruction").setVisible(true);
						that1.getView().byId("dateneeded").setVisible(false);
						that1.getView().byId("vendorname").setVisible(false);
						that1.getView().byId("vendoradd").setVisible(false);
						that1.getView().byId("lob_s").setVisible(false);
						that1.getView().byId("sublob_s").setVisible(false);
						that1.getView().byId("lob").setVisible(false);
						that1.getView().byId("sublob").setVisible(false);
						that1.getView().byId("payingentity").setVisible(false);
						that1.getView().byId("compcode").setVisible(false);
						that1.getView().byId("glaccount").setVisible(false);
						that1.getView().byId("wbs").setVisible(false);
						that1.getView().byId("AMOUNT_USD").setVisible(false);
						that1.getView().byId("amount_s1").setVisible(false);
						that1.getView().byId("amount").setVisible(false);
						that1.getView().byId("invoice").setVisible(false);
						that1.getView().byId("purpose_s").setVisible(true);
						that1.getView().byId("instruction_s").setVisible(true);
						that1.getView().byId("dateneeded_s").setVisible(false);
						that1.getView().byId("vendorname_s").setVisible(false);
						that1.getView().byId("vendoradd_s").setVisible(false);
						that1.getView().byId("payingentity_s").setVisible(false);
						that1.getView().byId("compcode_s").setVisible(false);
						that1.getView().byId("glaccount_s").setVisible(false);
						that1.getView().byId("wbs_s").setVisible(false);
						that1.getView().byId("amount_s").setVisible(false);
						that1.getView().byId("invoice_s").setVisible(false);
						that1.getView().byId("lob_s").setVisible(false);
						that1.getView().byId("sublob_s").setVisible(false);
					} else if (oSelectedItem === 'OPC Exception') {
						that1.hideSTPNFields(that1);
						that1.getView().byId("request_Desc_s").setVisible(true);
						that1.getView().byId("request_Desc").setVisible(true);
						that1.getView().byId("purpose").setVisible(false);
						that1.getView().byId("instruction").setVisible(false);
						that1.getView().byId("lob").setVisible(true);
						that1.getView().byId("sublob").setVisible(true);
						that1.getView().byId("dateneeded").setVisible(false);
						that1.getView().byId("vendorname").setVisible(false);
						that1.getView().byId("vendoradd").setVisible(false);
						that1.getView().byId("payingentity").setVisible(false);
						that1.getView().byId("compcode").setVisible(true);
						that1.getView().byId("glaccount").setVisible(false);
						that1.getView().byId("wbs").setVisible(false);
						that1.getView().byId("amount").setVisible(false);
						that1.getView().byId("AMOUNT_USD").setVisible(false);
						that1.getView().byId("invoice").setVisible(false);
						that1.getView().byId("purpose_s").setVisible(false);
						that1.getView().byId("instruction_s").setVisible(false);
						that1.getView().byId("dateneeded_s").setVisible(false);
						that1.getView().byId("vendorname_s").setVisible(false);
						that1.getView().byId("vendoradd_s").setVisible(false);
						that1.getView().byId("payingentity_s").setVisible(false);
						that1.getView().byId("compcode_s").setVisible(true);
						that1.getView().byId("glaccount_s").setVisible(false);
						that1.getView().byId("wbs_s").setVisible(false);
						that1.getView().byId("territory_s").setVisible(false);
						that1.getView().byId("approver_Date_s").setVisible(false);
						that1.getView().byId("customer_company_s").setVisible(false);
						that1.getView().byId("amount_s").setVisible(false);
						that1.getView().byId("invoice_s").setVisible(false);
						that1.getView().byId("lob_s").setVisible(true);
						that1.getView().byId("sublob_s").setVisible(true);
					} else if (oSelectedItem === 'Worldwide Facilities-PCF') {
						that1.hideSTPNFields(that1);
						that1.flag = 'PCF';
						var model = that1.getView().getModel();
						var editmode = model.getProperty("/PCFField");
						editmode = Boolean(1);
						model.setProperty("/PCFField", editmode);
						//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
						if (copy_case == "X" || oData.results[0].PCF_IMAGE_TYPE == "") {
							model.setProperty("/PCFField_img1", editmode);
							model.setProperty("/PCFField_img2", false);
						} else {
							model.setProperty("/PCFField_img1", false);
							model.setProperty("/PCFField_img2", editmode);
						}
						//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:END
						that1.getView().byId("request_Desc_s").setVisible(false);
						that1.getView().byId("request_Desc").setVisible(false);
						that1.getView().byId("territory").setVisible(false);
						that1.getView().byId("approver_Date").setVisible(false);
						that1.getView().byId("customer_company").setVisible(false);
						that1.getView().byId("territory_s").setVisible(false);
						that1.getView().byId("approver_Date_s").setVisible(false);
						that1.getView().byId("customer_company_s").setVisible(false);
						that1.getView().byId("purpose").setVisible(false);
						that1.getView().byId("fr_approve_by_date").setVisible(false);
						that1.getView().byId("fr_company").setVisible(false);
						that1.getView().byId("fr_lob").setVisible(false);
						that1.getView().byId("fr_fiscalmonth").setVisible(false);
						that1.getView().byId("fr_fiscalyear").setVisible(false);
						that1.getView().byId("fr_doclinks").setVisible(false);
						that1.getView().byId("fr_refdocs").setVisible(false);
						that1.getView().byId("fr_approve_by_date_s").setVisible(false);
						that1.getView().byId("fr_company_s").setVisible(false);
						that1.getView().byId("fr_lob_s").setVisible(false);
						that1.getView().byId("fr_fiscalmonth_s").setVisible(false);
						that1.getView().byId("fr_fiscalyear_s").setVisible(false);
						that1.getView().byId("fr_doclinks_s").setVisible(false);
						that1.getView().byId("fr_refdocs_s").setVisible(false);
						that1.getView().byId("fr_fin_req_type").setVisible(false);
						that1.getView().byId("fr_fin_req_type_s").setVisible(false);
						that1.getView().byId("instruction").setVisible(false);
						that1.getView().byId("dateneeded").setVisible(false);
						that1.getView().byId("vendorname").setVisible(false);
						that1.getView().byId("vendoradd").setVisible(false);
						that1.getView().byId("lob").setVisible(false);
						that1.getView().byId("sublob").setVisible(false);
						that1.getView().byId("payingentity").setVisible(false);
						that1.getView().byId("compcode").setVisible(false);
						that1.getView().byId("glaccount").setVisible(false);
						that1.getView().byId("wbs").setVisible(false);
						that1.getView().byId("AMOUNT_USD").setVisible(false);
						that1.getView().byId("amount_s1").setVisible(false);
						that1.getView().byId("amount").setVisible(false);
						that1.getView().byId("invoice").setVisible(false);
						that1.getView().byId("purpose_s").setVisible(false);
						that1.getView().byId("instruction_s").setVisible(false);
						that1.getView().byId("dateneeded_s").setVisible(false);
						that1.getView().byId("vendorname_s").setVisible(false);
						that1.getView().byId("vendoradd_s").setVisible(false);
						that1.getView().byId("payingentity_s").setVisible(false);
						that1.getView().byId("compcode_s").setVisible(false);
						that1.getView().byId("glaccount_s").setVisible(false);
						that1.getView().byId("wbs_s").setVisible(false);
						that1.getView().byId("amount_s").setVisible(false);
						that1.getView().byId("invoice_s").setVisible(false);
						that1.getView().byId("lob_s").setVisible(false);
						that1.getView().byId("sublob_s").setVisible(false);
					} else if (oSelectedItem === 'Japan TV Channels') {
						that1.hideSTPNFields(that1);
						that1.getView().byId("request_Desc_s").setVisible(true);
						that1.getView().byId("request_Desc").setVisible(true);
						that1.getView().byId("lob").setVisible(true);
						that1.getView().byId("sublob").setVisible(true);
						that1.getView().byId("payingentity").setVisible(false);
						that1.getView().byId("compcode").setVisible(true);
						that1.getView().byId("territory").setVisible(true);
						that1.getView().byId("approver_Date").setVisible(true);
						that1.getView().byId("customer_company").setVisible(true);
						if (that1.byId('AMOUNT_DONATION_USD').getText() !== "") {
							that1.getView().byId("AMOUNT_USD").setVisible(true);
							that1.getView().byId("amount_s1").setVisible(true);
						} else if (that1.byId('AMOUNT_DONATION_USD').getText() === "") {
							that1.getView().byId("AMOUNT_USD").setVisible(false);
							that1.getView().byId("amount_s1").setVisible(false);
						}
						that1.getView().byId("dateneeded_s").setVisible(false);
						that1.getView().byId("vendorname_s").setVisible(false);
						that1.getView().byId("vendoradd_s").setVisible(false);
						that1.getView().byId("glaccount_s").setVisible(false);
						that1.getView().byId("wbs_s").setVisible(false);
						that1.getView().byId("amount_s").setVisible(true);
						that1.getView().byId("payingentity_s").setVisible(false);
						that1.getView().byId("compcode_s").setVisible(true);
						that1.getView().byId("invoice_s").setVisible(false);
						that1.getView().byId("lob_s").setVisible(true);
						that1.getView().byId("sublob_s").setVisible(true);
						that1.getView().byId("territory_s").setVisible(true);
						that1.getView().byId("approver_Date_s").setVisible(true);
						that1.getView().byId("customer_company_s").setVisible(true);
						that1.getView().byId("glaccount").setVisible(false);
						that1.getView().byId("wbs").setVisible(false);
						that1.getView().byId("amount").setVisible(true);
						that1.getView().byId("invoice").setVisible(false);
						that1.getView().byId("dateneeded").setVisible(false);
						that1.getView().byId("vendorname").setVisible(false);
						that1.getView().byId("vendoradd").setVisible(false);
					}
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------Start of Change Description: Visibility of fields to display already existing request
					//************************************************************************************************************
					else if (oSelectedItem === 'SPTN ProCard Payment Request') {
						that1.flag = "STPN";
						that.getView().byId("fr_approve_by_date").setVisible(false);
						that.getView().byId("fr_company").setVisible(false);
						that.getView().byId("fr_lob").setVisible(false);
						that.getView().byId("fr_fiscalmonth").setVisible(false);
						that.getView().byId("fr_fiscalyear").setVisible(false);
						that.getView().byId("fr_doclinks").setVisible(false);
						that.getView().byId("fr_refdocs").setVisible(false);
						that.getView().byId("fr_fin_req_type").setVisible(false);
						that.getView().byId("request_Desc").setVisible(false);
						that.getView().byId("territory").setVisible(false);
						that.getView().byId("approver_Date").setVisible(false);
						that.getView().byId("customer_company").setVisible(false);
						that.getView().byId("purpose").setVisible(true);
						that.getView().byId("instruction").setVisible(true);
						that.getView().byId("dateneeded").setVisible(false);
						that.getView().byId("stpn_fe_ChargeDate").setVisible(true);
						that.getView().byId("stpn_fe_fundingDept").setVisible(true);
						that.getView().byId("stpn_fe_sapVendor").setVisible(true);
						that.getView().byId("stpn_fe_or").setVisible(true);
						that.getView().byId("stpn_fe_business").setVisible(true);
						that.getView().byId("stpn_fe_purchaseType").setVisible(true);
						that.getView().byId("stpn_fe_formType").setVisible(true);
						that.getView().byId("stpn_cb_formType").setSelectedKey(1);
						that.getView().byId("stpn_cb_formType").data("sItemId", 1);
						that.getView().byId("vendorname").setVisible(false);
						that.getView().byId("vendoradd").setVisible(false);
						that.getView().byId("payingentity").setVisible(false);
						that.getView().byId("compcode").setVisible(true);
						that.getView().byId("compcode").getAggregation("label").setRequired(true);
						that.getView().byId("glaccount").setVisible(true);
						that.getView().byId("wbs").setVisible(true);
						that.getView().byId("wbs").getAggregation("label").setRequired(false);
						that.getView().byId("lob").setVisible(true);
						//REQ0737819:DPATEL11:FPDK900063:Batch-2:Adhoc lob/sublob changes : START
						that.getView().byId("input_lob").setValue("SPT - NETW");
						//that.getView().byId("input_lob").setSelectedKey("SPT - NETW");
						that.onChangeLOB();
						//REQ0737819:DPATEL11:FPDK900063:Batch-2:Adhoc lob/sublob changes : STOP
						that.getView().byId("sublob").setVisible(true);
						that.getView().byId("amount").setVisible(true);
						if ($.sap.eform_dsp !== undefined) {
							if (that1.getView().byId("CURRENCY").getValue() === 'USD') {
								that1.getView().byId("AMOUNT_USD").setVisible(false);
							} else {
								that1.getView().byId("AMOUNT_USD").setVisible(true);
							}
						} else {
							that.getView().byId("CURRENCY").setValue("USD");
							that.getView().byId("AMOUNT_USD").setVisible(false);
						}

						that.getView().byId("invoice").setVisible(true);

						// Summary Tab Fields

						that.getView().byId("territory_s").setVisible(false);
						that.getView().byId("approver_Date_s").setVisible(false);
						that.getView().byId("customer_company_s").setVisible(false);
						that.getView().byId("request_Desc_s").setVisible(false);
						that.getView().byId("fr_approve_by_date_s").setVisible(false);
						that.getView().byId("fr_company_s").setVisible(false);
						that.getView().byId("fr_lob_s").setVisible(false);
						that.getView().byId("fr_fiscalmonth_s").setVisible(false);
						that.getView().byId("fr_fiscalyear_s").setVisible(false);
						that.getView().byId("fr_doclinks_s").setVisible(false);
						that.getView().byId("fr_refdocs_s").setVisible(false);
						that.getView().byId("fr_fin_req_type_s").setVisible(false);
						that.getView().byId("dateneeded_s").setVisible(false);
						that.getView().byId("vendorname_s").setVisible(false);
						that.getView().byId("vendoradd_s").setVisible(false);
						that.getView().byId("payingentity_s").setVisible(false);

						that.getView().byId("purpose_s").setVisible(true);
						that.getView().byId("instruction_s").setVisible(true);
						that.getView().byId("compcode_s").setVisible(true);
						that.getView().byId("compcode_s").getAggregation("label").setRequired(true);
						that.getView().byId("glaccount_s").setVisible(true);
						that.getView().byId("wbs_s").setVisible(true);
						that.getView().byId("amount_s").setVisible(true);
						that.getView().byId("invoice_s").setVisible(true);
						that.getView().byId("lob_s").setVisible(true);
						that.getView().byId("sublob_s").setVisible(true);

						that.getView().byId("stpn_fe_fundingDept_summary").setVisible(true);
						that.getView().byId("stpn_fe_sapVendor_summary").setVisible(true);
						that.getView().byId("stpn_fe_fundingDept_summary").setVisible(true);
						that.getView().byId("stpn_fe_business_summary").setVisible(true);
						that.getView().byId("stpn_fe_purchaseType_summary").setVisible(true);
						that.getView().byId("stpn_fe_formType_summary").setVisible(true);
						that.getView().byId("chdt_s").setVisible(true);
						if (that.getView().getModel().getData().COMPANY_CODE === "") {

							that.getView().byId("compcode_s").setVisible(false);
						} else {
							that.getView().byId("compcode_s").setVisible(true);
						}
						if (that.getView().getModel().getData().WBS_ELEMENT === "") {
							that.getView().byId("wbs_s").setVisible(false);

						} else {
							that.getView().byId("wbs_s").setVisible(true);
						}
						if (that.getView().getModel().getData().PCF_COST_CENTER === "") {
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);

						} else {
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(true);
						}
						if (that.getView().getModel().getData().CURRENCY !== "USD") {
							that.getView().byId("AMOUNT_USD").setVisible(true);
							that.getView().byId("amount_s1").setVisible(true);
						} else if (that.getView().getModel().getData().CURRENCY === "USD") {
							that.getView().byId("AMOUNT_USD").setVisible(false);
							that.getView().byId("amount_s1").setVisible(false);
						}

					}
					//************************************************************************************************************
					//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
					//-------End of Change Description: Visibility of fields to display already existing request
					//************************************************************************************************************

					that1.resetFields();
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		fillApprovers: function (that) {
			var model = that.getOwnerComponent().getModel("oData");
			var relPath = "/eFormApprovers";
			var that1 = that;
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, e_form_num
			);
			var oBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
			model.read(relPath, {
				filters: [oFilter],
				success: function (oData, response) {
					var counter = oData.results.length;
					if (counter > 0) {
						that.byId('txtPosition').setProperty('visible', true);
						that.byId('ENTRY_SEQUENCE').setProperty('visible', true);
					} else {
						that.byId('txtPosition').setProperty('visible', false);
						that.byId('ENTRY_SEQUENCE').setProperty('visible', false);
					}
					var i = 0;
					var oMod = that1.getView().getModel();
					var apRows = oMod.getProperty("/approvers");
					var no_of_items = apRows.length;
					var t = no_of_items - 1;
					for (i = t; i >= 0; i--) {
						apRows.splice(i, 1);
					}
					oMod.setProperty("/approvers", apRows);
					// oTable.destroyItems();
					for (i = 0; i < counter; i++) {
						if (oData.results[i].APPROVED === "X") {
							oData.results[i].APPROVED = oBundle.getText("Approved");
						} else if (oData.results[i].APPROVED === "R") {
							oData.results[i].APPROVED = oBundle.getText("Rejected");
						}
						var item = {

							approved: oData.results[i].APPROVED,
							approver: oData.results[i].APPR,
							reviewer_type: oData.results[i].REVIEWER_TYPE,
							approved_by: oData.results[i].APPROVED_BY,
							approval_date: oData.results[i].APPROVAL_DT,
							approval_time: oData.results[i].APPROVAL_TM,
							manual_addition: oData.results[i].MANUAL,
							added_by: oData.results[i].ADDED_BY,
							added_on: oData.results[i].CREATION_DT,
							can_edit: Boolean(0)
						};
						apRows.push(item);
					}
					oMod.setProperty("/approvers", apRows);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		fillApprovers_copy_case: function (that) {
			var model = that.getOwnerComponent().getModel("oData");
			var relPath = "/eFormApprovers";
			var that1 = that;
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, e_form_num
			);
			model.read(relPath, {
				filters: [oFilter],
				success: function (oData, response) {
					var counter = oData.results.length;
					if (counter > 0) {
						that.byId('txtPosition').setProperty('visible', true);
						that.byId('ENTRY_SEQUENCE').setProperty('visible', true);
					} else {
						that.byId('txtPosition').setProperty('visible', false);
						that.byId('ENTRY_SEQUENCE').setProperty('visible', false);
					}
					var i = 0;
					var oMod = that1.getView().getModel();
					var apRows = oMod.getProperty("/approvers");
					var no_of_items = apRows.length;
					var t = no_of_items - 1;
					for (i = t; i >= 0; i--) {
						apRows.splice(i, 1);
					}
					oMod.setProperty("/approvers", apRows);
					for (i = 0; i < counter; i++) {
						/*  if (i === 0 && oData.results[i].REVIEWER_TYPE === 'Watcher' && oData.results[i].MANUAL != "X" && (req_type !=
						      'Japan TV Channels' || req_type != 'OPC Exception' || req_type != 'SPTN ProCard Payment Request'))*/
						if (i === 0 && oData.results[i].REVIEWER_TYPE === 'Watcher' && oData.results[i].MANUAL != "X" && (req_type !=
								'Japan TV Channels' || req_type != 'OPC Exception') && (req_type != 'SPTN ProCard Payment Request')) {
							continue;
						}
						if (oData.results[i].APPR === 'MDMA Users' && req_type === 'Japan TV Channels') {
							continue;
						}

						var added_by_name;
						var creation_date;
						if (oData.results[i].MANUAL === "X") {
							added_by_name = logger_name;
							creation_date = '';
						} else {
							added_by_name = oData.results[i].ADDED_BY;
							creation_date = oData.results[i].CREATION_DT;
						}
						var item = {
							approved: '',
							approver: oData.results[i].APPR,
							reviewer_type: oData.results[i].REVIEWER_TYPE,
							approved_by: '',
							approval_date: '',
							approval_time: '',
							manual_addition: oData.results[i].MANUAL,
							added_by: added_by_name,
							added_on: creation_date,
							can_edit: Boolean(0)
						};
						apRows.push(item);
					}
					oMod.setProperty("/approvers", apRows);
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onBehalfOf_ValueHelp: function () {
			var ssModel = this.getOwnerComponent().getModel("oData");
			var onbehalf = this.getView().byId("input_on_behalf_of");
			var chooseonbehalfof = i18ntext_bundle.getText("ChooseValueforOnBehalfOf");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: chooseonbehalfof,
				items: {
					path: "/eFormProductionAccts",
					template: new sap.m.StandardListItem({
						title: "{USERID}",
						description: "{NAME}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"NAME",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					// if (oSelectedItem) {
					onbehalf.setValue(oSelectedItem.getDescription());
					onbehalf.setValueState("None");
					var title = oEvent.getParameter("selectedItem").getTitle();
					var path = "/eFormInitialInfos('" + title + "')";
					ssModel.read(path, {
						async: true,
						success: function (oData) {
							that.byId('input_emailid').setValue(oData.EMAIL);
							that.byId('input_business_phone').setValue(oData.PHONE);
							var adhoc = i18ntext_bundle.getText("adhoc");
							//REQ0563167:NSONI3:GWDK902037:03/31/2020:Title update after select on behalf of:START
							var titleNew = oSelectedItem.getDescription() + '-' + adhoc;
							var titleCurrUpdated = that.getView().byId("input_title").getValue();
							if (that.defaultTitle === titleCurrUpdated) {
								that.getView().byId("input_title").setValue(titleNew);
							}
							//REQ0563167:NSONI3:GWDK902037:03/31/2020:Title update after select on behalf of:END
						},
						error: function (oError) {}
					});
					// }
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open(); // Opening value help dialog
			// once data is binded to
			// standard list item
		},
		setEmpty: function () {
			var that = this;
			that.getView().byId("input_RequestType").setValue('');
			that.getView().byId("text_purpose").setValue('');
			that.getView().byId("text_instruction").setValue('');
			that.getView().byId("input_VendorName").setValue('');
			that.getView().byId("text_address").setValue('');
			that.getView().byId("input_payingentity").setValue('');
			that.getView().byId("input_compcode").setValue('');
			that.getView().byId("input_glaccount").setValue('');
			that.getView().byId("input_wbs").setValue('');
			that.getView().byId("input_amount").setValue('');
			that.getView().byId("text_amnt_s").setText('');
			that.getView().byId("AMOUNT_DONATION_USD").setText('');
			that.getView().byId("text_invoice").setValue('');
			that.getView().byId("DP2").setValue('');
			that.getView().byId("input_lob").setValue('');
			that.getView().byId("input_sublob").setValue('');
			that.getView().byId("oSelectCountry").setValue('');
			that.getView().byId("date_Approver").setValue('');
			that.getView().byId("inpCustomer").setValue('');
			that.getView().byId("text_ReqDesc").setValue('');
			that.getView().byId("PCF_TFADATE").setValue('');
			that.getView().byId("PCF_LOB").setValue('');
			//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
			that.getView().byId("PCF_RECOMMAND").setValue('');
			//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END
			that.getView().byId("PCF_STATE").setValue('');
			that.getView().byId("PCF_COUNTRY").setValue('');
			that.getView().byId("PCF_CITY").setValue('');
			that.getView().byId("PCF_POSTAL_CODE").setValue('');
			that.getView().byId("PCF_LOCATION").setValue('');
			that.getView().byId("PCF_AREASM").setValue('');
			that.getView().byId("PCF_AREASF").setValue('');
			that.getView().byId("PCF_LEASE").setValue('');
			// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
			that.getView().byId("PCF_EXIT").setValue('');
			// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END
			that.getView().byId("PCF_LOCCURRENCY").setValue('');
			that.getView().byId("PCF_OCC_COST").setValue('');
			that.getView().byId("PCF_CAP_COST").setValue('');
			that.getView().byId("PCF_OT_COST").setValue('');
			that.getView().byId("PCF_OTHER_MISC").setValue('');
			that.getView().byId("PCF_GRAND_TOTAL").setText('');
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
			that.getView().byId("PCF_EXCHANGE_RATE").setValue('');
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END
			// that.getView().byId("PCF_OCC_COST_USD").setText('');
			// that.getView().byId("PCF_CAP_COST_USD").setText('');
			// that.getView().byId("PCF_OT_COST_USD").setText('');
			// that.getView().byId("PCF_OTHER_MISC_USD").setText('');
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from Text to Input:START
			that.getView().byId("PCF_OCC_COST_USD").setValue('');
			that.getView().byId("PCF_CAP_COST_USD").setValue('');
			that.getView().byId("PCF_OT_COST_USD").setValue('');
			that.getView().byId("PCF_OTHER_MISC_USD").setValue('');
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from Text to Input:END
			that.getView().byId("PCF_GRAND_TOTAL_USD").setText('');
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
			that.getView().byId("PCF_REINSTATEMENT_COST").setValue('');
			that.getView().byId("PCF_REINSTATEMENT_COST_USD").setValue('');
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
			that.getView().byId("PCF_DESC_JUST").setValue('');
			that.getView().byId("PCF_COMPANY_CODE").setValue('');
			that.getView().byId("PCF_PROFIT_CENTER").setValue('');
			that.getView().byId("PCF_COST_CENTER").setValue('');
			that.getView().byId("AppDP").setValue("");
			that.getView().byId("input_comp").setValue("");
			that.getView().byId("fr_cmb_lob").setValue("");
			that.getView().byId("fr_fis_month").setValue("");
			that.getView().byId("fr_fis_year").setValue("");
			that.getView().byId("input_frdoclinks").setValue("");
			that.getView().byId("fr_text_refdocs").setValue("");
			that.getView().byId("fin_req_type").setValue("");

			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Reseting new fields
			//************************************************************************************************************
			this.getView().byId("stpn_ip_fundingDept").setValue("");
			this.getView().byId("stpn_ip_sapVendor").setValue("");
			this.getView().byId("stpn_cb_business").setValue("");
			this.getView().byId("stpn_cb_purchaseType").setValue("");
			this.getView().byId("stpn_cb_formType").setValue("");
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Reseting new fields
			//************************************************************************************************************
		},
		_onRequestTypeValueHelpRequest: function () {
			var that = this;
			var table = this.getView().byId("approver_table");
			var table2 = this.getView().byId("approver_table_s");
			if (table.getItems().length > 0) {
				that.byId('txtPosition').setProperty('visible', true);
				that.byId('ENTRY_SEQUENCE').setProperty('visible', true);
			} else {
				that.byId('txtPosition').setProperty('visible', false);
				that.byId('ENTRY_SEQUENCE').setProperty('visible', false);
			}
			var i;
			var no_of_item_s = table2.getItems();
			var length_s = table2.getItems().length;
			var t = length_s - 1;
			for (i = t; i >= 0; i--) {
				if (no_of_item_s[i].getCells()[6].getSelected() != true) {
					table2.removeItem(no_of_item_s[i]);
				}
			}
			var reqtype = this.getView().byId("input_RequestType");
			var choosevaluerequesttye = i18ntext_bundle.getText("ChooseValueforRequestType");
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: choosevaluerequesttye,
				items: {
					path: "/eFormRequestTypes",
					template: new sap.m.StandardListItem({
						title: "{RequestType}",
						// description: "{RequestId}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"RequestType",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				confirm: function (oEvent) {
					that.setEmpty();
					that.getView().byId("input_RequestType").setValueState('None');
					that.getView().byId("text_purpose").setValueState('None');
					that.getView().byId("text_instruction").setValueState('None');
					that.getView().byId("input_VendorName").setValueState('None');
					that.getView().byId("text_address").setValueState('None');
					that.getView().byId("input_payingentity").setValueState('None');
					that.getView().byId("input_compcode").setValueState('None');
					that.getView().byId("input_glaccount").setValueState('None');
					that.getView().byId("input_wbs").setValueState('None');
					that.getView().byId("input_amount").setValueState('None');
					that.getView().byId("text_invoice").setValueState('None');
					that.getView().byId("DP2").setValueState('None');
					that.getView().byId("input_lob").setValueState('None');
					that.getView().byId("input_sublob").setValueState('None');
					that.getView().byId("oSelectCountry").setValueState('None');
					that.getView().byId("date_Approver").setValueState('None');
					that.getView().byId("AppDP").setValueState('None');
					that.getView().byId("input_comp").setValueState('None');
					that.getView().byId("fr_cmb_lob").setValueState('None');
					that.getView().byId("fr_fis_month").setValueState('None');
					that.getView().byId("fr_fis_year").setValueState('None');
					that.getView().byId("input_frdoclinks").setValueState('None');
					that.getView().byId("fr_text_refdocs").setValueState('None');
					that.getView().byId("fin_req_type").setValueState('None');
					var oSelectedItem = oEvent.getParameter("selectedItem");
					var i;
					var no_of_items = table.getItems();
					var length = table.getItems().length;
					var t = length - 1;
					for (i = t; i >= 0; i--) {
						//************************************************************************************************************
						//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
						//-------Start of Change Description: Added "SPTN ProCard Payment Request" to the condition
						//************************************************************************************************************
						if (oSelectedItem.getTitle() != 'Japan TV Channels' && oSelectedItem.getTitle() != 'OPC Exception' && oSelectedItem.getTitle() !=
							'SPTN ProCard Payment Request') {

							if (no_of_items[i].getCells()[6].getSelected() != true) {
								table.removeItem(no_of_items[i]);
							}
						} else
						/*<Request Number:REQ034679><Dt: 14.10.2018><Start of>*/
						if (no_of_items[i].getCells()[6].getSelected() != true) {
							table.removeItem(no_of_items[i]);
							/*<Request Number:REQ034679><Dt: 14.10.2018><End of>*/
						}
					}
					if (oSelectedItem) {
						reqtype.setValue(oSelectedItem.getTitle());
						reqtype.setValueState("None");
						var model = that.getView().getModel();
						var editmode = model.getProperty("/PCFField");
						editmode = Boolean(0);
						model.setProperty("/PCFField", editmode);
						//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
						model.setProperty("/PCFField_img1", editmode);
						model.setProperty("/PCFField_img2", editmode);
						//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:END
						if ((oSelectedItem.getTitle() === 'Miscellaneous') || (oSelectedItem.getTitle() === 'Programming COFA') || (oSelectedItem.getTitle() ===
								'Sign-Off: BRD') || (oSelectedItem.getTitle() === 'Sign-Off: UAT') || (oSelectedItem.getTitle() === 'Sign-Off: Other') || (
								oSelectedItem.getTitle() === 'Sign-Off: FD/Level 7 Approval') || (oSelectedItem.getTitle() === 'Contract Approval Form') ||
							(oSelectedItem.getTitle() === 'Residual Payment Control')) {
							that.flag = "A";

							that.getView().byId("request_Desc_s").setVisible(false);
							that.getView().byId("request_Desc").setVisible(false);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("purpose").setVisible(true);
							that.getView().byId("instruction").setVisible(true);
							that.getView().byId("dateneeded").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field visibility functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);

							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field visibility functionality
							//************************************************************************************************************
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("lob").setVisible(false);
							that.getView().byId("sublob").setVisible(false);
							that.getView().byId("payingentity").setVisible(false);
							that.getView().byId("compcode").setVisible(false);
							that.getView().byId("glaccount").setVisible(false);
							that.getView().byId("wbs").setVisible(false);
							that.getView().byId("AMOUNT_USD").setVisible(false);
							that.getView().byId("amount_s1").setVisible(false);
							that.getView().byId("amount").setVisible(false);
							that.getView().byId("invoice").setVisible(false);
							that.getView().byId("purpose_s").setVisible(true);
							that.getView().byId("instruction_s").setVisible(true);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("payingentity_s").setVisible(false);
							that.getView().byId("compcode_s").setVisible(false);
							that.getView().byId("glaccount_s").setVisible(false);
							that.getView().byId("wbs_s").setVisible(false);
							that.getView().byId("amount_s").setVisible(false);
							that.getView().byId("invoice_s").setVisible(false);
							that.getView().byId("lob_s").setVisible(false);
							that.getView().byId("sublob_s").setVisible(false);
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
						} else if (oSelectedItem.getTitle() === 'Worldwide Facilities-PCF') {
							that.flag = 'PCF';
							var model = that.getView().getModel();
							var editmode = model.getProperty("/PCFField");
							editmode = Boolean(1);
							model.setProperty("/PCFField", editmode);
							//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:START
							model.setProperty("/PCFField_img1", editmode);
							model.setProperty("/PCFField_img2", false);
							//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING VISIBILITY FIELD FOR IMAGE:END
							that.getView().byId("request_Desc_s").setVisible(false);
							that.getView().byId("request_Desc").setVisible(false);
							that.getView().byId("instruction_s").setVisible(false);
							that.getView().byId("purpose").setVisible(false);
							that.getView().byId("instruction").setVisible(false);
							that.getView().byId("lob").setVisible(false);
							that.getView().byId("sublob").setVisible(false);
							that.getView().byId("payingentity").setVisible(false);
							that.getView().byId("compcode").setVisible(false);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("purpose_s").setVisible(false);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("glaccount_s").setVisible(false);
							that.getView().byId("wbs_s").setVisible(false);
							that.getView().byId("amount_s").setVisible(false);
							that.getView().byId("payingentity_s").setVisible(false);
							that.getView().byId("compcode_s").setVisible(false);
							that.getView().byId("invoice_s").setVisible(false);
							that.getView().byId("lob_s").setVisible(false);
							that.getView().byId("sublob_s").setVisible(false);
							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("glaccount").setVisible(false);
							that.getView().byId("wbs").setVisible(false);
							that.getView().byId("amount").setVisible(false);
							that.getView().byId("invoice").setVisible(false);
							that.getView().byId("dateneeded").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
						} else if ((oSelectedItem.getTitle() === 'Finance Request Form')) {
							that.flag = 'FR';
							that.getView().byId("request_Desc_s").setVisible(false);
							that.getView().byId("request_Desc").setVisible(false);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("purpose").setVisible(true);
							that.getView().byId("fr_approve_by_date").setVisible(true);
							that.getView().byId("fr_company").setVisible(true);
							that.getView().byId("fr_lob").setVisible(true);
							that.getView().byId("fr_fiscalmonth").setVisible(true);
							that.getView().byId("fr_fiscalyear").setVisible(true);
							that.getView().byId("fr_doclinks").setVisible(true);
							that.getView().byId("fr_refdocs").setVisible(true);
							that.getView().byId("fr_approve_by_date_s").setVisible(true);
							that.getView().byId("fr_company_s").setVisible(true);
							that.getView().byId("fr_lob_s").setVisible(true);
							that.getView().byId("fr_fiscalmonth_s").setVisible(true);
							that.getView().byId("fr_fiscalyear_s").setVisible(true);
							that.getView().byId("fr_doclinks_s").setVisible(true);
							that.getView().byId("fr_refdocs_s").setVisible(true);
							that.getView().byId("instruction").setVisible(true);
							that.getView().byId("dateneeded").setVisible(false);

							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("lob").setVisible(false);
							that.getView().byId("sublob").setVisible(false);
							that.getView().byId("payingentity").setVisible(false);
							that.getView().byId("compcode").setVisible(false);
							that.getView().byId("glaccount").setVisible(false);
							that.getView().byId("wbs").setVisible(false);
							that.getView().byId("AMOUNT_USD").setVisible(false);
							that.getView().byId("amount_s1").setVisible(false);
							that.getView().byId("amount").setVisible(false);
							that.getView().byId("invoice").setVisible(false);
							that.getView().byId("purpose_s").setVisible(true);
							that.getView().byId("instruction_s").setVisible(true);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("payingentity_s").setVisible(false);
							that.getView().byId("compcode_s").setVisible(false);
							that.getView().byId("glaccount_s").setVisible(false);
							that.getView().byId("wbs_s").setVisible(false);
							that.getView().byId("amount_s").setVisible(false);
							that.getView().byId("invoice_s").setVisible(false);
							that.getView().byId("lob_s").setVisible(false);
							that.getView().byId("sublob_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(true);
							that.getView().byId("fr_fin_req_type_s").setVisible(true);
						} else if (oSelectedItem.getTitle() === 'Production Accounting Payment Request') {
							that.flag = "B";
							that.getView().byId("request_Desc_s").setVisible(false);
							that.getView().byId("request_Desc").setVisible(false);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("purpose").setVisible(true);
							that.getView().byId("instruction").setVisible(true);
							that.getView().byId("dateneeded").setVisible(true);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("vendorname").setVisible(true);
							that.getView().byId("vendoradd").setVisible(true);
							that.getView().byId("payingentity").setVisible(true);
							that.getView().byId("compcode").setVisible(false);
							that.getView().byId("glaccount").setVisible(true);
							that.getView().byId("wbs").setVisible(true);
							that.getView().byId("wbs").getAggregation("label").setRequired(true);
							that.getView().byId("lob").setVisible(false);
							that.getView().byId("sublob").setVisible(false);
							that.getView().byId("amount").setVisible(true);
							that.getView().byId("CURRENCY").setEnabled(true);
							that.getView().byId("invoice").setVisible(true);
							that.getView().byId("purpose_s").setVisible(true);
							that.getView().byId("instruction_s").setVisible(true);
							that.getView().byId("dateneeded_s").setVisible(true);
							that.getView().byId("vendorname_s").setVisible(true);
							that.getView().byId("vendoradd_s").setVisible(true);
							that.getView().byId("payingentity_s").setVisible(true);
							that.getView().byId("compcode_s").setVisible(false);
							that.getView().byId("glaccount_s").setVisible(true);
							that.getView().byId("wbs_s").setVisible(true);
							that.getView().byId("amount_s").setVisible(true);
							that.getView().byId("invoice_s").setVisible(true);
							that.getView().byId("lob_s").setVisible(false);
							that.getView().byId("sublob_s").setVisible(false);
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
						}
						//************************************************************************************************************
						//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
						//-------Start of Change Description: Visibility of field for creating a new request
						//************************************************************************************************************
						else if (oSelectedItem.getTitle() === 'SPTN ProCard Payment Request') {
							that.flag = "STPN";
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("request_Desc").setVisible(false);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("purpose").setVisible(true);
							that.getView().byId("instruction").setVisible(true);
							that.getView().byId("dateneeded").setVisible(false);
							that.getView().byId("stpn_fe_ChargeDate").setVisible(true);
							that.getView().byId("stpn_fe_fundingDept").setVisible(true);
							that.getView().byId("stpn_fe_sapVendor").setVisible(true);
							that.getView().byId("stpn_fe_or").setVisible(true);
							that.getView().byId("stpn_fe_business").setVisible(true);
							that.getView().byId("stpn_fe_purchaseType").setVisible(true);
							that.getView().byId("stpn_fe_formType").setVisible(true);
							that.getView().byId("stpn_cb_formType").setSelectedKey(1);
							that.getView().byId("stpn_cb_formType").data("sItemId", 1);
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("payingentity").setVisible(false);
							that.getView().byId("compcode").setVisible(true);
							that.getView().byId("compcode").getAggregation("label").setRequired(true);
							that.getView().byId("glaccount").setVisible(true);
							that.getView().byId("wbs").setVisible(true);
							that.getView().byId("wbs").getAggregation("label").setRequired(false);
							that.getView().byId("lob").setVisible(true);
							//REQ0737819:DPATEL11:FPDK900063:Batch-2:Adhoc lob/sublob changes: START
							that.getView().byId("input_lob").setValue("SPT - NETW")
							//that.getView().byId("input_lob").setSelectedKey("SPT - NETW");
							that.onChangeLOB();
							//REQ0737819:DPATEL11:FPDK900063:Batch-2:Adhoc lob/sublob changes : STOP
							that.getView().byId("sublob").setVisible(true);
							that.getView().byId("amount").setVisible(true);
							if ($.sap.eform_dsp !== undefined) {
								if (that.getView().byId("CURRENCY").getValue() === 'USD') {
									that.getView().byId("AMOUNT_USD").setVisible(false);
								} else {
									that.getView().byId("AMOUNT_USD").setVisible(true);
								}
							} else {
								that.getView().byId("CURRENCY").setValue("USD");
								that.getView().byId("AMOUNT_USD").setVisible(false);
							}

							that.getView().byId("invoice").setVisible(true);
							that.getView().byId("text_invoice").setPlaceholder("Invoice Description ");

							// Summary Tab Fields

							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("request_Desc_s").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("payingentity_s").setVisible(false);

							that.getView().byId("purpose_s").setVisible(true);
							that.getView().byId("instruction_s").setVisible(true);
							that.getView().byId("compcode_s").setVisible(true);
							that.getView().byId("compcode_s").getAggregation("label").setRequired(true);
							that.getView().byId("glaccount_s").setVisible(true);
							that.getView().byId("wbs_s").setVisible(true);
							that.getView().byId("amount_s").setVisible(true);
							that.getView().byId("invoice_s").setVisible(true);
							that.getView().byId("lob_s").setVisible(true);
							that.getView().byId("sublob_s").setVisible(true);

							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(true);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(true);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(true);
							that.getView().byId("stpn_fe_business_summary").setVisible(true);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(true);
							that.getView().byId("stpn_fe_formType_summary").setVisible(true);

						}
						//************************************************************************************************************
						//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
						//-------End of Change Description: Visibility of field for creating a new request
						//************************************************************************************************************
						else if (oSelectedItem.getTitle() === 'SPHE Media Budget Authorization') {
							that.flag = "C";
							that.getView().byId("request_Desc_s").setVisible(false);
							that.getView().byId("request_Desc").setVisible(false);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("purpose").setVisible(true);
							that.getView().byId("instruction").setVisible(true);
							that.getView().byId("dateneeded").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("lob").setVisible(false);
							that.getView().byId("sublob").setVisible(false);
							that.getView().byId("payingentity").setVisible(true);
							that.getView().byId("compcode").setVisible(false);
							that.getView().byId("glaccount").setVisible(false);
							that.getView().byId("wbs").setVisible(false);
							that.getView().byId("amount").setVisible(true);
							that.getView().byId("CURRENCY").setEnabled(true);
							that.getView().byId("AMOUNT_USD").setVisible(false);
							that.getView().byId("amount_s1").setVisible(false);
							that.getView().byId("invoice").setVisible(true);
							that.getView().byId("purpose_s").setVisible(true);
							that.getView().byId("instruction_s").setVisible(true);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("payingentity_s").setVisible(true);
							that.getView().byId("compcode_s").setVisible(false);
							that.getView().byId("glaccount_s").setVisible(false);
							that.getView().byId("wbs_s").setVisible(false);
							that.getView().byId("amount_s").setVisible(true);
							that.getView().byId("invoice_s").setVisible(true);
							that.getView().byId("lob_s").setVisible(false);
							that.getView().byId("sublob_s").setVisible(false);
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
						} else if (oSelectedItem.getTitle() === 'OPC Exception') {
							that.flag = "D";
							that.getView().byId("request_Desc_s").setVisible(true);
							that.getView().byId("request_Desc").setVisible(true);
							that.getView().byId("territory").setVisible(false);
							that.getView().byId("approver_Date").setVisible(false);
							that.getView().byId("customer_company").setVisible(false);
							that.getView().byId("territory_s").setVisible(false);
							that.getView().byId("approver_Date_s").setVisible(false);
							that.getView().byId("customer_company_s").setVisible(false);
							that.getView().byId("purpose").setVisible(false);
							that.getView().byId("instruction").setVisible(false);
							that.getView().byId("lob").setVisible(true);
							that.getView().byId("sublob").setVisible(true);
							that.getView().byId("dateneeded").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("payingentity").setVisible(false);
							that.getView().byId("compcode").setVisible(true);
							that.getView().byId("compcode").getAggregation("label").setRequired(false);
							that.getView().byId("glaccount").setVisible(false);
							that.getView().byId("wbs").setVisible(false);
							that.getView().byId("amount").setVisible(false);
							that.getView().byId("AMOUNT_USD").setVisible(false);
							that.getView().byId("invoice").setVisible(false);
							that.getView().byId("purpose_s").setVisible(false);
							that.getView().byId("instruction_s").setVisible(false);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("payingentity_s").setVisible(false);
							that.getView().byId("compcode_s").setVisible(true);
							that.getView().byId("compcode_s").getAggregation("label").setRequired(false);
							that.getView().byId("glaccount_s").setVisible(false);
							that.getView().byId("wbs_s").setVisible(false);
							that.getView().byId("amount_s").setVisible(false);
							that.getView().byId("invoice_s").setVisible(false);
							that.getView().byId("lob_s").setVisible(true);
							that.getView().byId("sublob_s").setVisible(true);
							that.getView().byId("amount_s1").setVisible(false);
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
						} else if (oSelectedItem.getTitle() === 'Japan TV Channels') {
							that.flag = "E";
							that.getView().byId("request_Desc_s").setVisible(true);
							that.getView().byId("request_Desc").setVisible(true);
							that.getView().byId("instruction_s").setVisible(false);
							that.getView().byId("purpose").setVisible(false);
							that.getView().byId("instruction").setVisible(false);
							that.getView().byId("lob").setVisible(true);
							that.getView().byId("sublob").setVisible(true);
							that.getView().byId("payingentity").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------Start of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("stpn_fe_ChargeDate").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor").setVisible(false);
							that.getView().byId("stpn_fe_or").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
							that.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
							that.getView().byId("stpn_fe_business_summary").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
							that.getView().byId("stpn_fe_formType_summary").setVisible(false);
							that.getView().byId("stpn_fe_business").setVisible(false);
							that.getView().byId("stpn_fe_purchaseType").setVisible(false);
							that.getView().byId("stpn_fe_formType").setVisible(false);
							//************************************************************************************************************
							//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
							//-------End of Change Description: Field Visibility Functionality
							//************************************************************************************************************
							that.getView().byId("compcode").setVisible(true);
							that.getView().byId("compcode").getAggregation("label").setRequired(false);
							that.getView().byId("territory").setVisible(true);
							that.getView().byId("approver_Date").setVisible(true);
							that.getView().byId("customer_company").setVisible(true);
							that.getView().byId("purpose_s").setVisible(false);
							that.getView().byId("dateneeded_s").setVisible(false);
							that.getView().byId("vendorname_s").setVisible(false);
							that.getView().byId("vendoradd_s").setVisible(false);
							that.getView().byId("glaccount_s").setVisible(false);
							that.getView().byId("wbs_s").setVisible(false);
							that.getView().byId("amount_s").setVisible(true);
							that.getView().byId("payingentity_s").setVisible(false);
							that.getView().byId("compcode_s").setVisible(true);
							that.getView().byId("compcode_s").getAggregation("label").setRequired(false);
							that.getView().byId("invoice_s").setVisible(false);
							that.getView().byId("lob_s").setVisible(true);
							that.getView().byId("sublob_s").setVisible(true);
							that.getView().byId("territory_s").setVisible(true);
							that.getView().byId("approver_Date_s").setVisible(true);
							that.getView().byId("customer_company_s").setVisible(true);
							that.getView().byId("glaccount").setVisible(false);
							that.getView().byId("wbs").setVisible(false);
							that.getView().byId("amount").setVisible(true);
							that.getView().byId("CURRENCY").setEnabled(true);

							if (that.getView().byId("CURRENCY").getValue() == "USD" && that.getView().byId("input_amount").getValue() == "") {
								that.getView().byId("CURRENCY").setValue("JPY");
								that._onCurrencyChange();
							}
							that.getView().byId("invoice").setVisible(false);
							that.getView().byId("dateneeded").setVisible(false);
							that.getView().byId("vendorname").setVisible(false);
							that.getView().byId("vendoradd").setVisible(false);
							that.getView().byId("fr_approve_by_date").setVisible(false);
							that.getView().byId("fr_company").setVisible(false);
							that.getView().byId("fr_lob").setVisible(false);
							that.getView().byId("fr_fiscalmonth").setVisible(false);
							that.getView().byId("fr_fiscalyear").setVisible(false);
							that.getView().byId("fr_doclinks").setVisible(false);
							that.getView().byId("fr_refdocs").setVisible(false);
							that.getView().byId("fr_approve_by_date_s").setVisible(false);
							that.getView().byId("fr_company_s").setVisible(false);
							that.getView().byId("fr_lob_s").setVisible(false);
							that.getView().byId("fr_fiscalmonth_s").setVisible(false);
							that.getView().byId("fr_fiscalyear_s").setVisible(false);
							that.getView().byId("fr_doclinks_s").setVisible(false);
							that.getView().byId("fr_refdocs_s").setVisible(false);
							that.getView().byId("fr_fin_req_type").setVisible(false);
							that.getView().byId("fr_fin_req_type_s").setVisible(false);
						}
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData");
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		_onPayingEntityValueHelpRequest: function () {
			var ccode = this.getView().byId("input_payingentity");
			var choosepayentity = i18ntext_bundle.getText("ChooseValueforPayingEntity(Company)");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosepayentity,
				items: {
					path: "/eFormCompanyCodes",
					template: new sap.m.StandardListItem({
						title: "{CODE}",
						description: "{TEXT}",
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"TEXT",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					that.byId('input_glaccount').setValue("");
					that.byId('input_wbs').setValue("");
					compCode = oEvent.getParameter("selectedItem").getTitle();
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						ccode.setValue(oSelectedItem.getTitle());
						ccode.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open(); // Opening value help dialog
			// once data is binded to
			// standard list item
		},
		_onPCFCostCenter_ValueHelp: function () {
			var cardholder;
			var reqType = this.getView().byId("input_RequestType").getValue();
			if (reqType === "SPTN ProCard Payment Request") {
				cardholder = this.getView().byId("stpn_ip_fundingDept");
				if (!compCode) {
					compCode = this.getView().byId("input_compcode").getValue();
					if (compCode.indexOf("(") !== -1) {
						compCode = compCode.split("(")[0];
					}
				}
			} else {
				cardholder = this.getView().byId("PCF_COST_CENTER");
				compCode = this.getView().byId("PCF_COMPANY_CODE").getValue();
			}

			var oFilter1 = [new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.EQ, compCode)];
			var vhTitle = (reqType === "SPTN ProCard Payment Request") ? i18ntext_bundle.getText("ChooseValueforFundingDept") : i18ntext_bundle
				.getText("ChooseValueforCostCenter");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({
				title: vhTitle,
				items: {
					path: "/eFormCostCenters",
					filters: oFilter1,
					template: new sap.m.StandardListItem({
						title: "{COSTCENTER}",
						description: "{NAME}",
						active: true
					})
				},
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"NAME",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					//  var oFilter2 = [new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.EQ, compCode)];
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						if (reqType === "SPTN ProCard Payment Request") {
							cardholder.setValue(oSelectedItem.getTitle() + " (" + oSelectedItem.getDescription() + ")");
						} else {
							cardholder.setValue(oSelectedItem.getTitle());
						}
						cardholder.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData");
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open();
		},
		_onPCFCompanyCodeValueHelpRequest: function () {
			var ccode = this.getView().byId("PCF_COMPANY_CODE");
			var choosevaluecompanycode = i18ntext_bundle.getText("ChooseValueforCompanyCode");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosevaluecompanycode,
				items: {
					path: "/eFormCompanyCodes",
					template: new sap.m.StandardListItem({
						title: "{CODE}",
						description: "{TEXT}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"TEXT",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						ccode.setValue(oSelectedItem.getTitle());
						ccode.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open(); // Opening value help dialog
			// once data is binded to
			// standard list item
		},
		_onCompanyCodeValueHelpRequest: function () {
			var ccode = this.getView().byId("input_compcode");
			var reqType = this.getView().byId("input_RequestType").getValue();
			var choosevaluecompanycode = i18ntext_bundle.getText("ChooseValueforCompanyCode");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosevaluecompanycode,
				items: {
					path: "/eFormCompanyCodes",
					template: new sap.m.StandardListItem({
						title: "{CODE}",
						description: "{TEXT}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"TEXT",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");

					if (oSelectedItem) {

						if (reqType === "SPTN ProCard Payment Request") {
							compCode = oEvent.getParameter("selectedItem").getTitle();
							ccode.setValue(oSelectedItem.getTitle() + " (" + oSelectedItem.getDescription() + ")");
						} else {
							ccode.setValue(oSelectedItem.getTitle());
						}
						ccode.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open(); // Opening value help dialog
			// once data is binded to
			// standard list item
		},
		_onCompanyValueHelpRequest: function () {
			var ccode = this.getView().byId("input_comp");
			var choosevalueforcompany = i18ntext_bundle.getText("ChooseValueforCompany");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosevalueforcompany,
				items: {
					path: "/eFormCompanyCodes",
					template: new sap.m.StandardListItem({
						title: "{CODE}",
						description: "{TEXT}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"TEXT",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						ccode.setValue(oSelectedItem.getTitle());
						ccode.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open(); // Opening value help dialog
			// once data is binded to
			// standard list item
		},
		_onWBSElementValueHelpRequest: function () {
			var wbs = this.getView().byId("input_wbs");
			var reqType = this.getView().byId("input_RequestType").getValue();
			var choosevalueforwbs = i18ntext_bundle.getText("ChooseValueforWBSElement");

			if (!compCode && reqType === "SPTN ProCard Payment Request") {
				compCode = this.getView().byId("input_compcode").getValue();
				if (compCode.indexOf("(") !== -1) {
					compCode = compCode.split("(")[0];
				}
			}

			if (reqType === "Production Accounting Payment Request") {
				compCode = this.getView().byId("input_payingentity").getValue();
			}

			var oFilter = [new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.EQ, compCode)];
			var oValueHelpDialog_WBSElement = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosevalueforwbs,
				items: {
					path: "/HWbselemSet",
					filters: oFilter,
					template: new sap.m.StandardListItem({
						title: "{Posid}",
						description: "{Post1}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"Post1",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						if (reqType === "SPTN ProCard Payment Request") {
							wbs.setValue(oSelectedItem.getTitle() + " (" + oSelectedItem.getDescription() + ")");
						} else {
							wbs.setValue(oSelectedItem.getTitle());
						}

						wbs.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_WBSElement.setModel(model);
			oValueHelpDialog_WBSElement.open(); // Opening value help dialog
			// once data is binded to
			// standard
		},
		_onGLAccountValueHelpRequest: function () {
			var glaccount = this.getView().byId("input_glaccount");
			var reqType = this.getView().byId("input_RequestType").getValue();

			compCode = this.getView().byId("input_compcode").getValue();
			if (compCode.indexOf(" (") !== -1) {
				compCode = compCode.split(" (")[0];
			}

			if (reqType === "Production Accounting Payment Request") {
				compCode = this.getView().byId("input_payingentity").getValue();
			}

			var choosevalueforGL = i18ntext_bundle.getText("ChooseValueforGLAccount");
			var oFilter = [new sap.ui.model.Filter("BUKRS", sap.ui.model.FilterOperator.EQ, compCode)];
			var oValueHelpDialog_GLAccount = new sap.m.SelectDialog({ // Using
				// SelectDialog
				// control
				// that
				// will
				// allow
				// single
				// selection
				// along
				// with
				// Search
				// field
				// capability
				title: choosevalueforGL,
				items: {
					path: "/FisshSaknrGenericSet",
					filters: oFilter,
					template: new sap.m.StandardListItem({
						title: "{Saknr}",
						description: "{Txt50}",
						active: true
					})
				},
				// Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"Txt50",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						if (reqType === "SPTN ProCard Payment Request") {
							glaccount.setValue(oSelectedItem.getTitle() + " (" + oSelectedItem.getDescription() + ")");
						} else {
							glaccount.setValue(oSelectedItem.getTitle());
						}
						glaccount.setValueState("None");
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData"); // Setting
			// oServiceModel
			// defined in
			// Copmponent.js
			// to this value
			// help dialog
			oValueHelpDialog_GLAccount.setModel(model);
			oValueHelpDialog_GLAccount.open(); // Opening value help dialog
			// once data is binded to
			// standard
		},
		_onLiveChange_Title: function () {
			if (this.getView().byId("input_title").getValue() === "") {
				this.getView().byId("input_title").setValueState("Error");
				this.getView().byId("input_title").setValueStateText("(Required)");
			} else {
				this.getView().byId("input_title").setValueState("None");
			}
		},
		_onLiveChange_Purpose: function () {
			if (this.getView().byId("text_purpose").getValue() === "") {
				this.getView().byId("text_purpose").setValueState("Error");
				this.getView().byId("text_purpose").setValueStateText("(Required)");
			} else {
				this.getView().byId("text_purpose").setValueState("None");
			}
		},
		_onLiveChange_Inst: function () {
			if (this.getView().byId("text_instruction").getValue() === "") {
				this.getView().byId("text_instruction").setValueState("Error");
				this.getView().byId("text_instruction").setValueStateText("(Required)");
			} else {
				this.getView().byId("text_instruction").setValueState("None");
			}
		},
		_onLiveChange_Vendor: function () {
			if (this.getView().byId("input_VendorName").getValue() === "") {
				this.getView().byId("input_VendorName").setValueState("Error");
				this.getView().byId("input_VendorName").setValueStateText("(Required)");
			} else {
				this.getView().byId("input_VendorName").setValueState("None");
			}
		},
		_onLiveChange_VendorAdd: function () {
			if (this.getView().byId("text_address").getValue() === "") {
				this.getView().byId("text_address").setValueState("Error");
				this.getView().byId("text_address").setValueStateText("(Required)");
			} else {
				this.getView().byId("text_address").setValueState("None");
			}
		},
		_onLiveChange_Amount: function (oEvent) {
			if (this.getView().byId("input_amount").getValue() === "") {
				this.getView().byId("input_amount").setValueState("Error");
				this.getView().byId("input_amount").setValueStateText("(Required)");
			} else {
				var sAmount = oEvent.getParameter("value");
				var a = sAmount.split(',').join('');
				var str1;
				var str2;
				var regx = /[^0-9]/g;
				var res = regx.test(a);
				if (res === false) {
					var totalUsd = new Intl.NumberFormat('en-US').format(a);
					this.getView().byId("input_amount").setValue(totalUsd);
				} else {
					var result = a.match(regx);
					var substr = a.replace(result, '');
					var totalUsd;
					if (a.indexOf(".") !== -1) {
						var index = a.indexOf(".");
						str1 = a.substr(0, index);
						str2 = a.substr(index);
						var result1 = str1.match(regx);
						if (result1 !== null) {
							str1.replace(result1, '');
						}
						var result2 = str2.match(regx);
						if (result2[0] === "." && result2[1] !== null) {
							str2.replace(result2[1], '');
						}
						totalUsd = new Intl.NumberFormat('en-US').format(str1);
						totalUsd = totalUsd + str2;
					} else {
						totalUsd = new Intl.NumberFormat('en-US').format(substr);
					}
					this.getView().byId("input_amount").setValue(totalUsd);
				}
				this.getView().byId("input_amount").setValueState("None");
			}
		},
		_onLiveChange_dateNeeded: function () {
			if (this.getView().byId("DP2").getValue() === "") {
				this.getView().byId("DP2").setValueState("Error");
				this.getView().byId("DP2").setValueStateText("(Required)");
			} else {
				this.getView().byId("DP2").setValueState("None");
			}
		},
		_onLiveChange_InvoiceDesc: function () {
			if (this.getView().byId("text_invoice").getValue() === "") {
				this.getView().byId("text_invoice").setValueState("Error");
				this.getView().byId("text_invoice").setValueStateText("(Required)");
			} else {
				this.getView().byId("text_invoice").setValueState("None");
			}
		},
		_onLiveChange_CardHolderName: function () {
			if (this.getView().byId("input_cardholdername").getValue() === "") {
				this.getView().byId("input_cardholdername").setValueState("Error");
				this.getView().byId("input_cardholdername").setValueStateText("(Required)");
			} else {
				this.getView().byId("input_cardholdername").setValueState("None");
			}
		},
		_onLiveChange_Desc: function () {
			if (this.getView().byId("text_desc").getValue() === "") {
				this.getView().byId("text_desc").setValueState("Error");
				this.getView().byId("text_desc").setValueStateText("(Required)");
			} else {
				this.getView().byId("text_desc").setValueState("None");
			}
		},
		_onLiveChange_Dept: function () {
			if (this.getView().byId("input_department").getValue() === "") {
				this.getView().byId("input_department").setValueState("Error");
				this.getView().byId("input_department").setValueStateText("(Required)");
			} else {
				this.getView().byId("input_department").setValueState("None");
			}
		},
		_onLiveChange_Phone: function () {
			if (this.getView().byId("input_business_phone").getValue() === "") {
				this.getView().byId("input_business_phone").setValueState("Error");
				this.getView().byId("input_business_phone").setValueStateText("(Required)");
			} else {
				this.getView().byId("input_business_phone").setValueState("None");
			}
		},
		_onLiveChange_EmpTitle: function () {
			if (this.getView().byId("input_employee_title").getValue() === "") {
				this.getView().byId("input_employee_title").setValueState("Error");
				this.getView().byId("input_employee_title").setValueStateText("(Required)");
			} else {
				this.getView().byId("input_employee_title").setValueState("None");
			}
		},
		_onLiveChange_CheckBox: function () {
			if (this.getView().byId("tnc_check").getSelected() === false) {
				this.getView().byId("tnc_check").setValueState("Error");
			} else {
				this.getView().byId("tnc_check").setValueState("None");
			}
		},
		_onApproverHelpRequest: function (oEvent) {
			var input_1 = oEvent.getSource();
			var choosevalueapprover = i18ntext_bundle.getText("ChooseValueforApprover");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({
				title: choosevalueapprover,
				items: {
					path: "/eFormProductionAccts",
					template: new sap.m.StandardListItem({
						title: "{USERID}",
						description: "{NAME}",
						active: true
					})
				},
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"NAME",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						input_1.setValue(oSelectedItem.getDescription());
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData");
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open();
		},
		onAfterRendering: function () {
			// this.initialTableRecord();
		},
		initialTableRecord: function () {
			var table = this.byId('approver_table');
			var data = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Text({
						text: ""
					}),
					new sap.m.Input({
						showValueHelp: Boolean("true"),
						valueHelpOnly: Boolean("true"),
						id: "approver" + index_counter,
						valueHelpRequest: [this._onApproverHelpRequest, this]
					}),
					new sap.m.Select({
						items: [
							new sap.ui.core.Item({
								text: "Watcher"
							}),
							new sap.ui.core.Item({
								text: "Approver"
							})
						]
					}),
					new sap.m.Text({
						text: ""
					}),
					new sap.m.Text({
						text: ""
					}),
					new sap.m.Text({
						text: ""
					}),
					new sap.m.CheckBox({
						editable: false,
						selected: true
					}),
					new sap.m.Text({
						text: logger_name
					}),
					new sap.m.Text({
						text: ""
					})
				]
			});
			table.addItem(data);
		},
		_add_approver: function () {
			var selectedType = this.byId('REVIEWER_TYPE').getValue();
			var table = this.getView().byId("approver_table");
			var all_entries = table.getItems();
			index_counter = index_counter + 1;
			var num_of_entries = table.getItems().length;
			if (num_of_entries > -1) {
				this.byId('txtPosition').setProperty('visible', true);
				this.byId('ENTRY_SEQUENCE').setProperty('visible', true);
			}
			if (num_of_entries === 0) {
				var that = this;
				var data = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							editable: false
						}),
						new sap.m.Input({
							showValueHelp: Boolean("true"),
							valueHelpOnly: Boolean("true"),
							id: "approver" + index_counter,
							valueHelpRequest: [that._onApproverHelpRequest, that]
						}),
						new sap.m.Text({
							text: selectedType
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.Text({
							text: ""
						}),
						new sap.m.CheckBox({
							editable: false,
							selected: true
						}).data("Flag", "X"),
						new sap.m.Text({
							text: logger_name
						}),
						new sap.m.Text({
							text: ""
						})
					]
				});
				table.addItem(data);
			} else {
				var selected_item = this.getView().byId("approver_table").getSelectedItem();
				if (selected_item.mAggregations.cells[1].mProperties.value == "EMD Clerk" && this.getView().byId("ENTRY_SEQUENCE").getValue() ==
					"After" && table.indexOfItem(selected_item) != "0") {
					var addapproverafetremd = i18ntext_bundle.getText("YoucannotaddApprovers/WatchersafterEMDClerk");
					MessageBox.alert(addapproverafetremd);
					return;
				}
				if (selected_item.mAggregations.cells[2].mProperties.text == "Watcher" && this.getView().byId("ENTRY_SEQUENCE").getValue() ==
					"Before" && table.indexOfItem(selected_item) == "0" && selected_item.mAggregations.cells[6].mProperties.selected != true) {
					var addapproverbeforefirst = i18ntext_bundle.getText("YoucannotaddApprovers/Watchersbeforefirstwatcher");
					MessageBox.alert(addapproverbeforefirst);
					return;
				}
				if (selected_item.mAggregations.cells[0].mProperties.text == "" || this.getView().byId("ENTRY_SEQUENCE").getValue() ==
					"After") {
					if (this.getView().byId("ENTRY_SEQUENCE").getValue() == "After") {
						var index = table.indexOfItem(selected_item) + 1;
					} else {
						if (table.indexOfItem(selected_item) > 0) {
							var index = table.indexOfItem(selected_item);
							if (index == 0) {
								index = 1;
							}
						} else {
							index = 0;
						}
					}
					table.removeAllItems();
					var counter = 0;
					var x = 1;
					var that = this;
					for (counter = 0; counter < num_of_entries; counter++) {
						x = x + 1;
						if (counter == index) {
							var data = new sap.m.ColumnListItem({
								cells: [
									new sap.m.Text({

									}),
									new sap.m.Input({
										showValueHelp: Boolean("true"),
										valueHelpOnly: Boolean("true"),
										id: "approver" + index_counter,
										valueHelpRequest: [that._onApproverHelpRequest, that]
									}),
									new sap.m.Text({
										text: this.getView().byId("REVIEWER_TYPE").getValue()
									}),
									new sap.m.Text({
										text: ""
									}),
									new sap.m.Text({
										text: ""
									}),
									new sap.m.Text({
										text: ""
									}),
									new sap.m.CheckBox({
										editable: false,
										selected: true
									}).data("Flag", "X"),
									new sap.m.Text({
										text: logger_name
									}),
									new sap.m.Text({
										text: ""
									})
								]
							});
							table.addItem(data);
						}
						table.addItem(all_entries[counter]);
						if (counter === (num_of_entries - 1) && (index === num_of_entries)) {
							var data = new sap.m.ColumnListItem({
								cells: [
									new sap.m.Text({

									}),
									new sap.m.Input({
										showValueHelp: Boolean("true"),
										valueHelpOnly: Boolean("true"),
										id: "approver2" + index_counter,
										valueHelpRequest: [that._onApproverHelpRequest, that]
									}),
									new sap.m.Text({
										text: this.getView().byId("REVIEWER_TYPE").getValue()
									}),
									new sap.m.Text({
										text: ""
									}),
									new sap.m.Text({
										text: ""
									}),
									new sap.m.Text({
										text: ""
									}),
									new sap.m.CheckBox({
										editable: false,
										selected: true
									}).data("Flag", "X"),
									new sap.m.Text({
										text: logger_name
									}),
									new sap.m.Text({
										text: ""
									})
								]
							});
							table.addItem(data);
						}
					}
				} else {
					var cannotaddbeforeapproved = i18ntext_bundle.getText("YoucannotaddApprovers/WatchersbeforeanApprovedItem");
					MessageBox.alert(cannotaddbeforeapproved);
				}
			}
		},
		_onRefreshApprovers: function (oEvent) {
			if (e_form_num != "") {
				var model = this.getOwnerComponent().getModel("oData");
				var relPath = "/eFormApprovers";
				var that1 = this;
				var oFilter = new sap.ui.model.Filter(
					"EFORM_NUM",
					sap.ui.model.FilterOperator.EQ, e_form_num
				);
				var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
				model.read(relPath, {
					filters: [oFilter],
					success: function (oData, response) {
						var counter = oData.results.length;
						var i = 0;
						var oMod = that1.getView().getModel();
						var apRows = oMod.getProperty("/approvers");
						var no_of_items = apRows.length;
						var t = no_of_items - 1;
						for (i = t; i >= 0; i--) {
							apRows.splice(i, 1);
						}
						oMod.setProperty("/approvers", apRows);
						// oTable.destroyItems();
						for (i = 0; i < counter; i++) {
							if (oData.results[i].APPROVED === "X") {
								oData.results[i].APPROVED = oBundle.getText("Approved");
							} else if (oData.results[i].APPROVED === "R") {
								oData.results[i].APPROVED = oBundle.getText("Rejected");
							}
							var item = {
								approved: oData.results[i].APPROVED,
								approver: oData.results[i].APPR,
								reviewer_type: oData.results[i].REVIEWER_TYPE,
								approved_by: oData.results[i].APPROVED_BY,
								approval_date: oData.results[i].APPROVAL_DT,
								approval_time: oData.results[i].APPROVAL_TM,
								manual_addition: oData.results[i].MANUAL,
								added_by: oData.results[i].ADDED_BY,
								added_on: oData.results[i].CREATION_DT,
								can_edit: Boolean(0)
							};
							apRows.push(item);
						}
						oMod.setProperty("/approvers", apRows);
					},
					error: function (oError) {
						var response = JSON.parse(oError.responseText);
						MessageBox.show(
							response.error.message.value,
							MessageBox.Icon.ERROR,
							"Error"
						);
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		},
		_delete_approver: function () {
			var table = this.getView().byId("approver_table");
			var deleteOne = this.getView().getModel("i18n").getResourceBundle().getText("addOneItem");
			if (table.getItems().length === 0) {
				this.byId('txtPosition').setProperty('visible', false);
				this.byId('ENTRY_SEQUENCE').setProperty('visible', false);
				this.getView().getModel("viewData").getProperty("/Footval").Msg = deleteOne;
				this.getView().getModel("viewData").getProperty("/Footval").FieldName = "";
				// this.getView().byId("ValidateButton").setVisible(true);
				return;
			}
			if (table.getSelectedItems().length === 0) {
				var pleaseselectitemdelete = i18ntext_bundle.getText("Pleaseselectatleastoneitemtodelete");
				var error = i18ntext_bundle.getText("Error");
				MessageBox.show(pleaseselectitemdelete, {
					title: error,
					icon: sap.m.MessageBox.Icon.ERROR,
				});
				return;
			}
			var selected_item = this.getView().byId("approver_table").getSelectedItem();
			// deleting mannually added items
			if (selected_item.mAggregations.cells[0].mProperties.text == "" && selected_item.mAggregations.cells[6].mProperties.selected ==
				true) {
				if (selected_item.mAggregations.cells[7].mProperties.text === logger_name) {
					table.removeItem(selected_item);
				} else {
					var youcanonlydeleteapproversaddedbyyou = i18ntext_bundle.getText("Youcanonlydeleteapproversaddedbyyou");
					MessageBox.alert(youcanonlydeleteapproversaddedbyyou);
				}
				if (table.getItems().length === 0) {
					this.byId('txtPosition').setProperty('visible', false);
					this.byId('ENTRY_SEQUENCE').setProperty('visible', false);
				}
			} else {

				if (selected_item.mAggregations.cells[0].mProperties.text == "Approved") {
					var youcannotdeleteapproverapproved = i18ntext_bundle.getText("Youcannotdeletetheapproversinceitisalreadyapproved");
					MessageBox.alert(youcannotdeleteapproverapproved);
					return;
				}

				if (this.getView().byId("input_RequestType").getValue() === "SPTN ProCard Payment Request" && selected_item.mAggregations.cells[6]
					.mProperties.selected ==
					false) {
					var youcannotdeletederivedapprovers = i18ntext_bundle.getText("youcannotdeletederivedapprovers");
					MessageBox.alert(youcannotdeletederivedapprovers);
					return;
				}
			}
		},
		_onSaveComment: function (oEvent) {
			var c = {};
			var oModel = this.getOwnerComponent().getModel("oData");
			c.FORM_NO = e_form_num;
			c.FORMNAME = "AAF";
			if (oEvent.getSource().getId().includes("save_cmnt")) {
				c.COMMENTS = this.getView().byId("textarea_comments").getValue();
				this.getView().byId("textarea_comments").setValue('');
			} else {
				c.COMMENTS = this.getView().byId("textarea_comments2").getValue();
				this.getView().byId("textarea_comments2").setValue('');
			}
			c.SEQUENCE = "";
			c.CREATOR = "";
			c.CR_DATE = "";
			c.TIME = "";
			c.ACTION = "";
			var that = this;
			if (c.COMMENTS == "") {
				var pleaseenterthecomment = i18ntext_bundle.getText("Pleaseenterthecomment");
				MessageBox.alert(pleaseenterthecomment);
				return;
			}
			oModel.create("/eFormComments", c, {
				async: false,
				success: function (oData, response) {
					e_form_num = oData.FORM_NO;
					var msg1 = e_form_num;
					var oResourceModel = that.getView().getModel("i18n").getResourceBundle();
					var oText = oResourceModel.getText("AdhocApprovableForm", [msg1]);
					that.getView().byId("page").setText(oText);
					var commentaddedsuccessfully = i18ntext_bundle.getText("Commentaddedsuccessfully");
					var msg = commentaddedsuccessfully;
					MessageBox.show(
						msg,
						MessageBox.Icon.SUCCESS
					);
					sap.ui.core.BusyIndicator.hide();
					var relPath = "/eFormComments";
					var oModel = that.getOwnerComponent().getModel("oData");
					var oFilter = new sap.ui.model.Filter(
						"FORM_NO",
						sap.ui.model.FilterOperator.EQ, e_form_num
					);
					oModel.read(relPath, {
						filters: [oFilter],
						success: function (oData, response) {
							that.getView().byId("t_comment1").destroyItems();
							var counter = oData.results.length;
							var i = 0;
							for (i = 0; i < counter; i++) {
								var table = that.getView().byId("t_comment1");
								var vedit = oData.results[i].EDIT;
								if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
									vedit = Boolean(0);
								}
								var data = new sap.m.ColumnListItem({
									cells: [
										new sap.m.Text({
											text: oData.results[i].SEQUENCE
										}),
										new sap.m.TextArea({
											value: oData.results[i].COMMENTS,
											rows: 2,
											cols: 70,
											enabled: vedit
										}),
										new sap.m.Text({
											text: oData.results[i].CREATOR
										}),
										new sap.m.Text({
											text: oData.results[i].CR_DATE
										})
									]
								})
								table.addItem(data);
							} // for
							that.getView().byId("t_comment2").destroyItems();
							var counter = oData.results.length;
							var i = 0;
							for (i = 0; i < counter; i++) {
								var table = that.getView().byId("t_comment2");
								var vedit = oData.results[i].EDIT;
								if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
									vedit = Boolean(0);
								}
								var data = new sap.m.ColumnListItem({
									cells: [
										new sap.m.Text({
											text: oData.results[i].SEQUENCE
										}),
										new sap.m.TextArea({
											value: oData.results[i].COMMENTS,
											rows: 2,
											cols: 70,
											enabled: vedit
										}),
										new sap.m.Text({
											text: oData.results[i].CREATOR
										}),
										new sap.m.Text({
											text: oData.results[i].CR_DATE
										})
									]
								})
								table.addItem(data);
							}
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onClearCommentsPress: function () {
			this.getView().byId("textarea_comments").setValue("");
		},
		_onClearCommentsPress2: function () {
			this.getView().byId("textarea_comments2").setValue("");
		},
		_onhandleValueChange: function (oEvent) {
			file_size = oEvent.getParameters().files[0].size;
			file_size = (file_size / 1024);
		},
		_onPressDeleteAttachment: function (oEvent) {
			var model = this.getOwnerComponent().getModel("oData");
			if (oEvent.getSource().getId().includes("button_delete_attachment"))
				var selected_item = this.getView().byId("t_attachment1").getSelectedItem();
			else
				var selected_item = this.getView().byId("t_attachment2").getSelectedItem();
			if (selected_item === null) {
				var pleaseselectanyattachmenttodelete = i18ntext_bundle.getText("Pleaseselectanyattachmenttodelete");
				var noattachmentselected = i18ntext_bundle.getText("NoAttachemntSelected");
				MessageBox.show(
					pleaseselectanyattachmenttodelete,
					MessageBox.Icon.Error,
					noattachmentselected)
			} else {
				var filename = selected_item.getCells()[0].getText();
				if (filename !== "") {
					// if (logger_name == this.getView().byId("text_Preparer").getText()
					// ||
					// logger_name ==
					// this.getView().byId("input_on_behalf_of").getValue())
					// {
					// var that = this;
					// var attachmentdeletedsuccesfully =
					// i18ntext_bundle.getText("Attachmentdeletedsuccessfully");
					// model.read("/eFormAttachments(EFORM_NUM='" + e_form_num + "'" +
					// ",FILE_NAME='" + filename + "')", {
					// success: function(oData, response) {
					// that.getView().byId("t_attachment1").removeItem(selected_item);
					// that.getView().byId("t_attachment2").removeItem(selected_item);
					// that.fillAttachments(that);
					// MessageBox.alert(attachmentdeletedsuccesfully);
					// },
					// error: function(oError) {
					// var response = JSON.parse(oError.responseText);
					// MessageBox.show(
					// response.error.message.value,
					// MessageBox.Icon.ERROR,
					// "Error"
					// );
					// sap.ui.core.BusyIndicator.hide();
					// }
					// });
					// }
					// else
					if (logger_name == selected_item.getCells()[4].getText()) {
						var that = this;
						var attachmentdeletedsuccesfully = i18ntext_bundle.getText("Attachmentdeletedsuccessfully");
						//add remove method to delete attachemnet instead of read call by nsoni on 10/07/2020
						// model.read("/eFormAttachments(EFORM_NUM='" + e_form_num + "'" + ",FILE_NAME='" + filename + "')", {
						model.remove("/eFormAttachments(EFORM_NUM='" + e_form_num + "'" + ",FILE_NAME='" + filename + "')", {
							method: "DELETE",
							success: function (oData, response) {
								that.getView().byId("t_attachment1").removeItem(selected_item);
								that.getView().byId("t_attachment2").removeItem(selected_item);
								that.fillAttachments(that);
								MessageBox.alert(attachmentdeletedsuccesfully);
							},
							error: function (oError) {
								var response = JSON.parse(oError.responseText);
								MessageBox.show(
									response.error.message.value,
									MessageBox.Icon.ERROR,
									"Error"
								);
								sap.ui.core.BusyIndicator.hide();
							}
						});
					} else {
						var youcannotdeletethisattachment = i18ntext_bundle.getText("Youcannotdeletethisattachment");
						MessageBox.alert(youcannotdeletethisattachment);
					}
				}
			}
		},
		_onhandleUploadPress: function (oEvent) {
			if (oEvent.mParameters.id.toLowerCase().indexOf("b_upload1") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploader1");
				if (oFileUploader.getValue() == "") {
					var pleaseselectthefile = i18ntext_bundle.getText("Pleaseselectthefile");
					MessageBox.alert(pleaseselectthefile);
					return;
				}
			}
			if (oEvent.mParameters.id.toLowerCase().indexOf("b_upload2") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploader2");
				if (oFileUploader.getValue() == "") {
					var pleaseselectthefile = i18ntext_bundle.getText("Pleaseselectthefile");
					MessageBox.alert(pleaseselectthefile);
					return;
				}
			}
			var userModel = this.getOwnerComponent().getModel("oData");
			var viewInstance = this.getView();
			if (oFileUploader.getName() == "") {
				return;
			}
			viewInstance.setBusy(true);
			// Set CSRF
			userModel.refreshSecurityToken();
			var csrf = userModel.getSecurityToken();
			// Add to header and upload
			oFileUploader.destroyHeaderParameters();
			oFileUploader.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			var headerParma2 = new sap.ui.unified.FileUploaderParameter();
			var headerParma3 = new sap.ui.unified.FileUploaderParameter();
			headerParma2.setName('slug');
			headerParma2.setValue(encodeURIComponent(oFileUploader.getValue() + '|' + e_form_num + '|' + file_size + '|' + 'AAF'));
			oFileUploader.insertHeaderParameter(headerParma2);
			headerParma3.setName('Content-Type');
			headerParma3.setValue('image/jpeg');
			oFileUploader.insertHeaderParameter(headerParma3);
			headerParma.setName('x-csrf-token');
			headerParma.setValue(csrf);
			oFileUploader.addHeaderParameter(headerParma);
			oFileUploader.upload();
		},
		_onhandleUploadComplete: function (oEvent) {
			var status = oEvent.getParameter("status");
			if (status === 201) {
				var uploadsuccess = i18ntext_bundle.getText("UploadSuccess");
				var sMsg = uploadsuccess;
				var attachmentuploadedsuccessfully = i18ntext_bundle.getText("AttachmentUploadedSuccessfully");
				oEvent.getSource().setValue("");
				MessageBox.show(
					attachmentuploadedsuccessfully,
					MessageBox.Icon.SUCCESS,
					sMsg)
			} else {
				var uploaderror = i18ntext_bundle.getText("UploadError");
				var erroruploadingattachment = i18ntext_bundle.getText("ErrorUploadingAttachment");
				sMsg = uploaderror;
				MessageBox.show(
					erroruploadingattachment,
					MessageBox.Icon.ERROR,
					sMsg
				)
			}
			var temp = oEvent.getParameter("response");
			// S4R:PJAIN6:GWDK902384:08/05/2021:EFORM_NUM ISSUE:START
			// e_form_num = temp.slice(115, 125);
			// var start=temp.search("AAF");
			e_form_num = temp.substr(temp.indexOf("EFORM_NUM='") + 11, 10);
			// S4R:PJAIN6:GWDK902384:08/05/2021:EFORM_NUM ISSUE:END
			
			var oResourceModel = this.getView().getModel("i18n").getResourceBundle();
			var oText = oResourceModel.getText("AdhocApprovableForm", e_form_num);
			this.getView().byId("page").setText(oText);
			var viewInstance = this.getView();
			viewInstance.setBusy(false);
			var oModel = this.getOwnerComponent().getModel("oData");
			var relPath = "/eFormAttachments";
			var that = this;
			var oFilter = new sap.ui.model.Filter(
				"EFORM_NUM",
				sap.ui.model.FilterOperator.EQ, e_form_num
			);
			oModel.read(relPath, {
				filters: [oFilter],
				success: function (oData, response) {
					that.getView().byId("t_attachment1").destroyItems();
					that.getView().byId("t_attachment2").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table1 = that.getView().byId("t_attachment1");
						var table2 = that.getView().byId("t_attachment2");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									wrapping: Boolean(1),
									press: function (event) {
										var that2 = that;
										var oSource = event.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/eFormAttachments(EFORM_NUM='" + e_form_num + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATED_BY
								}),
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
								new sap.m.CheckBox({
									visible: that.getView().getModel().getProperty("/ATTACHMENT_CHECKBOXES"),
									selected: function () {
										if (response.data.results[i].ATTACH === 'X') {
											checkboxSelectedCounter1++;
										}
										return response.data.results[i].ATTACH;
									}.call() === '' ? false : true,
									select: function (event) {
										var oSource = event.getSource();
										var isSelectedOrNot = this.getSelected();
										if (isSelectedOrNot === true) {
											if (checkboxSelectedCounter1 > 0) {
												MessageBox.alert("Please choose only one attachment.");
												this.setSelected(false);
												return;
											} else {
												checkboxSelectedCounter1++;
											}
										}
										if (isSelectedOrNot == false) {
											checkboxSelectedCounter1--;
										}
										var attach_value = isSelectedOrNot === false ? "" : "X";
										var c = {};
										var file_Name = response.data.results[oSource.data("rowID")].FILE_NAME;
										// 										c.EFORM_NUM = e_form_num;
										c.FILE_NAME = file_Name;
										c.ATTACH = attach_value; //eFormAttachments
										oModel.update("/eFormAttachments(EFORM_NUM='" + e_form_num + "',FILE_NAME='" + file_Name + "')", c, null, {
											async: false,
											success: function (oData, response) {
												console.log("Success to create call in eFormAttachments entity set");
											},
											error: function (oError) {
												var response = JSON.parse(oError.responseText);
												MessageBox.show(
													response.error.message.value,
													MessageBox.Icon.ERROR,
													"Error"
												);
												sap.ui.core.BusyIndicator.hide();
											}
										});
									}
								}).data("rowID", i)
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
							]
						});
						var data2 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									wrapping: Boolean(1),
									press: function (event) {
										var that2 = that;
										var oSource = event.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIPFRDD0022_ADHOC_EFORM_SRV/eFormAttachments(EFORM_NUM='" + e_form_num + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATED_BY
								}),
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
								new sap.m.CheckBox({
									visible: that.getView().getModel().getProperty("/ATTACHMENT_CHECKBOXES"),
									selected: function () {
										if (response.data.results[i].ATTACH === 'X') {
											checkboxSelectedCounter2++;
										}
										return response.data.results[i].ATTACH;
									}.call() === '' ? false : true,
									select: function (event) {
										var oSource = event.getSource();
										var isSelectedOrNot = this.getSelected();
										if (isSelectedOrNot === true) {
											if (checkboxSelectedCounter2 > 0) {
												MessageBox.alert("Please choose only one attachment.");
												this.setSelected(false);
												return;
											} else {
												checkboxSelectedCounter2++;
											}
										}
										if (isSelectedOrNot == false) {
											checkboxSelectedCounter2--;
										}
										var attach_value = isSelectedOrNot === false ? "" : "X";
										var c = {};
										var file_Name = response.data.results[oSource.data("rowID")].FILE_NAME;
										// 										c.EFORM_NUM = e_form_num;
										c.FILE_NAME = file_Name;
										c.ATTACH = attach_value; //eFormAttachments
										oModel.update("/eFormAttachments(EFORM_NUM='" + e_form_num + "',FILE_NAME='" + file_Name + "')", c, null, {
											async: false,
											success: function (oData, response) {
												console.log("Success to create call in eFormAttachments entity set");
											},
											error: function (oError) {
												var response = JSON.parse(oError.responseText);
												MessageBox.show(
													response.error.message.value,
													MessageBox.Icon.ERROR,
													"Error"
												);
												sap.ui.core.BusyIndicator.hide();
											}
										});
									}
								}).data("rowID", i)
								//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
							]
						});
						table1.addItem(data1);
						table2.addItem(data2);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onCardholder_ValueHelp: function () {
			var cardholder = this.getView().byId("cardholder_name");
			var choosevalueforcardholderof = i18ntext_bundle.getText("ChooseValueforCardholderOf");
			var oValueHelpDialog_CardHolderName = new sap.m.SelectDialog({
				title: choosevalueforcardholderof,
				items: {
					path: "/eFormProductionAccts",
					template: new sap.m.StandardListItem({
						title: "{USERID}",
						description: "{NAME}",
						active: true
					})
				},
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"NAME",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},
				// On click of Confirm, value is set to input field
				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						cardholder.setValue(oSelectedItem.getDescription());
					}
				}
			});
			var model = this.getOwnerComponent().getModel("oData");
			oValueHelpDialog_CardHolderName.setModel(model);
			oValueHelpDialog_CardHolderName.open();
		},
		_onFinalSavePress: function () {
			button_press = 'Save';
			var msgflag;
			var title = this.getView().byId("input_title");
			var dateNeeded = this.getView().byId('DP2');
			var desc = this.getView().byId("text_desc");
			var onbehalfof = this.getView().byId("input_on_behalf_of");
			var phone = this.getView().byId("input_business_phone");
			var email = this.getView().byId("input_emailid");
			var req_type = this.getView().byId("input_RequestType");
			var purpose = this.getView().byId("text_purpose");
			var inst = this.getView().byId("text_instruction");
			var vendorname = this.getView().byId("input_VendorName");
			var vendoradd = this.getView().byId("text_address");
			var payingentity = this.getView().byId("input_payingentity");
			var glaccount = this.getView().byId("input_glaccount");
			var wbs = this.getView().byId("input_wbs");
			var amount = this.getView().byId("input_amount");
			var invoice = this.getView().byId("text_invoice");
			var apprTable = this.byId('approver_table');
			var lob = this.byId('input_lob');
			var sublob = this.byId('input_sublob');
			var territory = this.byId('oSelectCountry');
			var approver_Date = this.byId('date_Approver');
			var customer_Company = this.byId('inpCustomer');
			var fr_approve_by_date = this.byId('AppDP');
			var fr_comp_code = this.byId('input_comp');
			var fr_lob = this.byId('fr_cmb_lob');
			var fr_fis_month = this.byId('fr_fis_month');
			var fr_fis_year = this.byId('fr_fis_year');
			var fr_doc_link = this.byId('input_frdoclinks');
			var fr_refdocs = this.byId('fr_text_refdocs');
			var fin_req_type = this.byId('fin_req_type');
			var pleaseentermandatoryparameter = i18ntext_bundle.getText("PleaseEnterMandatoryParameters");
			var requiredFields = pleaseentermandatoryparameter;

			/*<Request Number:REQ034679><Dt: 14.10.2018><Start of>*/

			// if (req_type.getValue() === "") {
			//  sap.m.MessageBox.show("Please select a request type to Proceed.", {
			//      title: error,
			//      icon: sap.m.MessageBox.Icon.ERROR,
			//    });
			//    return;
			// }
			/*<Request Number:REQ034679><Dt: 14.10.2018><End of>*/

			if (req_type.getValue() === "Japan TV Channels") {
				this.flag = "E";
			}
			if (req_type.getValue() === "OPC Exception") {
				this.flag = "D";
			}
			if (req_type.getValue() === "Finance Request Form") {
				this.flag = "FR";
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Adding SPTN ProCard Payment Request to the condition
			//************************************************************************************************************

			if (req_type.getValue() === "SPTN ProCard Payment Request") {
				this.flag = "STPN";
			}
			if (this.flag !== "E" && this.flag !== "D" && this.flag !== "STPN") {
				//************************************************************************************************************
				//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
				//-------End of Change Description: Adding SPTN ProCard Payment Request to the condition
				//************************************************************************************************************
				if (apprTable.getItems().length === 0) {
					var pleaseentermanualapprovertoproceed = i18ntext_bundle.getText("Pleaseenteratleastonemanualapprovertoproceed");
					var error = i18ntext_bundle.getText("Error");
					sap.m.MessageBox.show(pleaseentermanualapprovertoproceed, {
						title: error,
						icon: sap.m.MessageBox.Icon.ERROR,
					});
					return;
				} else {
					var approver_txt = i18ntext_bundle.getText("Approver");
					for (var i = 0; i < apprTable.getItems().length; i++) {
						if (apprTable.getItems()[i].getCells()[6].getSelected() === true && apprTable.getItems()[i].getCells()[2].getText() ===
							approver_txt) {
							manual_approver = 'T';
						}

					}
					if (manual_approver != 'T') {
						var pleaseentermanualapprovertoproceed = i18ntext_bundle.getText("Pleaseenteratleastonemanualapprovertoproceed");
						var error = i18ntext_bundle.getText("Error");
						sap.m.MessageBox.show(pleaseentermanualapprovertoproceed, {
							title: error,
							icon: sap.m.MessageBox.Icon.ERROR,
						});
						// Reset manual approver validation
						manual_approver = '';
						return;
					}
					// Reset manual approver validation
					manual_approver = '';
				}
			}
			if (apprTable.getItems().length > 0) {
				var emptyappr = "";
				for (var i = 0; i < apprTable.getItems().length; i++) {
					if (apprTable.getItems()[i].getCells()[1].mProperties.value === undefined)
						emptyappr = apprTable.getItems()[i].getCells()[1].getText();
					else
						emptyappr = apprTable.getItems()[i].getCells()[1].getValue();
					if (emptyappr === "") {
						var error = i18ntext_bundle.getText("Error");
						var approverwatchercannotbeempty = i18ntext_bundle.getText("Approver/WatchernamecannotbeEmpty");
						sap.m.MessageBox.show(approverwatchercannotbeempty, {
							title: error,
							icon: sap.m.MessageBox.Icon.ERROR,
						});
						return;
					}
				}
			}
			if (req_type.getValue() === "") {
				req_type.setValueState('Error');
				req_type.setValueStateText('Required');
			} else if (req_type.getValue() !== "") {
				req_type.setValueState('None');
				req_type.setValueStateText('');
			}
			if (title.getValue() === "") {
				title.setValueState('Error');
				title.setValueStateText('Required');
			} else if (title.getValue() !== "") {
				title.setValueState('None');
				title.setValueStateText('');
			}
			if (email.getValue() === "") {
				email.setValueState('Error');
				email.setValueStateText('Required');
			} else if (email.getValue() !== "") {
				email.setValueState('None');
				email.setValueStateText('');
			}
			if (desc.getValue() === "") {
				desc.setValueState('Error');
				desc.setValueStateText('Required');
			} else if (desc.getValue() !== "") {
				desc.setValueState('None');
				desc.setValueStateText('');
			}
			if (onbehalfof.getValue() === "") {
				onbehalfof.setValueState('Error');
				onbehalfof.setValueStateText('Required');
			} else if (onbehalfof.getValue() !== "") {
				onbehalfof.setValueState('None');
				onbehalfof.setValueStateText('');
			}
			if (phone.getValue() === "") {
				phone.setValueState('Error');
				phone.setValueStateText('Required');
			} else if (phone.getValue() !== "") {
				phone.setValueState('None');
				phone.setValueStateText('');
			}
			if (title.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() ===
				"" || onbehalfof.getValue() === "" || phone.getValue() === "") {
				msgflag = 'true';
				var warning = i18ntext_bundle.getText("Warning");
				sap.m.MessageBox.show(requiredFields, {
					title: warning,
					icon: sap.m.MessageBox.Icon.WARNING,
				});
			}
			if (this.flag === "A") {
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (purpose.getValue() === "" || inst.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() ===
					"" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() === "") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true'
					}
				}
			}
			if (this.flag === "B") {
				if (dateNeeded.getValue() === "") {
					dateNeeded.setValueState('Error');
					dateNeeded.setValueStateText('Required');
				} else if (dateNeeded.getValue() !== "") {
					dateNeeded.setValueState('None');
					dateNeeded.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (vendorname.getValue() === "") {
					vendorname.setValueState('Error');
					vendorname.setValueStateText('Required');
				} else if (vendorname.getValue() !== "") {
					vendorname.setValueState('None');
					vendorname.setValueStateText('');
				}
				if (vendoradd.getValue() === "") {
					vendoradd.setValueState('Error');
					vendoradd.setValueStateText('Required');
				} else if (vendoradd.getValue() !== "") {
					vendoradd.setValueState('None');
					vendoradd.setValueStateText('');
				}
				if (payingentity.getValue() === "") {
					payingentity.setValueState('Error');
					payingentity.setValueStateText('Required');
				} else if (payingentity.getValue() !== "") {
					payingentity.setValueState('None');
					payingentity.setValueStateText('');
				}
				if (glaccount.getValue() === "") {
					glaccount.setValueState('Error');
					glaccount.setValueStateText('Required');
				} else if (glaccount.getValue() !== "") {
					glaccount.setValueState('None');
					glaccount.setValueStateText('');
				}
				if (wbs.getValue() === "") {
					wbs.setValueState('Error');
					wbs.setValueStateText('Required');
				} else if (wbs.getValue() !== "") {
					wbs.setValueState('None');
					wbs.setValueStateText('');
				}
				if (amount.getValue() === "") {
					amount.setValueState('Error');
					amount.setValueStateText('Required');
				} else if (amount.getValue() !== "") {
					amount.setValueState('None');
					amount.setValueStateText('');
				}
				if (invoice.getValue() === "") {
					invoice.setValueState('Error');
					invoice.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					invoice.setValueState('None');
					invoice.setValueStateText('');
				}
				if (dateNeeded.getValue() === "" || title.getValue() === "" || purpose.getValue() === "" ||
					inst.getValue() === "" || vendorname.getValue() === "" || vendoradd.getValue() === "" ||
					payingentity.getValue() === "" || glaccount.getValue() === "" || wbs.getValue() === "" || amount.getValue() === "" || invoice.getValue() ===
					"" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true'
					}
				}
			}
			if (this.flag === "C") {
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (payingentity.getValue() === "") {
					payingentity.setValueState('Error');
					payingentity.setValueStateText('Required');
				} else if (payingentity.getValue() !== "") {
					payingentity.setValueState('None');
					payingentity.setValueStateText('');
				}
				if (amount.getValue() === "") {
					amount.setValueState('Error');
					amount.setValueStateText('Required');
				} else if (amount.getValue() !== "") {
					amount.setValueState('None');
					amount.setValueStateText('');
				}
				if (invoice.getValue() === "") {
					invoice.setValueState('Error');
					invoice.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					invoice.setValueState('None');
					invoice.setValueStateText('');
				}
				if (purpose.getValue() === "" || inst.getValue() === "" || payingentity.getValue() === "" || amount.getValue() === "" || invoice.getValue() ===
					"" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true'
					}
				}
			}
			if (this.flag === "D") {
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (payingentity.getValue() === "") {
					payingentity.setValueState('Error');
					payingentity.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					payingentity.setValueState('None');
					payingentity.setValueStateText('');
				}
				if (lob.getValue() === "") {
					lob.setValueState('Error');
					lob.setValueStateText('Required');
				} else if (lob.getValue() !== "") {
					lob.setValueState('None');
					lob.setValueStateText('');
				}
				if (sublob.getValue() === "") {
					sublob.setValueState('Error');
					sublob.setValueStateText('Required');
				} else if (sublob.getValue() !== "") {
					sublob.setValueState('None');
					sublob.setValueStateText('');
				}
				if (lob.getValue() === "" || sublob.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() ===
					"" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() === "") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true'
					}
				}
			}
			if (this.flag === 'FR') {
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (fin_req_type.getValue() === "") {
					fin_req_type.setValueState('Error');
					fin_req_type.setValueStateText('Required');
				} else if (fin_req_type.getValue() !== "") {
					fin_req_type.setValueState('None');
					fin_req_type.setValueStateText('');
				}
				if (fr_approve_by_date.getValue() === "") {
					fr_approve_by_date.setValueState('Error');
					fr_approve_by_date.setValueStateText('Required');
				} else if (fr_approve_by_date.getValue() !== "") {
					fr_approve_by_date.setValueState('None');
					fr_approve_by_date.setValueStateText('');
				}
				if (fr_comp_code.getValue() === "") {
					fr_comp_code.setValueState('Error');
					fr_comp_code.setValueStateText('Required');
				} else if (fr_comp_code.getValue() !== "") {
					fr_comp_code.setValueState('None');
					fr_comp_code.setValueStateText('');
				}
				if (fr_lob.getValue() === "") {
					fr_lob.setValueState('Error');
					fr_lob.setValueStateText('Required');
				} else if (fr_lob.getValue() !== "") {
					fr_lob.setValueState('None');
					fr_lob.setValueStateText('');
				}
				if (fr_fis_month.getValue() === "") {
					fr_fis_month.setValueState('Error');
					fr_fis_month.setValueStateText('Required');
				} else if (fr_fis_month.getValue() !== "") {
					fr_fis_month.setValueState('None');
					fr_fis_month.setValueStateText('');
				}
				if (fr_fis_year.getValue() === "") {
					fr_fis_year.setValueState('Error');
					fr_fis_year.setValueStateText('Required');
				} else if (fr_fis_year.getValue() !== "") {
					fr_fis_year.setValueState('None');
					fr_fis_year.setValueStateText('');
				}
				if (fr_doc_link.getValue() === "") {
					fr_doc_link.setValueState('Error');
					fr_doc_link.setValueStateText('Required');
				} else if (fr_doc_link.getValue() !== "") {
					fr_doc_link.setValueState('None');
					fr_doc_link.setValueStateText('');
				}
				if (fr_refdocs.getValue() === "") {
					fr_refdocs.setValueState('Error');
					fr_refdocs.setValueStateText('Required');
				} else if (fr_refdocs.getValue() !== "") {
					fr_refdocs.setValueState('None');
					fr_refdocs.setValueStateText('');
				}
				if (fin_req_type.getValue() === "" ||
					fr_approve_by_date.getValue() === "" || fr_comp_code.getValue() === "" || fr_lob.getValue() === "" || fr_fis_month.getValue() ===
					"" ||
					fr_fis_year.getValue() === "" || fr_doc_link.getValue() === "" || fr_refdocs.getValue() === "" || req_type.getValue() === "" ||
					title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() ===
					"") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true';
					}
				}
			}
			if (this.flag === "E") {
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (payingentity.getValue() === "") {
					payingentity.setValueState('Error');
					payingentity.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					payingentity.setValueState('None');
					payingentity.setValueStateText('');
				}
				if (lob.getValue() === "") {
					lob.setValueState('Error');
					lob.setValueStateText('Required');
				} else if (lob.getValue() !== "") {
					lob.setValueState('None');
					lob.setValueStateText('');
				}
				if (sublob.getValue() === "") {
					sublob.setValueState('Error');
					sublob.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					sublob.setValueState('None');
					sublob.setValueStateText('');
				}
				if (territory.getValue() === "") {
					territory.setValueState('Error');
					territory.setValueStateText('Required');
				} else if (territory.getValue() !== "") {
					territory.setValueState('None');
					territory.setValueStateText('');
				}
				if (approver_Date.getValue() === "") {
					approver_Date.setValueState('Error');
					approver_Date.setValueStateText('Required');
				} else if (approver_Date.getValue() !== "") {
					approver_Date.setValueState('None');
					approver_Date.setValueStateText('');
				}
				if (customer_Company.getValue() === "") {
					customer_Company.setValueState('Error');
					customer_Company.setValueStateText('Required');
				} else if (customer_Company.getValue() !== "") {
					customer_Company.setValueState('None');
					customer_Company.setValueStateText('');
				}
				if (amount.getValue() === "") {
					amount.setValueState('Error');
					amount.setValueStateText('Required');
				} else if (amount.getValue() !== "") {
					amount.setValueState('None');
					amount.setValueStateText('');
				}
				if (
					lob.getValue() === "" || sublob.getValue() === "" || territory.getValue() === "" || approver_Date.getValue() === "" ||
					customer_Company.getValue() === "" || amount.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() ===
					"" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() === "") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true'
					}
				}
			}
			// ///
			if (this.flag === "PCF") {
				if (this.getView().byId('PCF_TFADATE').getValue() === "") {
					this.getView().byId('PCF_TFADATE').setValueState('Error');
					this.getView().byId('PCF_TFADATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_TFADATE').getValue() !== "") {
					this.getView().byId('PCF_TFADATE').setValueState('None');
					this.getView().byId('PCF_TFADATE').setValueStateText('');
				}
				if (this.getView().byId('PCF_LOB').getValue() === "") {
					this.getView().byId('PCF_LOB').setValueState('Error');
					this.getView().byId('PCF_LOB').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOB').getValue() !== "") {
					this.getView().byId('PCF_LOB').setValueState('None');
					this.getView().byId('PCF_LOB').setValueStateText('');
				}

				//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
				if (this.getView().byId('PCF_RECOMMAND').getValue() === "") {
					this.getView().byId('PCF_RECOMMAND').setValueState('Error');
					this.getView().byId('PCF_RECOMMAND').setValueStateText('Required');
				} else if (this.getView().byId('PCF_RECOMMAND').getValue() !== "") {
					this.getView().byId('PCF_RECOMMAND').setValueState('None');
					this.getView().byId('PCF_RECOMMAND').setValueStateText('');
				}
				//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END

				if (this.getView().byId('PCF_STATE').getValue() === "") {
					this.getView().byId('PCF_STATE').setValueState('Error');
					this.getView().byId('PCF_STATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_STATE').getValue() !== "") {
					this.getView().byId('PCF_STATE').setValueState('None');
					this.getView().byId('PCF_STATE').setValueStateText('');
				}
				if (this.getView().byId('PCF_COUNTRY').getValue() === "") {
					this.getView().byId('PCF_COUNTRY').setValueState('Error');
					this.getView().byId('PCF_COUNTRY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_COUNTRY').getValue() !== "") {
					this.getView().byId('PCF_COUNTRY').setValueState('None');
					this.getView().byId('PCF_COUNTRY').setValueStateText('');
				}
				if (this.getView().byId('PCF_CITY').getValue() === "") {
					this.getView().byId('PCF_CITY').setValueState('Error');
					this.getView().byId('PCF_CITY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CITY').getValue() !== "") {
					this.getView().byId('PCF_CITY').setValueState('None');
					this.getView().byId('PCF_CITY').setValueStateText('');
				}
				if (this.getView().byId('PCF_LOCATION').getValue() === "") {
					this.getView().byId('PCF_LOCATION').setValueState('Error');
					this.getView().byId('PCF_LOCATION').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOCATION').getValue() !== "") {
					this.getView().byId('PCF_LOCATION').setValueState('None');
					this.getView().byId('PCF_LOCATION').setValueStateText('');
				}
				if (this.getView().byId('PCF_LEASE').getValue() === "") {
					this.getView().byId('PCF_LEASE').setValueState('Error');
					this.getView().byId('PCF_LEASE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LEASE').getValue() !== "") {
					this.getView().byId('PCF_LEASE').setValueState('None');
					this.getView().byId('PCF_LEASE').setValueStateText('');
				}

				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
				if (this.getView().byId('PCF_EXIT').getValue() === "") {
					this.getView().byId('PCF_EXIT').setValueState('Error');
					this.getView().byId('PCF_EXIT').setValueStateText('Required');
				} else if (this.getView().byId('PCF_EXIT').getValue() !== "") {
					this.getView().byId('PCF_EXIT').setValueState('None');
					this.getView().byId('PCF_EXIT').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END

				if (this.getView().byId('PCF_LOCCURRENCY').getValue() === "") {
					this.getView().byId('PCF_LOCCURRENCY').setValueState('Error');
					this.getView().byId('PCF_LOCCURRENCY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOCCURRENCY').getValue() !== "") {
					this.getView().byId('PCF_LOCCURRENCY').setValueState('None');
					this.getView().byId('PCF_LOCCURRENCY').setValueStateText('');
				}
				if (this.getView().byId('PCF_OCC_COST').getValue() === "") {
					this.getView().byId('PCF_OCC_COST').setValueState('Error');
					this.getView().byId('PCF_OCC_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OCC_COST').getValue() !== "") {
					this.getView().byId('PCF_OCC_COST').setValueState('None');
					this.getView().byId('PCF_OCC_COST').setValueStateText('');
				}
				if (this.getView().byId('PCF_CAP_COST').getValue() === "") {
					this.getView().byId('PCF_CAP_COST').setValueState('Error');
					this.getView().byId('PCF_CAP_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CAP_COST').getValue() !== "") {
					this.getView().byId('PCF_CAP_COST').setValueState('None');
					this.getView().byId('PCF_CAP_COST').setValueStateText('');
				}
				if (this.getView().byId('PCF_OT_COST').getValue() === "") {
					this.getView().byId('PCF_OT_COST').setValueState('Error');
					this.getView().byId('PCF_OT_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OT_COST').getValue() !== "") {
					this.getView().byId('PCF_OT_COST').setValueState('None');
					this.getView().byId('PCF_OT_COST').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
				if (this.getView().byId('PCF_REINSTATEMENT_COST').getValue() === "") {
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueState('Error');
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_REINSTATEMENT_COST').getValue() !== "") {
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueState('None');
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
				if (this.getView().byId('PCF_OTHER_MISC').getValue() === "") {
					this.getView().byId('PCF_OTHER_MISC').setValueState('Error');
					this.getView().byId('PCF_OTHER_MISC').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OTHER_MISC').getValue() !== "") {
					this.getView().byId('PCF_OTHER_MISC').setValueState('None');
					this.getView().byId('PCF_OTHER_MISC').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:Validation for the New Field added:START
				if (this.getView().byId('PCF_OCC_COST_USD').getValue() === "") {
					this.getView().byId('PCF_OCC_COST_USD').setValueState('Error');
					this.getView().byId('PCF_OCC_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OCC_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_OCC_COST_USD').setValueState('None');
					this.getView().byId('PCF_OCC_COST_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_CAP_COST_USD').getValue() === "") {
					this.getView().byId('PCF_CAP_COST_USD').setValueState('Error');
					this.getView().byId('PCF_CAP_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CAP_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_CAP_COST_USD').setValueState('None');
					this.getView().byId('PCF_CAP_COST_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_OT_COST_USD').getValue() === "") {
					this.getView().byId('PCF_OT_COST_USD').setValueState('Error');
					this.getView().byId('PCF_OT_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OT_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_OT_COST_USD').setValueState('None');
					this.getView().byId('PCF_OT_COST_USD').setValueStateText('');
				}

				if (this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue() === "") {
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueState('Error');
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueState('None');
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueStateText('');
				}

				if (this.getView().byId('PCF_OTHER_MISC_USD').getValue() === "") {
					this.getView().byId('PCF_OTHER_MISC_USD').setValueState('Error');
					this.getView().byId('PCF_OTHER_MISC_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OTHER_MISC_USD').getValue() !== "") {
					this.getView().byId('PCF_OTHER_MISC_USD').setValueState('None');
					this.getView().byId('PCF_OTHER_MISC_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_EXCHANGE_RATE').getValue() === "") {
					this.getView().byId('PCF_EXCHANGE_RATE').setValueState('Error');
					this.getView().byId('PCF_EXCHANGE_RATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_EXCHANGE_RATE').getValue() !== "") {
					this.getView().byId('PCF_EXCHANGE_RATE').setValueState('None');
					this.getView().byId('PCF_EXCHANGE_RATE').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:Validation for the New Field added :END
				if (this.getView().byId('PCF_DESC_JUST').getValue() === "") {
					this.getView().byId('PCF_DESC_JUST').setValueState('Error');
					this.getView().byId('PCF_DESC_JUST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_DESC_JUST').getValue() !== "") {
					this.getView().byId('PCF_DESC_JUST').setValueState('None');
					this.getView().byId('PCF_DESC_JUST').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD if if condition FOR WorldWide PCF TYPE
				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW PCF_RECOMMAND FIELD in if condition FOR WorldWide PCF TYPE
				if (this.getView().byId('PCF_TFADATE').getValue() === "" || this.getView().byId('PCF_LOB').getValue() === "" ||
					this.getView().byId('PCF_RECOMMAND').getValue() === "" || this.getView().byId(
						'PCF_STATE').getValue() === "" ||
					this.getView().byId('PCF_COUNTRY').getValue() === "" || this.getView().byId('PCF_CITY').getValue() === "" || this.getView().byId(
						'PCF_LOCATION').getValue() === "" || this.getView().byId(
						'PCF_EXCHANGE_RATE').getValue() === "" ||
					this.getView().byId('PCF_LEASE').getValue() === "" ||
					this.getView().byId('PCF_EXIT').getValue() === "" || this.getView().byId('PCF_LOCCURRENCY').getValue() === "" || this.getView().byId(
						'PCF_OCC_COST').getValue() === "" ||
					this.getView().byId('PCF_CAP_COST').getValue() === "" || this.getView().byId('PCF_OT_COST').getValue() === "" || this.getView().byId(
						'PCF_REINSTATEMENT_COST').getValue() === "" || this.getView().byId('PCF_OTHER_MISC').getValue() === "" || this.getView().byId(
						'PCF_OCC_COST_USD').getValue() === "" ||
					this.getView().byId('PCF_CAP_COST_USD').getValue() === "" || this.getView().byId('PCF_OT_COST_USD').getValue() === "" || this.getView()
					.byId(
						'PCF_REINSTATEMENT_COST_USD').getValue() === "" || this.getView().byId(
						'PCF_OTHER_MISC_USD').getValue() === "" || this.getView().byId(
						'PCF_DESC_JUST').getValue() === "" ||
					req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					if (msgflag != 'true') {
						var warning = i18ntext_bundle.getText("Warning");
						sap.m.MessageBox.show(requiredFields, {
							title: warning,
							icon: sap.m.MessageBox.Icon.WARNING,
						});
						msgflag = 'true'
					}
				}
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Validation functionality while saving request
			//************************************************************************************************************

			/*<Request Number:REQ034679><Dt: 14.10.2018><Start of>*/
			if (this.flag === "STPN") {
				msgflag = this.STPNFieldsvalidation(msgflag, "Save");
			}
			/*<Request Number:REQ034679><Dt: 14.10.2018><End of>*/

			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Validation functionality while saving request
			//************************************************************************************************************
			if (phone.getValue().length < 10 && phone.getValue() != "") {
				var warning = i18ntext_bundle.getText("Warning");
				var pleaseenter10digits = i18ntext_bundle.getText("Pleaseenterrequestorphoneofatleast10digits");
				MessageBox.show(
					pleaseenter10digits,
					MessageBox.Icon.WARNING,
					warning
				);
				phone.setValueState("Error");
			}
			if (eform_status == 'In Approval') {
				this._postDataToBackend('In Approval');
			}
			if (eform_status == 'Rejected') {
				this._postDataToBackend('Rejected');
			}
			if (eform_status == 'Data Saved') {
				this._postDataToBackend('Data Saved');
			}
			if (eform_status == 'Withdrawn') {
				this._postDataToBackend('Data Saved');
			}
		},
		_onFinalSubmitPress: function () {
			button_press = 'Submit';
			this.items = [];
			// var oButton=this.byId('ValidateButton');
			var msgPopover = sap.ui.getCore().byId('oMsgPopover');
			var title = this.getView().byId("input_title");
			var dateNeeded = this.getView().byId('DP2');
			var desc = this.getView().byId("text_desc");
			var onbehalfof = this.getView().byId("input_on_behalf_of");
			var phone = this.getView().byId("input_business_phone");
			var email = this.getView().byId("input_emailid");
			var req_type = this.getView().byId("input_RequestType");
			var purpose = this.getView().byId("text_purpose");
			var inst = this.getView().byId("text_instruction");
			var lob = this.getView().byId("input_lob");
			var sublob = this.getView().byId("input_sublob");
			var vendorname = this.getView().byId("input_VendorName");
			var vendoradd = this.getView().byId("text_address");
			var payingentity = this.getView().byId("input_payingentity");
			var glaccount = this.getView().byId("input_glaccount");
			var wbs = this.getView().byId("input_wbs");
			var amount = this.getView().byId("input_amount");
			var invoice = this.getView().byId("text_invoice");
			var territory = this.byId('oSelectCountry');
			var approver_Date = this.byId('date_Approver');
			var customer_Company = this.byId('inpCustomer');
			var table = this.byId('approver_table');
			var fr_approve_by_date = this.byId('AppDP');
			var fr_comp_code = this.byId('input_comp');
			var fr_lob = this.byId('fr_cmb_lob');
			var fr_fis_month = this.byId('fr_fis_month');
			var fr_fis_year = this.byId('fr_fis_year');
			var fr_doc_link = this.byId('input_frdoclinks');
			var fr_refdocs = this.byId('fr_text_refdocs');
			var fin_req_type = this.byId('fin_req_type');
			var requiredFields = this.getView().getModel("i18n").getResourceBundle().getText("requiredParameter");
			var noApprover = this.getView().getModel("i18n").getResourceBundle().getText("emptyApproval");
			var emptyApprover = this.getView().getModel("i18n").getResourceBundle().getText("approverEmpty");
			if (req_type.getValue() === "") {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				var error = i18ntext_bundle.getText("Error");
				sap.m.MessageBox.show(requiredFields, {
					title: error,
					icon: sap.m.MessageBox.Icon.ERROR,
				});
				return;
			}
			if ((req_type.getValue() === 'Miscellaneous') || (req_type.getValue() === 'Programming COFA') || (req_type.getValue() ===
					'Sign-Off: BRD') || (req_type.getValue() === 'Sign-Off: UAT') || (req_type.getValue() === 'Sign-Off: Other') || (req_type.getValue() ===
					'Sign-Off: FD/Level 7 Approval') || (req_type.getValue() === 'Contract Approval Form') || (req_type.getValue() ===
					'Residual Payment Control')) {
				this.flag = "A";
			} else if (req_type.getValue() === 'Production Accounting Payment Request') {
				this.flag = "B";
			} else if (req_type.getValue() === 'SPHE Media Budget Authorization') {
				this.flag = "C";
			} else if (req_type.getValue() === 'OPC Exception') {
				this.flag = "D";
			} else if (req_type.getValue() === 'Japan TV Channels') {
				this.flag = "E";
			} else if (req_type.getValue() === 'Worldwide Facilities-PCF') {
				this.flag = "PCF";
			} else if ((req_type.getValue() === 'Finance Request Form')) {
				this.flag = 'FR';
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Adding SPTN ProCard Payment Request to the condition
			//************************************************************************************************************
			else if (req_type.getValue() === "SPTN ProCard Payment Request") {
				this.flag = "STPN";
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Adding SPTN ProCard Payment Request to the condition
			//************************************************************************************************************

			if (this.flag === "A") {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (purpose.getValue() === "" || inst.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() ===
					"" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() === "") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			if (this.flag === "B") {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				if (dateNeeded.getValue() === "") {
					dateNeeded.setValueState('Error');
					dateNeeded.setValueStateText('Required');
				} else if (dateNeeded.getValue() !== "") {
					dateNeeded.setValueState('None');
					dateNeeded.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (vendorname.getValue() === "") {
					vendorname.setValueState('Error');
					vendorname.setValueStateText('Required');
				} else if (vendorname.getValue() !== "") {
					vendorname.setValueState('None');
					vendorname.setValueStateText('');
				}
				if (vendoradd.getValue() === "") {
					vendoradd.setValueState('Error');
					vendoradd.setValueStateText('Required');
				} else if (vendoradd.getValue() !== "") {
					vendoradd.setValueState('None');
					vendoradd.setValueStateText('');
				}
				if (payingentity.getValue() === "") {
					payingentity.setValueState('Error');
					payingentity.setValueStateText('Required');
				} else if (payingentity.getValue() !== "") {
					payingentity.setValueState('None');
					payingentity.setValueStateText('');
				}
				if (glaccount.getValue() === "") {
					glaccount.setValueState('Error');
					glaccount.setValueStateText('Required');
				} else if (glaccount.getValue() !== "") {
					glaccount.setValueState('None');
					glaccount.setValueStateText('');
				}
				if (wbs.getValue() === "") {
					wbs.setValueState('Error');
					wbs.setValueStateText('Required');
				} else if (wbs.getValue() !== "") {
					wbs.setValueState('None');
					wbs.setValueStateText('');
				}
				if (amount.getValue() === "") {
					amount.setValueState('Error');
					amount.setValueStateText('Required');
				} else if (amount.getValue() !== "") {
					amount.setValueState('None');
					amount.setValueStateText('');
				}
				if (invoice.getValue() === "") {
					invoice.setValueState('Error');
					invoice.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					invoice.setValueState('None');
					invoice.setValueStateText('');
				}
				if (dateNeeded.getValue() === "" || title.getValue() === "" || purpose.getValue() === "" ||
					inst.getValue() === "" || vendorname.getValue() === "" || vendoradd.getValue() === "" ||
					payingentity.getValue() === "" || glaccount.getValue() === "" || wbs.getValue() === "" || amount.getValue() === "" || invoice.getValue() ===
					"" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			if (this.flag === "C") {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (payingentity.getValue() === "") {
					payingentity.setValueState('Error');
					payingentity.setValueStateText('Required');
				} else if (payingentity.getValue() !== "") {
					payingentity.setValueState('None');
					payingentity.setValueStateText('');
				}
				if (amount.getValue() === "") {
					amount.setValueState('Error');
					amount.setValueStateText('Required');
				} else if (amount.getValue() !== "") {
					amount.setValueState('None');
					amount.setValueStateText('');
				}
				if (invoice.getValue() === "") {
					invoice.setValueState('Error');
					invoice.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					invoice.setValueState('None');
					invoice.setValueStateText('');
				}
				if (purpose.getValue() === "" || inst.getValue() === "" || payingentity.getValue() === "" || amount.getValue() === "" || invoice.getValue() ===
					"" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			// ///
			if (this.flag === "PCF") {
				if (this.getView().byId('PCF_TFADATE').getValue() === "") {
					this.getView().byId('PCF_TFADATE').setValueState('Error');
					this.getView().byId('PCF_TFADATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_TFADATE').getValue() !== "") {
					this.getView().byId('PCF_TFADATE').setValueState('None');
					this.getView().byId('PCF_TFADATE').setValueStateText('');
				}
				if (this.getView().byId('PCF_LOB').getValue() === "") {
					this.getView().byId('PCF_LOB').setValueState('Error');
					this.getView().byId('PCF_LOB').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOB').getValue() !== "") {
					this.getView().byId('PCF_LOB').setValueState('None');
					this.getView().byId('PCF_LOB').setValueStateText('');
				}

				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
				if (this.getView().byId('PCF_RECOMMAND').getValue() === "") {
					this.getView().byId('PCF_RECOMMAND').setValueState('Error');
					this.getView().byId('PCF_RECOMMAND').setValueStateText('Required');
				} else if (this.getView().byId('PCF_RECOMMAND').getValue() !== "") {
					this.getView().byId('PCF_RECOMMAND').setValueState('None');
					this.getView().byId('PCF_RECOMMAND').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END

				if (this.getView().byId('PCF_STATE').getValue() === "") {
					this.getView().byId('PCF_STATE').setValueState('Error');
					this.getView().byId('PCF_STATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_STATE').getValue() !== "") {
					this.getView().byId('PCF_STATE').setValueState('None');
					this.getView().byId('PCF_STATE').setValueStateText('');
				}
				if (this.getView().byId('PCF_COUNTRY').getValue() === "") {
					this.getView().byId('PCF_COUNTRY').setValueState('Error');
					this.getView().byId('PCF_COUNTRY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_COUNTRY').getValue() !== "") {
					this.getView().byId('PCF_COUNTRY').setValueState('None');
					this.getView().byId('PCF_COUNTRY').setValueStateText('');
				}
				if (this.getView().byId('PCF_CITY').getValue() === "") {
					this.getView().byId('PCF_CITY').setValueState('Error');
					this.getView().byId('PCF_CITY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CITY').getValue() !== "") {
					this.getView().byId('PCF_CITY').setValueState('None');
					this.getView().byId('PCF_CITY').setValueStateText('');
				}
				if (this.getView().byId('PCF_LOCATION').getValue() === "") {
					this.getView().byId('PCF_LOCATION').setValueState('Error');
					this.getView().byId('PCF_LOCATION').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOCATION').getValue() !== "") {
					this.getView().byId('PCF_LOCATION').setValueState('None');
					this.getView().byId('PCF_LOCATION').setValueStateText('');
				}
				if (this.getView().byId('PCF_LEASE').getValue() === "") {
					this.getView().byId('PCF_LEASE').setValueState('Error');
					this.getView().byId('PCF_LEASE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LEASE').getValue() !== "") {
					this.getView().byId('PCF_LEASE').setValueState('None');
					this.getView().byId('PCF_LEASE').setValueStateText('');
				}

				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
				if (this.getView().byId('PCF_EXIT').getValue() === "") {
					this.getView().byId('PCF_EXIT').setValueState('Error');
					this.getView().byId('PCF_EXIT').setValueStateText('Required');
				} else if (this.getView().byId('PCF_EXIT').getValue() !== "") {
					this.getView().byId('PCF_EXIT').setValueState('None');
					this.getView().byId('PCF_EXIT').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END

				if (this.getView().byId('PCF_LOCCURRENCY').getValue() === "") {
					this.getView().byId('PCF_LOCCURRENCY').setValueState('Error');
					this.getView().byId('PCF_LOCCURRENCY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOCCURRENCY').getValue() !== "") {
					this.getView().byId('PCF_LOCCURRENCY').setValueState('None');
					this.getView().byId('PCF_LOCCURRENCY').setValueStateText('');
				}
				if (this.getView().byId('PCF_OCC_COST').getValue() === "") {
					this.getView().byId('PCF_OCC_COST').setValueState('Error');
					this.getView().byId('PCF_OCC_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OCC_COST').getValue() !== "") {
					this.getView().byId('PCF_OCC_COST').setValueState('None');
					this.getView().byId('PCF_OCC_COST').setValueStateText('');
				}
				if (this.getView().byId('PCF_CAP_COST').getValue() === "") {
					this.getView().byId('PCF_CAP_COST').setValueState('Error');
					this.getView().byId('PCF_CAP_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CAP_COST').getValue() !== "") {
					this.getView().byId('PCF_CAP_COST').setValueState('None');
					this.getView().byId('PCF_CAP_COST').setValueStateText('');
				}
				if (this.getView().byId('PCF_OT_COST').getValue() === "") {
					this.getView().byId('PCF_OT_COST').setValueState('Error');
					this.getView().byId('PCF_OT_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OT_COST').getValue() !== "") {
					this.getView().byId('PCF_OT_COST').setValueState('None');
					this.getView().byId('PCF_OT_COST').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
				if (this.getView().byId('PCF_REINSTATEMENT_COST').getValue() === "") {
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueState('Error');
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_REINSTATEMENT_COST').getValue() !== "") {
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueState('None');
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END	

				if (this.getView().byId('PCF_OTHER_MISC').getValue() === "") {
					this.getView().byId('PCF_OTHER_MISC').setValueState('Error');
					this.getView().byId('PCF_OTHER_MISC').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OTHER_MISC').getValue() !== "") {
					this.getView().byId('PCF_OTHER_MISC').setValueState('None');
					this.getView().byId('PCF_OTHER_MISC').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:Validation for the New Field added:START
				if (this.getView().byId('PCF_OCC_COST_USD').getValue() === "") {
					this.getView().byId('PCF_OCC_COST_USD').setValueState('Error');
					this.getView().byId('PCF_OCC_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OCC_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_OCC_COST_USD').setValueState('None');
					this.getView().byId('PCF_OCC_COST_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_CAP_COST_USD').getValue() === "") {
					this.getView().byId('PCF_CAP_COST_USD').setValueState('Error');
					this.getView().byId('PCF_CAP_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CAP_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_CAP_COST_USD').setValueState('None');
					this.getView().byId('PCF_CAP_COST_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_OT_COST_USD').getValue() === "") {
					this.getView().byId('PCF_OT_COST_USD').setValueState('Error');
					this.getView().byId('PCF_OT_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OT_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_OT_COST_USD').setValueState('None');
					this.getView().byId('PCF_OT_COST_USD').setValueStateText('');
				}

				if (this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue() === "") {
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueState('Error');
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueState('None');
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueStateText('');
				}

				if (this.getView().byId('PCF_OTHER_MISC_USD').getValue() === "") {
					this.getView().byId('PCF_OTHER_MISC_USD').setValueState('Error');
					this.getView().byId('PCF_OTHER_MISC_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OTHER_MISC_USD').getValue() !== "") {
					this.getView().byId('PCF_OTHER_MISC_USD').setValueState('None');
					this.getView().byId('PCF_OTHER_MISC_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_EXCHANGE_RATE').getValue() === "") {
					this.getView().byId('PCF_EXCHANGE_RATE').setValueState('Error');
					this.getView().byId('PCF_EXCHANGE_RATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_EXCHANGE_RATE').getValue() !== "") {
					this.getView().byId('PCF_EXCHANGE_RATE').setValueState('None');
					this.getView().byId('PCF_EXCHANGE_RATE').setValueStateText('');
				}

				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:Validation for the New Field added :END
				if (this.getView().byId('PCF_DESC_JUST').getValue() === "") {
					this.getView().byId('PCF_DESC_JUST').setValueState('Error');
					this.getView().byId('PCF_DESC_JUST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_DESC_JUST').getValue() !== "") {
					this.getView().byId('PCF_DESC_JUST').setValueState('None');
					this.getView().byId('PCF_DESC_JUST').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD in if condition FOR WorldWide PCF TYPE
				//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW PCF_RECOMMAND field in if condition FOR WorldWide PCF TYPE
				if (this.getView().byId('PCF_TFADATE').getValue() === "" || this.getView().byId('PCF_LOB').getValue() === "" ||
					this.getView().byId('PCF_RECOMMAND').getValue() === "" || this.getView().byId(
						'PCF_STATE').getValue() === "" ||
					this.getView().byId('PCF_COUNTRY').getValue() === "" || this.getView().byId('PCF_CITY').getValue() === "" || this.getView().byId(
						'PCF_LOCATION').getValue() === "" || this.getView().byId(
						'PCF_EXCHANGE_RATE').getValue() === "" ||
					this.getView().byId('PCF_LEASE').getValue() === "" ||
					this.getView().byId('PCF_EXIT').getValue() === "" || this.getView().byId('PCF_LOCCURRENCY').getValue() === "" || this.getView().byId(
						'PCF_OCC_COST').getValue() === "" ||
					this.getView().byId('PCF_CAP_COST').getValue() === "" || this.getView().byId('PCF_OT_COST').getValue() === "" || this.getView().byId(
						'PCF_REINSTATEMENT_COST').getValue() === "" || this.getView().byId(
						'PCF_OTHER_MISC').getValue() === "" || this.getView().byId(
						'PCF_OCC_COST_USD').getValue() === "" ||
					this.getView().byId('PCF_CAP_COST_USD').getValue() === "" || this.getView().byId('PCF_OT_COST_USD').getValue() === "" || this.getView()
					.byId(
						'PCF_REINSTATEMENT_COST_USD').getValue() === "" || this.getView().byId(
						'PCF_OTHER_MISC_USD').getValue() === "" || this.getView().byId('PCF_DESC_JUST').getValue() === "" ||
					req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					sap.m.MessageBox.show(requiredFields, {
						title: "Warning",
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			// ////
			if (this.flag === 'FR') {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				if (purpose.getValue() === "") {
					purpose.setValueState('Error');
					purpose.setValueStateText('Required');
				} else if (purpose.getValue() !== "") {
					purpose.setValueState('None');
					purpose.setValueStateText('');
				}
				if (inst.getValue() === "") {
					inst.setValueState('Error');
					inst.setValueStateText('Required');
				} else if (inst.getValue() !== "") {
					inst.setValueState('None');
					inst.setValueStateText('');
				}
				if (fin_req_type.getValue() === "") {
					fin_req_type.setValueState('Error');
					fin_req_type.setValueStateText('Required');
				} else if (fin_req_type.getValue() !== "") {
					fin_req_type.setValueState('None');
					fin_req_type.setValueStateText('');
				}
				if (fr_approve_by_date.getValue() === "") {
					fr_approve_by_date.setValueState('Error');
					fr_approve_by_date.setValueStateText('Required');
				} else if (fr_approve_by_date.getValue() !== "") {
					fr_approve_by_date.setValueState('None');
					fr_approve_by_date.setValueStateText('');
				}
				if (fr_comp_code.getValue() === "") {
					fr_comp_code.setValueState('Error');
					fr_comp_code.setValueStateText('Required');
				} else if (fr_comp_code.getValue() !== "") {
					fr_comp_code.setValueState('None');
					fr_comp_code.setValueStateText('');
				}
				if (fr_lob.getValue() === "") {
					fr_lob.setValueState('Error');
					fr_lob.setValueStateText('Required');
				} else if (fr_lob.getValue() !== "") {
					fr_lob.setValueState('None');
					fr_lob.setValueStateText('');
				}
				if (fr_fis_month.getValue() === "") {
					fr_fis_month.setValueState('Error');
					fr_fis_month.setValueStateText('Required');
				} else if (fr_fis_month.getValue() !== "") {
					fr_fis_month.setValueState('None');
					fr_fis_month.setValueStateText('');
				}
				if (fr_fis_year.getValue() === "") {
					fr_fis_year.setValueState('Error');
					fr_fis_year.setValueStateText('Required');
				} else if (fr_fis_year.getValue() !== "") {
					fr_fis_year.setValueState('None');
					fr_fis_year.setValueStateText('');
				}
				if (fr_doc_link.getValue() === "") {
					fr_doc_link.setValueState('Error');
					fr_doc_link.setValueStateText('Required');
				} else if (fr_doc_link.getValue() !== "") {
					fr_doc_link.setValueState('None');
					fr_doc_link.setValueStateText('');
				}
				if (fr_refdocs.getValue() === "") {
					fr_refdocs.setValueState('Error');
					fr_refdocs.setValueStateText('Required');
				} else if (fr_refdocs.getValue() !== "") {
					fr_refdocs.setValueState('None');
					fr_refdocs.setValueStateText('');
				}
				if (fin_req_type.getValue() === "" ||
					fr_approve_by_date.getValue() === "" || fr_comp_code.getValue() === "" || fr_lob.getValue() === "" || fr_fis_month.getValue() ===
					"" ||
					fr_fis_year.getValue() === "" || fr_doc_link.getValue() === "" || fr_refdocs.getValue() === "" || req_type.getValue() === "" ||
					title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() ===
					"") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			if (this.flag === "D") {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				if (lob.getValue() === "") {
					lob.setValueState('Error');
					lob.setValueStateText('Required');
				} else if (lob.getValue() !== "") {
					lob.setValueState('None');
					lob.setValueStateText('');
				}
				if (sublob.getValue() === "") {
					sublob.setValueState('Error');
					sublob.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					sublob.setValueState('None');
					sublob.setValueStateText('');
				}
				if (lob.getValue() === "" || sublob.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() ===
					"" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() === "") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			if (this.flag === "E") {
				if (req_type.getValue() === "") {
					req_type.setValueState('Error');
					req_type.setValueStateText('Required');
				} else if (req_type.getValue() !== "") {
					req_type.setValueState('None');
					req_type.setValueStateText('');
				}
				if (title.getValue() === "") {
					title.setValueState('Error');
					title.setValueStateText('Required');
				} else if (title.getValue() !== "") {
					title.setValueState('None');
					title.setValueStateText('');
				}
				if (desc.getValue() === "") {
					desc.setValueState('Error');
					desc.setValueStateText('Required');
				} else if (desc.getValue() !== "") {
					desc.setValueState('None');
					desc.setValueStateText('');
				}
				if (onbehalfof.getValue() === "") {
					onbehalfof.setValueState('Error');
					onbehalfof.setValueStateText('Required');
				} else if (onbehalfof.getValue() !== "") {
					onbehalfof.setValueState('None');
					onbehalfof.setValueStateText('');
				}
				if (email.getValue() === "") {
					email.setValueState('Error');
					email.setValueStateText('Required');
				} else if (email.getValue() !== "") {
					email.setValueState('None');
					email.setValueStateText('');
				}
				if (phone.getValue() === "") {
					phone.setValueState('Error');
					phone.setValueStateText('Required');
				} else if (phone.getValue() !== "") {
					phone.setValueState('None');
					phone.setValueStateText('');
				}
				if (lob.getValue() === "") {
					lob.setValueState('Error');
					lob.setValueStateText('Required');
				} else if (lob.getValue() !== "") {
					lob.setValueState('None');
					lob.setValueStateText('');
				}
				if (sublob.getValue() === "") {
					sublob.setValueState('Error');
					sublob.setValueStateText('Required');
				} else if (invoice.getValue() !== "") {
					sublob.setValueState('None');
					sublob.setValueStateText('');
				}
				if (territory.getValue() === "") {
					territory.setValueState('Error');
					territory.setValueStateText('Required');
				} else if (territory.getValue() !== "") {
					territory.setValueState('None');
					territory.setValueStateText('');
				}
				if (approver_Date.getValue() === "") {
					approver_Date.setValueState('Error');
					approver_Date.setValueStateText('Required');
				} else if (approver_Date.getValue() !== "") {
					approver_Date.setValueState('None');
					approver_Date.setValueStateText('');
				}
				if (customer_Company.getValue() === "") {
					customer_Company.setValueState('Error');
					customer_Company.setValueStateText('Required');
				} else if (customer_Company.getValue() !== "") {
					customer_Company.setValueState('None');
					customer_Company.setValueStateText('');
				}
				if (amount.getValue() === "") {
					amount.setValueState('Error');
					amount.setValueStateText('Required');
				} else if (amount.getValue() !== "") {
					amount.setValueState('None');
					amount.setValueStateText('');
				}
				if (
					lob.getValue() === "" || sublob.getValue() === "" || territory.getValue() === "" || approver_Date.getValue() === "" ||
					customer_Company.getValue() === "" || amount.getValue() === "" || req_type.getValue() === "" || title.getValue() === "" || email.getValue() ===
					"" || desc.getValue() === "" || onbehalfof.getValue() === "" || phone.getValue() === "") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Adding SPTN ProCard Payment Request to the condition
			//************************************************************************************************************
			if (this.flag !== "E" && this.flag !== "D" && this.flag !== "STPN") {
				if (table.getItems().length === 0) {
					var error = i18ntext_bundle.getText("Error");
					sap.m.MessageBox.show(noApprover, {
						title: error,
						icon: sap.m.MessageBox.Icon.ERROR,
					});
					return;
				} else {
					var approver_txt = i18ntext_bundle.getText("Approver");
					for (var i = 0; i < table.getItems().length; i++) {
						if (table.getItems()[i].getCells()[6].getSelected() === true && table.getItems()[i].getCells()[2].getText() === approver_txt) {
							manual_approver = 'T';
						}
					}
					if (manual_approver != 'T') {
						var error = i18ntext_bundle.getText("Error");
						sap.m.MessageBox.show(noApprover, {
							title: error,
							icon: sap.m.MessageBox.Icon.ERROR,
						});
						// Reset manual approver validation
						manual_approver = '';
						return;
					}
					// Reset manual approver validation
					manual_approver = '';
				}
			}
			if (this.flag === "PCF") {
				if (this.getView().byId('PCF_TFADATE').getValue() === "") {
					this.getView().byId('PCF_TFADATE').setValueState('Error');
					this.getView().byId('PCF_TFADATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_TFADATE').getValue() !== "") {
					this.getView().byId('PCF_TFADATE').setValueState('None');
					this.getView().byId('PCF_TFADATE').setValueStateText('');
				}
				if (this.getView().byId('PCF_LOB').getValue() === "") {
					this.getView().byId('PCF_LOB').setValueState('Error');
					this.getView().byId('PCF_LOB').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOB').getValue() !== "") {
					this.getView().byId('PCF_LOB').setValueState('None');
					this.getView().byId('PCF_LOB').setValueStateText('');
				}

				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
				if (this.getView().byId('PCF_RECOMMAND').getValue() === "") {
					this.getView().byId('PCF_RECOMMAND').setValueState('Error');
					this.getView().byId('PCF_RECOMMAND').setValueStateText('Required');
				} else if (this.getView().byId('PCF_RECOMMAND').getValue() !== "") {
					this.getView().byId('PCF_RECOMMAND').setValueState('None');
					this.getView().byId('PCF_RECOMMAND').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END

				if (this.getView().byId('PCF_STATE').getValue() === "") {
					this.getView().byId('PCF_STATE').setValueState('Error');
					this.getView().byId('PCF_STATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_STATE').getValue() !== "") {
					this.getView().byId('PCF_STATE').setValueState('None');
					this.getView().byId('PCF_STATE').setValueStateText('');
				}
				if (this.getView().byId('PCF_COUNTRY').getValue() === "") {
					this.getView().byId('PCF_COUNTRY').setValueState('Error');
					this.getView().byId('PCF_COUNTRY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_COUNTRY').getValue() !== "") {
					this.getView().byId('PCF_COUNTRY').setValueState('None');
					this.getView().byId('PCF_COUNTRY').setValueStateText('');
				}
				if (this.getView().byId('PCF_CITY').getValue() === "") {
					this.getView().byId('PCF_CITY').setValueState('Error');
					this.getView().byId('PCF_CITY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CITY').getValue() !== "") {
					this.getView().byId('PCF_CITY').setValueState('None');
					this.getView().byId('PCF_CITY').setValueStateText('');
				}
				if (this.getView().byId('PCF_LOCATION').getValue() === "") {
					this.getView().byId('PCF_LOCATION').setValueState('Error');
					this.getView().byId('PCF_LOCATION').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOCATION').getValue() !== "") {
					this.getView().byId('PCF_LOCATION').setValueState('None');
					this.getView().byId('PCF_LOCATION').setValueStateText('');
				}
				if (this.getView().byId('PCF_LEASE').getValue() === "") {
					this.getView().byId('PCF_LEASE').setValueState('Error');
					this.getView().byId('PCF_LEASE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LEASE').getValue() !== "") {
					this.getView().byId('PCF_LEASE').setValueState('None');
					this.getView().byId('PCF_LEASE').setValueStateText('');
				}

				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
				if (this.getView().byId('PCF_EXIT').getValue() === "") {
					this.getView().byId('PCF_EXIT').setValueState('Error');
					this.getView().byId('PCF_EXIT').setValueStateText('Required');
				} else if (this.getView().byId('PCF_EXIT').getValue() !== "") {
					this.getView().byId('PCF_EXIT').setValueState('None');
					this.getView().byId('PCF_EXIT').setValueStateText('');
				}
				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END

				if (this.getView().byId('PCF_LOCCURRENCY').getValue() === "") {
					this.getView().byId('PCF_LOCCURRENCY').setValueState('Error');
					this.getView().byId('PCF_LOCCURRENCY').setValueStateText('Required');
				} else if (this.getView().byId('PCF_LOCCURRENCY').getValue() !== "") {
					this.getView().byId('PCF_LOCCURRENCY').setValueState('None');
					this.getView().byId('PCF_LOCCURRENCY').setValueStateText('');
				}
				if (this.getView().byId('PCF_OCC_COST').getValue() === "") {
					this.getView().byId('PCF_OCC_COST').setValueState('Error');
					this.getView().byId('PCF_OCC_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OCC_COST').getValue() !== "") {
					this.getView().byId('PCF_OCC_COST').setValueState('None');
					this.getView().byId('PCF_OCC_COST').setValueStateText('');
				}
				if (this.getView().byId('PCF_CAP_COST').getValue() === "") {
					this.getView().byId('PCF_CAP_COST').setValueState('Error');
					this.getView().byId('PCF_CAP_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CAP_COST').getValue() !== "") {
					this.getView().byId('PCF_CAP_COST').setValueState('None');
					this.getView().byId('PCF_CAP_COST').setValueStateText('');
				}
				if (this.getView().byId('PCF_OT_COST').getValue() === "") {
					this.getView().byId('PCF_OT_COST').setValueState('Error');
					this.getView().byId('PCF_OT_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OT_COST').getValue() !== "") {
					this.getView().byId('PCF_OT_COST').setValueState('None');
					this.getView().byId('PCF_OT_COST').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
				if (this.getView().byId('PCF_REINSTATEMENT_COST').getValue() === "") {
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueState('Error');
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_REINSTATEMENT_COST').getValue() !== "") {
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueState('None');
					this.getView().byId('PCF_REINSTATEMENT_COST').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
				if (this.getView().byId('PCF_OTHER_MISC').getValue() === "") {
					this.getView().byId('PCF_OTHER_MISC').setValueState('Error');
					this.getView().byId('PCF_OTHER_MISC').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OTHER_MISC').getValue() !== "") {
					this.getView().byId('PCF_OTHER_MISC').setValueState('None');
					this.getView().byId('PCF_OTHER_MISC').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:Validation for the New Field added:START
				if (this.getView().byId('PCF_OCC_COST_USD').getValue() === "") {
					this.getView().byId('PCF_OCC_COST_USD').setValueState('Error');
					this.getView().byId('PCF_OCC_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OCC_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_OCC_COST_USD').setValueState('None');
					this.getView().byId('PCF_OCC_COST_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_CAP_COST_USD').getValue() === "") {
					this.getView().byId('PCF_CAP_COST_USD').setValueState('Error');
					this.getView().byId('PCF_CAP_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_CAP_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_CAP_COST_USD').setValueState('None');
					this.getView().byId('PCF_CAP_COST_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_OT_COST_USD').getValue() === "") {
					this.getView().byId('PCF_OT_COST_USD').setValueState('Error');
					this.getView().byId('PCF_OT_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OT_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_OT_COST_USD').setValueState('None');
					this.getView().byId('PCF_OT_COST_USD').setValueStateText('');
				}

				if (this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue() === "") {
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueState('Error');
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue() !== "") {
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueState('None');
					this.getView().byId('PCF_REINSTATEMENT_COST_USD').setValueStateText('');
				}

				if (this.getView().byId('PCF_OTHER_MISC_USD').getValue() === "") {
					this.getView().byId('PCF_OTHER_MISC_USD').setValueState('Error');
					this.getView().byId('PCF_OTHER_MISC_USD').setValueStateText('Required');
				} else if (this.getView().byId('PCF_OTHER_MISC_USD').getValue() !== "") {
					this.getView().byId('PCF_OTHER_MISC_USD').setValueState('None');
					this.getView().byId('PCF_OTHER_MISC_USD').setValueStateText('');
				}
				if (this.getView().byId('PCF_EXCHANGE_RATE').getValue() === "") {
					this.getView().byId('PCF_EXCHANGE_RATE').setValueState('Error');
					this.getView().byId('PCF_EXCHANGE_RATE').setValueStateText('Required');
				} else if (this.getView().byId('PCF_EXCHANGE_RATE').getValue() !== "") {
					this.getView().byId('PCF_EXCHANGE_RATE').setValueState('None');
					this.getView().byId('PCF_EXCHANGE_RATE').setValueStateText('');
				}
				//REQ0589824:PJAIN6:GWDK902102:08/06/2020:Validation for the New Field added :END
				if (this.getView().byId('PCF_DESC_JUST').getValue() === "") {
					this.getView().byId('PCF_DESC_JUST').setValueState('Error');
					this.getView().byId('PCF_DESC_JUST').setValueStateText('Required');
				} else if (this.getView().byId('PCF_DESC_JUST').getValue() !== "") {
					this.getView().byId('PCF_DESC_JUST').setValueState('None');
					this.getView().byId('PCF_DESC_JUST').setValueStateText('');
				}

				// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD in if condition FOR WorldWide PCF TYPE
				//REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW PCF_RECOMMAND field in if condition FOR WorldWide PCF TYPE
				if (this.getView().byId('PCF_TFADATE').getValue() === "" || this.getView().byId('PCF_LOB').getValue() === "" ||
					this.getView().byId('PCF_RECOMMAND').getValue() === "" || this.getView().byId(
						'PCF_STATE').getValue() === "" ||
					this.getView().byId('PCF_COUNTRY').getValue() === "" || this.getView().byId('PCF_CITY').getValue() === "" || this.getView().byId(
						'PCF_LOCATION').getValue() === "" || this.getView().byId(
						'PCF_EXCHANGE_RATE').getValue() === "" ||
					this.getView().byId('PCF_LEASE').getValue() === "" ||
					this.getView().byId('PCF_EXIT').getValue() === "" || this.getView().byId('PCF_LOCCURRENCY').getValue() === "" || this.getView().byId(
						'PCF_OCC_COST').getValue() === "" ||
					this.getView().byId('PCF_CAP_COST').getValue() === "" || this.getView().byId('PCF_OT_COST').getValue() === "" || this.getView().byId(
						'PCF_REINSTATEMENT_COST').getValue() === "" || this.getView().byId(
						'PCF_OTHER_MISC').getValue() === "" || this.getView().byId(
						'PCF_OCC_COST_USD').getValue() === "" ||
					this.getView().byId('PCF_CAP_COST_USD').getValue() === "" || this.getView().byId('PCF_OT_COST_USD').getValue() === "" || this.getView()
					.byId(
						'PCF_REINSTATEMENT_COST_USD').getValue() === "" || this.getView().byId(
						'PCF_OTHER_MISC_USD').getValue() === "" || this.getView().byId('PCF_DESC_JUST').getValue() === "" ||
					req_type.getValue() === "" || title.getValue() === "" || email.getValue() === "" || desc.getValue() === "" || onbehalfof.getValue() ===
					"" || phone.getValue() === "") {
					var warning = i18ntext_bundle.getText("Warning");
					sap.m.MessageBox.show(requiredFields, {
						title: warning,
						icon: sap.m.MessageBox.Icon.WARNING,
					});
					return;
				}
			}
			if (table.getItems().length > 0) {
				var emptyappr = "";
				for (var i = 0; i < table.getItems().length; i++) {
					if (table.getItems()[i].getCells()[1].mProperties.value === undefined)
						emptyappr = table.getItems()[i].getCells()[1].getText();
					else
						emptyappr = table.getItems()[i].getCells()[1].getValue();
					if (emptyappr === "") {
						var error = i18ntext_bundle.getText("Error");
						sap.m.MessageBox.show(emptyApprover, {
							title: error,
							icon: sap.m.MessageBox.Icon.ERROR,
						});
						return;
					}
				}
			}
			if (phone.getValue().length < 10 && phone.getValue() != "") {
				var pleaseenterrequestor10digits = i18ntext_bundle.getText("Pleaseenterrequestorphoneofatleast10digits");
				var error = i18ntext_bundle.getText("Error");
				MessageBox.show(
					pleaseenterrequestor10digits,
					MessageBox.Icon.ERROR,
					error
				);
				phone.setValueState("Error");
				return;
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Validation functionality for submiting request
			//************************************************************************************************************
			if (this.flag === "STPN") {
				var validationflag = this.STPNFieldsvalidation(false, "Submit");
				if (!validationflag) {
					return;
				}
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Validation functionality for submiting request
			//************************************************************************************************************
			this._postDataToBackend('In Approval');
		},
		_postDataToBackend: function (status) {
			var territory = this.byId('oSelectCountry');
			var customer_Company = this.byId('inpCustomer').getValue();
			var approved_date = this.byId('date_Approver').getValue();
			var selectedCurrency = this.byId('CURRENCY').getValue();
			var selectedCurrencyConv = this.byId('AMOUNT_DONATION_USD').getText().split(',').join('');
			var dateNeeded = this.getView().byId("DP2").getValue();
			var title = this.getView().byId("input_title").getValue();
			var desc = this.getView().byId("text_desc").getValue();
			var reqdate = this.getView().byId("text_request_date").getText();
			var chargedate = this.getView().byId("stpn_dp_ChargeDate").getValue();
			var onbehalfof = this.getView().byId("input_on_behalf_of").getValue();
			var preparer = this.getView().byId("text_Preparer").getText();
			var email = this.getView().byId("input_emailid").getValue();
			var phone = this.getView().byId("input_business_phone").getValue();
			var req_type = this.getView().byId("input_RequestType").getValue();
			var purpose = this.getView().byId("text_purpose").getValue();
			var inst = this.getView().byId("text_instruction").getValue();
			var vendorname = this.getView().byId("input_VendorName").getValue();
			var vendoradd = this.getView().byId("text_address").getValue();
			var payingentity = this.getView().byId("input_payingentity").getValue();
			var compcode = this.getView().byId("input_compcode").getValue();
			var glaccount = this.getView().byId("input_glaccount").getValue();
			var wbs = this.getView().byId("input_wbs").getValue();
			var amount = this.getView().byId("input_amount").getValue().split(',').join('');
			var invoice = this.getView().byId("text_invoice").getValue();
			var lob = this.getView().byId("input_lob").getValue();
			var sublob = this.getView().byId("input_sublob").getValue();
			var req_Desc = this.byId('text_ReqDesc').getValue();
			///REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING  FIELD FOR IMAGE:START
			// var image = btoa(encodeURI(this.getView().byId('ss').getSrc().replace("data:image/png;base64,", "")));

			//var image = this.getView().byId('ss').getSrc().replace("data:image/png;base64,", "");
			var image = this.getView().byId('ss').getSrc().replace("data:" + img_type + ";base64,", "");
			var image_type = img_type;
			// if(image==""){
			// 	this.getView().byId("ss1").setVisible("false");
			// }
			///REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FIELD FOR IMAGE:END
			var data = {};
			data.TERRITORY = territory.getValue();
			data.EFORM_NUM = e_form_num;
			data.TITLE = title;
			data.DESC = desc;
			data.ON_BEHALF_OF = onbehalfof;
			data.PREPARER = preparer;
			data.REQUESTER_EMAIL = email;
			data.REQUESTER_PHONE = phone;
			data.REQUEST_TYPE = req_type;
			// REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:START
			// if (req_type === 'Worldwide Facilities-PCF') {
			// 	data.ATTACHMENT_CHECKBOXES = true;
			// } else {
			// 	data.ATTACHMENT_CHECKBOXES = false;
			// }
			//REQ0600512:NSONI3:GWDK902137:09/18/2020:ADD NEW aTTACHMENT CHECKBOX COLUMN FOR WorldWide PCF TYPE:END
			data.PURPOSE = purpose;
			data.INSTRUCTIONS = inst;
			data.REQUEST_DESC = req_Desc;
			data.VENDOR_NAME = vendorname;
			data.VENDOR_ADDRESS = vendoradd;
			data.PAYING_ENTITY = payingentity;
			data.COMPANY_CODE = compcode;
			data.GENE_LEDGER = glaccount;
			data.REQUEST_DATE = reqdate;
			//data.CHARGED_DATE  = chargedate;                        
			data.WBS_ELEMENT = wbs;
			data.AMOUNT = amount;
			data.DATE_NEEDED = dateNeeded;
			data.INVOICE_DESC = invoice;
			data.STATUS = status;
			data.CURRENCY = selectedCurrency;
			data.AMOUNT_CONVERTED = selectedCurrencyConv;
			data.LOB = lob;

			data.SUBLOB = sublob;
			data.APPROVE_BY_DATE = approved_date;
			data.CUST_COMPANY = customer_Company;
			// New Fields of PCF
			data.PCF_TFADATE = this.getView().byId('PCF_TFADATE').getValue();
			data.PCF_LOB = this.getView().byId('PCF_LOB').getValue();

			// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
			data.PCF_RECOMMAND = this.getView().byId('PCF_RECOMMAND').getValue();
			// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END

			data.PCF_STATE = this.getView().byId('PCF_STATE').getValue();
			data.PCF_COUNTRY = this.getView().byId('PCF_COUNTRY').getValue();
			data.PCF_CITY = this.getView().byId('PCF_CITY').getValue();
			data.PCF_POSTAL_CODE = this.getView().byId('PCF_POSTAL_CODE').getValue();
			data.PCF_LOCATION = this.getView().byId('PCF_LOCATION').getValue();
			data.PCF_AREASM = this.getView().byId('PCF_AREASM').getValue().split(',').join('');
			data.PCF_AREASF = this.getView().byId('PCF_AREASF').getValue().split(',').join('');
			data.PCF_LEASE = this.getView().byId('PCF_LEASE').getValue();
			// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
			data.PCF_EXIT = this.getView().byId('PCF_EXIT').getValue();
			// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END
			data.PCF_LOCCURRENCY = this.getView().byId('PCF_LOCCURRENCY').getValue();
			data.PCF_OCC_COST = this.getView().byId('PCF_OCC_COST').getValue().split(',').join('');
			data.PCF_CAP_COST = this.getView().byId('PCF_CAP_COST').getValue().split(',').join('');
			data.PCF_OT_COST = this.getView().byId('PCF_OT_COST').getValue().split(',').join('');
			data.PCF_OTHER_MISC = this.getView().byId('PCF_OTHER_MISC').getValue().split(',').join('');
			data.PCF_GRAND_TOTAL = this.getView().byId('PCF_GRAND_TOTAL').getText().split(',').join('');
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from Text to Input:START
			// data.PCF_OCC_COST_USD = this.getView().byId('PCF_OCC_COST_USD').getText().split(',').join('');
			// data.PCF_CAP_COST_USD = this.getView().byId('PCF_CAP_COST_USD').getText().split(',').join('');
			// data.PCF_OT_COST_USD = this.getView().byId('PCF_OT_COST_USD').getText().split(',').join('');
			// data.PCF_OTHER_MISC_USD = this.getView().byId('PCF_OTHER_MISC_USD').getText().split(',').join('');

			data.PCF_OCC_COST_USD = this.getView().byId('PCF_OCC_COST_USD').getValue().split(',').join('');
			data.PCF_CAP_COST_USD = this.getView().byId('PCF_CAP_COST_USD').getValue().split(',').join('');
			data.PCF_OT_COST_USD = this.getView().byId('PCF_OT_COST_USD').getValue().split(',').join('');
			data.PCF_OTHER_MISC_USD = this.getView().byId('PCF_OTHER_MISC_USD').getValue().split(',').join('');
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Control changed from Text to Input:END
			data.PCF_GRAND_TOTAL_USD = this.getView().byId('PCF_GRAND_TOTAL_USD').getText().split(',').join('');
			data.PCF_DESC_JUST = this.getView().byId('PCF_DESC_JUST').getValue();
			data.PCF_COMPANY_CODE = this.getView().byId('PCF_COMPANY_CODE').getValue();
			data.PCF_PROFIT_CENTER = this.getView().byId('PCF_PROFIT_CENTER').getValue();
			data.PCF_COST_CENTER = this.getView().byId('PCF_COST_CENTER').getValue();

			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
			data.PCF_EXCHANGE_RATE = this.getView().byId('PCF_EXCHANGE_RATE').getValue();
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:START
			data.PCF_REINSTATEMENT_COST = this.getView().byId('PCF_REINSTATEMENT_COST').getValue().split(',').join('');
			data.PCF_REINSTATEMENT_COST_USD = this.getView().byId('PCF_REINSTATEMENT_COST_USD').getValue().split(',').join('');
			//REQ0589824:PJAIN6:GWDK902102:08/06/2020:New Field added:END
			// New Fields end of PCF
			// Start of : New fields for Finance Request Form
			data.FR_APPROVE_BY_DATE = this.getView().byId('AppDP').getValue();
			data.FR_COMPANY_CODE = this.getView().byId('input_comp').getValue();
			data.FR_LOB = this.getView().byId('fr_cmb_lob').getValue();
			data.FR_FISCAL_P_MONTH = this.getView().byId('fr_fis_month').getValue();
			data.FR_FISCAL_P_YEAR = this.getView().byId('fr_fis_year').getValue();
			data.FR_FISCAL_P_YEAR = this.getView().byId('fr_fis_year').getValue();
			data.FR_DOC_LINK = this.getView().byId('input_frdoclinks').getValue();
			data.FR_SAP_REF_DOC = this.getView().byId('fr_text_refdocs').getValue();
			data.FR_FIN_REQ_TYPE = this.getView().byId('fin_req_type').getValue();
			// end of : New fields for Finance Request Form
			//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FIELD FOR IMAGE:START
			data.PCF_IMAGE = image;
			data.PCF_IMAGE_TYPE = image_type;
			//REQ0600512:PJAIN6:GWDK902137:10/6/2020:ADDING FIELD FOR IMAGE:END

			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Posting data of new fields to backend
			//************************************************************************************************************
			if (req_type === "SPTN ProCard Payment Request") {
				if (compcode.split(" (")[0] !== undefined) {
					data.COMPANY_CODE = compcode.split(" (")[0];

				}
				if (data.COMPANY_CODE === "") {
					this.getView().byId("compcode_s").setVisible(false);
				} else {
					this.getView().byId("compcode_s").setVisible(true);
				}
				if (glaccount.split(" (")[0] !== undefined) {
					data.GENE_LEDGER = glaccount.split(" (")[0];
					if (data.GENE_LEDGER === "") {

					}
				}
				if (wbs.split(" (")[0] !== undefined) {
					data.WBS_ELEMENT = wbs.split(" (")[0];

				}
				if (data.WBS_ELEMENT === "") {
					this.getView().byId("wbs_s").setVisible(false);
				} else {
					this.getView().byId("wbs_s").setVisible(true);
				}

				var fundingDept = this.getView().byId('PCF_COST_CENTER').getValue();
				if (fundingDept.split(" (")[0] !== undefined) {
					data.PCF_COST_CENTER = fundingDept.split(" (")[0];

				}

				if (data.PCF_COST_CENTER === "") {
					this.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
				} else {
					this.getView().byId("stpn_fe_fundingDept_summary").setVisible(true);
				}
				this.getView().byId("chdt_s").setVisible(true);
				data.REQUEST_DATE = this.getView().byId("stpn_dp_RequestDate").getValue();
				data.CHARGED_DATE = this.getView().byId("stpn_dp_ChargeDate").getValue();
				data.VENDOR_NAME = this.getView().byId("stpn_ip_sapVendor").getValue();
				data.BUSINESS = (this.getView().byId("stpn_cb_business").data("sItemId") === null) ? 0 : this.getView().byId("stpn_cb_business").data(
					"sItemId");
				data.PUR_TYPE = (this.getView().byId("stpn_cb_purchaseType").data("sItemId") === null) ? 0 : this.getView().byId(
					"stpn_cb_purchaseType").data("sItemId");
				data.FORM_TYPE = (this.getView().byId("stpn_cb_formType").data("sItemId") === null) ? 0 : this.getView().byId("stpn_cb_formType").data(
					"sItemId");

			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Posting data of new fields to backend
			//************************************************************************************************************

			if (button_press === "Save")
				data.ACTION = "Save";
			else if (button_press === "Submit")
				data.ACTION = "Submit";
			var approverData = [];
			var approvertable = this.getView().byId("approver_table").getModel().getData();
			var oModel = this.getOwnerComponent().getModel("oData");
			sap.ui.core.BusyIndicator.show();
			var i = null;
			var approved = null;
			var manual = null
			var table = this.getView().byId("approver_table").getItems();
			var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
			for (i = 0; i < table.length; i++) {
				if (table[i].getCells()[0].getText() === oBundle.getText("Approved"))
					approved = 'X';
				else {
					approved = '';
				}

				manual = table[i].getCells()[6].data("Flag");
				// if (table[i].getCells()[6].getSelected() === true) {
				//  manual = 'X';
				// } else {
				//  manual = '';
				// }

				var tempappr;
				if (table[i].getCells()[1].mProperties.value === undefined)
					tempappr = table[i].getCells()[1].getText();
				else
					tempappr = table[i].getCells()[1].getValue();
				approverData.push({
					EFORM_NUM: e_form_num,
					ORGLEVEL: "",
					SEQUENCE: String(i + 1),
					APPROVED: approved,
					APPR: tempappr,
					REVIEWER_TYPE: table[i].getCells()[2].getText(),
					APPROVED_BY: table[i].getCells()[3].getText(),
					APPROVAL_DT: table[i].getCells()[4].getText(),
					APPROVAL_TM: table[i].getCells()[5].getText(),
					MANUAL: manual,
					ADDED_BY: table[i].getCells()[7].getText()
				});
			}
			if (approverData.length == 0) {
				//************************************************************************************************************
				//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
				//-------Start of Change Description: Adding SPTN ProCard Payment Request to the condition
				//************************************************************************************************************
				if ((req_type !== 'Japan TV Channels') && (req_type !== 'OPC Exception') && (req_type !== 'SPTN ProCard Payment Request')) {
					var pleaseenteronemanualapprover = i18ntext_bundle.getText("Pleaseenteratleastonemanualapprovertoproceed");
					var error = i18ntext_bundle.getText("Error");
					sap.m.MessageBox.show(pleaseenteronemanualapprover, {
						title: error,
						icon: sap.m.MessageBox.Icon.ERROR,
					});
					sap.ui.core.BusyIndicator.hide();
					return;
				}
			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Adding SPTN ProCard Payment Request to the condition
			//************************************************************************************************************
			if (((req_type === 'Japan TV Channels') || (req_type === 'OPC Exception') || (req_type === 'SPTN ProCard Payment Request')) && copy ===
				"X") {
				if (copy_lob != lob || copy_sublob != sublob || copy_on_behalf_of != onbehalfof) {
					approverData = [];
					copy = "";
				}
			}
			data.AdhocForm_Approvers = approverData;

			var that = this;
			oModel.create("/eFormAdhocForms", data, {
				async: false,
				success: function (oData, response) {
					that.eFormNumber = oData.EFORM_NUM;
					if (status === 'In Approval' && button_press === 'Submit') {
						that.getView().byId("save_button").setVisible(true);
						that.getView().byId("withdraw_button").setVisible(true);
						that.getView().byId("submit_button").setVisible(false);

						// Reset Attachment Delete button
						that.getView().byId("button_delete_attachment").setVisible(false);
						that.getView().byId("button_attachment_delete_summary").setVisible(false);

						that.getView().byId("buton_update_cmt").setVisible(false);
						that.getView().byId("button_delete_cmt").setVisible(false);

						that.getView().byId("buton_update_cmt_sum").setVisible(false);
						that.getView().byId("button_delete_cmt_sum").setVisible(false);

						// Make comments non editable
						var i = null;
						var table = that.getView().byId("t_comment1").getItems();
						for (i = 0; i < table.length; i++) {
							table[i].getCells()[1].setEnabled(Boolean(0));

						}
						i = null;
						var table2 = that.getView().byId("t_comment2").getItems();
						for (i = 0; i < table2.length; i++) {
							table2[i].getCells()[1].setEnabled(Boolean(0));

						}

						// that.getView().byId("i_comment_txt").setEditable(false);
						// that.getView().byId("i_comment_txt_sum").setEditable(false);

						// that.getView().byId("b_approve").setVisible(true);
						// that.getView().byId("b_reject").setVisible(true);
						// that.getView().byId("ValidateButton").setVisible(false);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(true);
							//S4R:PJAIN6:Home icon not visible:END
						}
						var formnum = oData.EFORM_NUM;
						var issubmitsuccessfully = i18ntext_bundle.getText("issubmittedsuccessfuly");
						issubmitsuccessfully = " " + issubmitsuccessfully;
						var msg = formnum.concat(issubmitsuccessfully);
						var success = i18ntext_bundle.getText("Success");
						var ok = i18ntext_bundle.getText("OK");
						MessageBox.show(
							msg, {
								title: success,
								actions: [ok],
								icon: MessageBox.Icon.SUCCESS,
							});
						setTimeout(that.approve_reject_button_dsp, 1000);
					} else if (status === 'In Approval' && button_press === 'Save') {
						// that.getView().byId("b_approve").setVisible(true);
						// that.getView().byId("b_reject").setVisible(true);
						that.getView().byId("save_button").setVisible(true);
						that.getView().byId("withdraw_button").setVisible(true);
						that.approve_reject_button_dsp();
						that.getView().byId("submit_button").setVisible(false);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						var formnum = oData.EFORM_NUM;
						var issavedsuccessfully = i18ntext_bundle.getText("issavedsuccessfuly");
						issavedsuccessfully = " " + issavedsuccessfully;
						var msg = formnum.concat(issavedsuccessfully);
						MessageBox.show(
							msg,
							MessageBox.Icon.SUCCESS);
						setTimeout(that.approve_reject_button_dsp, 1000);

					} else if (status === 'Rejected') {
						// that.getView().byId("b_approve").setVisible(true);
						// that.getView().byId("b_reject").setVisible(false);
						that.getView().byId("save_button").setVisible(true);
						that.getView().byId("withdraw_button").setVisible(false);
						that.getView().byId("submit_button").setVisible(true);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						var formnum = oData.EFORM_NUM;
						var issavedsuccessfully = i18ntext_bundle.getText("issavedsuccessfuly");
						issavedsuccessfully = " " + issavedsuccessfully;
						var msg = formnum.concat(issavedsuccessfully);
						MessageBox.show(
							msg,
							MessageBox.Icon.SUCCESS);
						setTimeout(that.approve_reject_button_dsp, 1000);
					}
					if (status === 'Withdrawn') {
						that.getView().byId("save_button").setVisible(true);
						that.getView().byId("withdraw_button").setVisible(false);
						that.getView().byId("submit_button").setVisible(true);
						that.getView().byId("print_button").setEnabled(true);
						// that.getView().byId("b_approve").setVisible(false);
						// that.getView().byId("b_reject").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:START
						// this.getView().byId("HOME").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:END
						var model = that.getView().getModel();
						var editmode = model.getProperty("/requestmode");
						editmode = Boolean(1);
						model.setProperty("/requestmode", editmode);
						var formnum = oData.EFORM_NUM;
						var iswithdrawnSuccessfuly = i18ntext_bundle.getText("iswithdrawnSuccessfuly");
						iswithdrawnSuccessfuly = " " + iswithdrawnSuccessfuly;
						var msg = formnum.concat(iswithdrawnSuccessfuly);
						MessageBox.show(
							msg,
							MessageBox.Icon.SUCCESS);
						setTimeout(that.approve_reject_button_dsp, 1000);
					}
					if (status === 'Data Saved') {
						//S4R:PJAIN6:Home icon not visible:START
						// this.getView().byId("HOME").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:END
						// that.getView().byId("b_approve").setVisible(false);
						// that.getView().byId("b_reject").setVisible(false);
						var formnum = oData.EFORM_NUM;
						var issavedsuccessfully = i18ntext_bundle.getText("issavedsuccessfuly");
						issavedsuccessfully = " " + issavedsuccessfully;
						var msg = formnum.concat(issavedsuccessfully);
						MessageBox.show(
							msg,
							MessageBox.Icon.SUCCESS
						);
						setTimeout(that.approve_reject_button_dsp, 1000);
					}
					if (status === 'Delete') {

						//S4R:PJAIN6:Home icon not visible:START
						// this.getView().byId("HOME").setVisible(false);
						//S4R:PJAIN6:Home icon not visible:ENDthat.getView().byId("HOME").setVisible(false);
						// that.getView().byId("b_approve").setVisible(false);
						// that.getView().byId("b_reject").setVisible(false);
						var formnum = oData.EFORM_NUM;
						var isdeletedsuccessfully = i18ntext_bundle.getText("isdeletedSuccessfuly");
						isdeletedsuccessfully = " " + isdeletedsuccessfully;
						var msg = formnum.concat(isdeletedsuccessfully);

						MessageBox.show(msg, {
							icon: MessageBox.Icon.SUCCESS,
							onClose: function (oAction) {
								// call search function over here
							}
						});
						setTimeout(that.approve_reject_button_dsp, 1000);
					}
					e_form_num = oData.EFORM_NUM;
					eform_status = oData.STATUS;

					// fetch approvers
					var relPath = "/eFormApprovers";
					var oFilter = new sap.ui.model.Filter(
						"EFORM_NUM",
						sap.ui.model.FilterOperator.EQ, e_form_num
					);
					oModel.read(relPath, {
						filters: [oFilter],
						success: function (oData, response) {
							var table = that.getView().byId('approver_table');
							table.removeAllItems(true);
							var counter = oData.results.length;
							if (counter > 0) {
								that.byId('txtPosition').setProperty('visible', true);
								that.byId('ENTRY_SEQUENCE').setProperty('visible', true);
							} else {
								that.byId('txtPosition').setProperty('visible', false);
								that.byId('ENTRY_SEQUENCE').setProperty('visible', false);
							}
							var i = 0;
							var oMod = that.getView().getModel();
							var apRows = oMod.getProperty("/approvers");
							var no_of_items = apRows.length;
							var t = no_of_items - 1;
							for (i = t; i >= 0; i--) {
								apRows.splice(i, 1);
							}
							oMod.setProperty("/approvers", apRows);
							// oTable.destroyItems();
							for (i = 0; i < counter; i++) {
								if (oData.results[i].APPROVED === "X") {
									oData.results[i].APPROVED = oBundle.getText("Approved");
								} else if (oData.results[i].APPROVED === "R") {
									oData.results[i].APPROVED = oBundle.getText("Rejected");
								}
								var item = {
									approved: oData.results[i].APPROVED,
									approver: oData.results[i].APPR,
									reviewer_type: oData.results[i].REVIEWER_TYPE,
									approved_by: oData.results[i].APPROVED_BY,
									approval_date: oData.results[i].APPROVAL_DT,
									approval_time: oData.results[i].APPROVAL_TM,
									manual_addition: oData.results[i].MANUAL,
									added_by: oData.results[i].ADDED_BY,
									added_on: oData.results[i].CREATION_DT,
									can_edit: Boolean(0)
								};
								apRows.push(item);
							}
							oMod.setProperty("/approvers", apRows);
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
						}
					});
					var oResourceModel = that.getView().getModel("i18n").getResourceBundle();
					var oText = oResourceModel.getText("AdhocApprovableForm", [e_form_num]);
					that.getView().byId("page").setText(oText);

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		resetFields: function () {
			this.getView().byId("input_title").setValueState("None");
			this.getView().byId("text_desc").setValueState("None");
			this.getView().byId("input_on_behalf_of").setValueState("None");
			this.getView().byId("input_business_phone").setValueState("None");
			this.getView().byId("input_emailid").setValueState("None");
			this.getView().byId("input_RequestType").setValueState("None");
			this.getView().byId("text_purpose").setValueState("None");
			this.getView().byId("text_instruction").setValueState("None");
			this.getView().byId("DP2").setValueState("None");
			this.getView().byId("input_VendorName").setValueState("None");
			this.getView().byId("text_address").setValueState("None");
			this.getView().byId("input_payingentity").setValueState("None");
			this.getView().byId("input_compcode").setValueState("None");
			this.getView().byId("input_glaccount").setValueState("None");
			this.getView().byId("input_wbs").setValueState("None");
			this.getView().byId("input_amount").setValueState("None");
			this.getView().byId("CURRENCY").setValueState("None");
			this.getView().byId("input_lob").setValueState("None");
			this.getView().byId("input_sublob").setValueState("None");
			this.getView().byId("oSelectCountry").setValueState("None");
			this.getView().byId("date_Approver").setValueState("None");
			this.getView().byId("inpCustomer").setValueState("None");
			this.getView().byId("text_invoice").setValueState("None");
			this.getView().byId("PCF_TFADATE").setValueState("None");
			this.getView().byId("PCF_LOB").setValueState("None");

			// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:START
			this.getView().byId("PCF_RECOMMAND").setValueState("None");
			// REQ0600512:NSONI3:GWDK902137:10/07/2020:ADD NEW RECOMMANDATION FIELD FOR WorldWide PCF TYPE:END

			this.getView().byId("PCF_STATE").setValueState("None");
			this.getView().byId("PCF_COUNTRY").setValueState("None");
			this.getView().byId("PCF_CITY").setValueState("None");
			this.getView().byId("PCF_POSTAL_CODE").setValueState("None");
			this.getView().byId("PCF_LOCATION").setValueState("None");
			this.getView().byId("PCF_AREASM").setValueState("None");
			this.getView().byId("PCF_AREASF").setValueState("None");
			this.getView().byId("PCF_LEASE").setValueState("None");
			// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:START
			this.getView().byId("PCF_EXIT").setValueState("None");
			// REQ0600512:NSONI3:GWDK902137:10/08/2020:ADD NEW Exit Options/Renewals FIELD FOR WorldWide PCF TYPE:END
			this.getView().byId("PCF_LOCCURRENCY").setValueState("None");
			this.getView().byId("PCF_OCC_COST").setValueState("None");
			this.getView().byId("PCF_CAP_COST").setValueState("None");
			this.getView().byId("PCF_OT_COST").setValueState("None");
			this.getView().byId("PCF_OTHER_MISC").setValueState("None");
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Resetting newly added input field:START
			this.getView().byId("PCF_OCC_COST_USD").setValueState("None");
			this.getView().byId("PCF_CAP_COST_USD").setValueState("None");
			this.getView().byId("PCF_OT_COST_USD").setValueState("None");
			this.getView().byId("PCF_OTHER_MISC_USD").setValueState("None");
			this.getView().byId("PCF_REINSTATEMENT_COST").setValueState("None");
			this.getView().byId("PCF_REINSTATEMENT_COST_USD").setValueState("None");
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Resetting newly added input field:END
			this.getView().byId("PCF_DESC_JUST").setValueState("None");
			this.getView().byId("PCF_COMPANY_CODE").setValueState("None");
			this.getView().byId("PCF_PROFIT_CENTER").setValueState("None");

			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:START
			this.getView().byId("PCF_EXCHANGE_RATE").setValueState("None");
			//REQ0589824:PJAIN6:GWDK902102:08/04/2020:Exchange rate field added:END

			this.getView().byId("PCF_COST_CENTER").setValueState("None");
			this.getView().byId("fin_req_type").setValueState('None');
			this.getView().byId("AppDP").setValueState('None');
			this.getView().byId("input_comp").setValueState('None');
			this.getView().byId("fr_cmb_lob").setValueState('None');
			this.getView().byId("fr_fis_month").setValueState('None');
			this.getView().byId("fr_fis_year").setValueState('None');
			this.getView().byId("input_frdoclinks").setValueState('None');
			this.getView().byId("fr_text_refdocs").setValueState('None');

			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------Start of Change Description: Reseting new fields
			//************************************************************************************************************
			this.getView().byId("stpn_dp_RequestDate").setValueState('None');
			this.getView().byId("stpn_dp_ChargeDate").setValueState('None');
			this.getView().byId("stpn_ip_fundingDept").setValueState('None');
			this.getView().byId("stpn_ip_sapVendor").setValueState('None');
			this.getView().byId("stpn_cb_business").setValueState('None');
			this.getView().byId("stpn_cb_purchaseType").setValueState('None');
			this.getView().byId("stpn_cb_formType").setValueState('None');
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: Reseting new fields
			//************************************************************************************************************

		},
		resetAttachments: function () {
			this.getView().byId("t_attachment1").destroyItems();
			this.getView().byId("t_attachment2").destroyItems();
		},
		resetComments: function () {
			this.getView().byId("textarea_comments").setValue("");
			this.getView().byId("textarea_comments2").setValue("");
			this.getView().byId("t_comment1").destroyItems();
			this.getView().byId("t_comment2").destroyItems();
		},
		_onPressEditForm: function () {
			var requestType = this.byId('input_RequestType').getValue();
			if ((requestType === 'Miscellaneous') || (requestType === 'Programming COFA') || (requestType === 'Sign-Off: BRD') || (requestType ===
					'Sign-Off: UAT') || (requestType === 'Sign-Off: Other') || (requestType === 'Sign-Off: FD/Level 7 Approval') || (requestType ===
					'Contract Approval Form') || (requestType === 'Residual Payment Control')) {
				this.flag = "A";
			} else if (requestType === 'Production Accounting Payment Request') {
				this.flag = "B";
			} else if (requestType === 'SPHE Media Budget Authorization') {
				this.flag = "C";
			} else if (requestType === 'OPC Exception') {
				this.flag = "D";
			} else if (requestType === 'Japan TV Channels') {
				this.flag = "E";
			} else if (requestType === 'Worldwide Facilities-PCF') {
				this.flag = "PCF";
			}
			var oModel = this.getOwnerComponent().getModel("oData");
			var that = this;
			oModel.read("/eFormInitialInfos('" + e_form_num + "')", {
				success: function (oData, response) {
					if (response.data.STATUS == "Not Authorised") {
						// edit is not allowed
						var youcannoteditform = i18ntext_bundle.getText("YoucannoteditthiseForm");
						MessageBox.alert(youcannoteditform);
						return;
					}
					if (response.data.STATUS == "Data Saved" || response.data.STATUS == "Withdrawn") {
						// edit is allowed
						var model = that.getView().getModel();
						var editmode = model.getProperty("/requestmode");
						editmode = Boolean(1);
						model.setProperty("/requestmode", editmode);
						MessageBox.alert("You can edit this eForm.");
						that.getView().byId("save_button").setVisible(true);
						that.getView().byId("withdraw_button").setVisible(false);
						that.getView().byId("submit_button").setVisible(true);
						that.getView().byId("print_button").setEnabled(true);

						// that.bindingCurrency();
					}
					if (response.data.STATUS == "Rejected") {
						// edit is allowed
						var model = that.getView().getModel();
						var editmode = model.getProperty("/requestmode");
						editmode = Boolean(1);
						model.setProperty("/requestmode", editmode);
						var youcaneditthiseform = i18ntext_bundle.getText("YoucaneditthiseForm");
						MessageBox.alert(youcaneditthiseform);
						that.getView().byId("save_button").setVisible(true);
						that.getView().byId("approve").setVisible(true);
						that.getView().byId("reject").setVisible(false);
						that.getView().byId("withdraw_button").setVisible(true);
						that.getView().byId("submit_button").setVisible(false);
						if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							//S4R:PJAIN6:Home icon not visible:START
							// this.getView().byId("HOME").setVisible(false);
							//S4R:PJAIN6:Home icon not visible:END
						}
						that.getView().byId("print_button").setEnabled(true);
						// that.bindingCurrency();
					}
					if (response.data.STATUS == "In Approval") {
						// that.byId('b_approve').setVisible(true);
						// that.byId('b_reject').setVisible(true);
						that._onButtonPressWithdraw();
					}
					if (response.data.STATUS == "Approved") {
						var youcannoteditapprovedeform = i18ntext_bundle.getText("YoucannoteditthisapprovedeForm");
						MessageBox.alert(youcannoteditapprovedeform);
						return;
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onPressDeleteForm: function () {
			var oModel = this.getOwnerComponent().getModel("oData");
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var that = this;
			oModel.read("/eFormInitialInfos('" + e_form_num + "')", {
				success: function (oData, response) {
					if (response.data.STATUS == "Not Authorised") {
						// edit is allowed
						var youcannotdeleteeform = i18ntext_bundle.getText("YoucannotDeletethiseForm");
						MessageBox.alert(youcannotdeleteeform);
						return;
					} else if (response.data.STATUS == "Approved") {
						var youcannotdeleteeform = i18ntext_bundle.getText("YoucannotDeletethiseForm");
						MessageBox.alert(youcannotdeleteeform);
						return;

					} else {
						new Promise(function (fnResolve) {
							var Areyousureyouwanttodeletethisform = i18ntext_bundle.getText("Areyousureyouwanttodeletethisform");
							var ConfirmDelete = i18ntext_bundle.getText("ConfirmDelete");

							sap.m.MessageBox.confirm(Areyousureyouwanttodeletethisform, {
								title: ConfirmDelete,
								actions: ["Yes", "No"],
								onClose: function (sActionClicked) {
									if (sActionClicked === "Yes") {
										// that._postDataToBackend('Withdrawn');
										that._postDataToBackend('Delete');
										that.oRouter.navTo("default", {
											from: "AdhocCreate"
										}, false);
									} else {}
								}
							});
						}).catch(function (err) {
							if (err !== undefined) {
								MessageBox.error(err);
							}
						});
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onButtonPressWithdraw: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel("oData");
			var that1 = this;
			oModel.read("/eFormInitialInfos('" + e_form_num + "')", {
				success: function (oData, response) {
					if (response.data.STATUS == "Not Authorised") {
						// edit is not allowed
						var YoucannotwithdrawthiseForm = i18ntext_bundle.getText("YoucannotwithdrawthiseForm");
						MessageBox.alert(YoucannotwithdrawthiseForm);
						return;
					} else {
						var oModel = that1.getOwnerComponent().getModel("oData");
						var s = {};
						var that = that1;
						var curr_view = that1.getView();
						window.eform_withdraw;
						if (response.data.STATUS === "Rejected") {
							that._postDataToBackend('Withdrawn');
							that._onRefreshApprovers();
							// Reset Attachment Delete button
							that.getView().byId("button_delete_attachment").setVisible(true);
							that.getView().byId("button_attachment_delete_summary").setVisible(true);

							that.getView().byId("buton_update_cmt").setVisible(true);
							that.getView().byId("button_delete_cmt").setVisible(true);

							that.getView().byId("buton_update_cmt_sum").setVisible(true);
							that.getView().byId("button_delete_cmt_sum").setVisible(true);
							// that.getView().byId("i_comment_txt").setEditable(true);
							// that.getView().byId("i_comment_txt_sum").setEditable(true);

							//                    Make comments editable
							var i = null;
							var table = that.getView().byId("t_comment1").getItems();
							for (i = 0; i < table.length; i++) {
								table[i].getCells()[1].setEnabled(Boolean(1));

							}
							i = null;
							var table2 = that.getView().byId("t_comment2").getItems();
							for (i = 0; i < table2.length; i++) {
								table2[i].getCells()[1].setEnabled(Boolean(1));

							}
						} else {
							new Promise(function (fnResolve) {
								var DoyouwanttoCanceltheworkflow = i18ntext_bundle.getText("DoyouwanttoCanceltheworkflow");
								var ConfirmWithdraw = i18ntext_bundle.getText("ConfirmWithdraw");
								sap.m.MessageBox.confirm(DoyouwanttoCanceltheworkflow, {
									title: ConfirmWithdraw,
									actions: ["Yes", "No"],
									onClose: function (sActionClicked) {
										if (sActionClicked === "Yes") {
											that._postDataToBackend('Withdrawn');
											that._onRefreshApprovers();
											// Reset Attachment Delete button
											that.getView().byId("button_delete_attachment").setVisible(true);
											that.getView().byId("button_attachment_delete_summary").setVisible(true);

											that.getView().byId("buton_update_cmt").setVisible(true);
											that.getView().byId("button_delete_cmt").setVisible(true);

											that.getView().byId("buton_update_cmt_sum").setVisible(true);
											that.getView().byId("button_delete_cmt_sum").setVisible(true);
											// that.getView().byId("i_comment_txt").setEditable(true);
											// that.getView().byId("i_comment_txt_sum").setEditable(true);

											//                    Make comments editable
											var i = null;
											var table = that.getView().byId("t_comment1").getItems();
											for (i = 0; i < table.length; i++) {
												table[i].getCells()[1].setEnabled(Boolean(1));

											}
											i = null;
											var table2 = that.getView().byId("t_comment2").getItems();
											for (i = 0; i < table2.length; i++) {
												table2[i].getCells()[1].setEnabled(Boolean(1));

											}

										} else {}
									}
								});
							}).catch(function (err) {
								if (err !== undefined) {
									MessageBox.error(err);
								}
							});
						}
						if (window.eform_withdraw == "X") {}
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onPressUpdateComment: function (oEvent) {
			var c = {};
			var oModel = this.getOwnerComponent().getModel("oData");
			if (oEvent.getSource().getId().includes("buton_update_cmt"))
				var selected_item = this.getView().byId("t_comment1").getSelectedItem();
			else
				var selected_item = this.getView().byId("t_comment2").getSelectedItem();
			if (selected_item === null) {
				var Selectanycommenttoupdate = i18ntext_bundle.getText("Selectanycommenttoupdate");
				MessageBox.alert(Selectanycommenttoupdate);
			} else {
				var c = {};
				c.FORM_NO = e_form_num;
				c.COMMENTS = selected_item.getCells()[1].getValue();
				c.SEQUENCE = selected_item.getCells()[0].getText();
				c.CREATOR = "";
				c.CR_DATE = "";
				c.TIME = "";
				c.ACTION = "";
				var that = this;
				if (selected_item.getCells()[2].getText() == logger_name) {

					oModel.create("/eFormComments", c, {
						async: false,
						success: function (oData, response) {
							var Commentupdatedsuccessfully = i18ntext_bundle.getText("Commentupdatedsuccessfully");
							var msg = Commentupdatedsuccessfully;
							MessageBox.show(
								msg,
								MessageBox.Icon.SUCCESS
							);
							sap.ui.core.BusyIndicator.hide();
							var relPath = "/eFormComments";
							var oModel = that.getOwnerComponent().getModel("oData");
							var oFilter = new sap.ui.model.Filter(
								"FORM_NO",
								sap.ui.model.FilterOperator.EQ, e_form_num
							);
							oModel.read(relPath, {
								filters: [oFilter],
								success: function (oData, response) {
									that.getView().byId("t_comment1").destroyItems();
									var counter = oData.results.length;
									var i = 0;
									for (i = 0; i < counter; i++) {
										var table = that.getView().byId("t_comment1");
										var vedit = oData.results[i].EDIT;
										if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
											vedit = Boolean(0);
										}
										var data = new sap.m.ColumnListItem({
											cells: [
												new sap.m.Text({
													text: oData.results[i].SEQUENCE
												}),
												new sap.m.TextArea({
													value: oData.results[i].COMMENTS,
													rows: 2,
													cols: 70,
													enabled: vedit
												}),
												new sap.m.Text({
													text: oData.results[i].CREATOR
												}),
												new sap.m.Text({
													text: oData.results[i].CR_DATE
												})
											]
										})
										table.addItem(data);
									} // for
									that.getView().byId("t_comment2").destroyItems();
									var counter = oData.results.length;
									var i = 0;
									for (i = 0; i < counter; i++) {
										var table = that.getView().byId("t_comment2");
										var vedit = oData.results[i].EDIT;
										if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
											vedit = Boolean(0);
										}
										var data = new sap.m.ColumnListItem({
											cells: [
												new sap.m.Text({
													text: oData.results[i].SEQUENCE
												}),
												new sap.m.TextArea({
													value: oData.results[i].COMMENTS,
													rows: 2,
													cols: 70,
													enabled: vedit
												}),
												new sap.m.Text({
													text: oData.results[i].CREATOR
												}),
												new sap.m.Text({
													text: oData.results[i].CR_DATE
												})
											]
										})
										table.addItem(data);
									}
								},
								error: function (oError) {
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
									sap.ui.core.BusyIndicator.hide();
								}
							});
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
				} else {
					var Commentcannotbeupdated = i18ntext_bundle.getText("Commentcannotbeupdated");
					MessageBox.alert(Commentcannotbeupdated);
				}
			}
		},
		_onPressDeleteComment: function (oEvent) {
			var c = {};
			var oModel = this.getOwnerComponent().getModel("oData");
			if (oEvent.getSource().getId().includes("button_delete_cmt"))
				var selected_item = this.getView().byId("t_comment1").getSelectedItem();
			else
				var selected_item = this.getView().byId("t_comment2").getSelectedItem();
			if (selected_item === null) {
				var Selectanycommenttodelete = i18ntext_bundle.getText("Selectanycommenttodelete");
				MessageBox.alert(Selectanycommenttodelete);
			} else {
				var c = {};
				c.FORM_NO = e_form_num;
				c.COMMENTS = selected_item.getCells()[1].getValue();
				c.SEQUENCE = selected_item.getCells()[0].getText();
				c.CREATOR = "";
				c.CR_DATE = "";
				c.TIME = "";
				c.ACTION = "Delete";
				var that = this;
				if (selected_item.getCells()[2].getText() == logger_name) {
					oModel.create("/eFormComments", c, {
						async: false,
						success: function (oData, response) {
							var Commentdeletedsuccessfully = i18ntext_bundle.getText("Commentdeletedsuccessfully");
							var msg = Commentdeletedsuccessfully;
							MessageBox.show(
								msg,
								MessageBox.Icon.SUCCESS
							);
							sap.ui.core.BusyIndicator.hide();
							var relPath = "/eFormComments";
							var oModel = that.getOwnerComponent().getModel("oData");
							var oFilter = new sap.ui.model.Filter(
								"FORM_NO",
								sap.ui.model.FilterOperator.EQ, e_form_num
							);
							oModel.read(relPath, {
								filters: [oFilter],
								success: function (oData, response) {
									that.getView().byId("t_comment1").destroyItems();
									var counter = oData.results.length;
									var i = 0;
									for (i = 0; i < counter; i++) {
										var table = that.getView().byId("t_comment1");
										var vedit = oData.results[i].EDIT;
										if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
											vedit = Boolean(0);
										}
										var data = new sap.m.ColumnListItem({
											cells: [
												new sap.m.Text({
													text: oData.results[i].SEQUENCE
												}),
												new sap.m.TextArea({
													value: oData.results[i].COMMENTS,
													rows: 2,
													cols: 70,
													enabled: vedit
												}),
												new sap.m.Text({
													text: oData.results[i].CREATOR
												}),
												new sap.m.Text({
													text: oData.results[i].CR_DATE
												})
											]
										})
										table.addItem(data);
									} // for
									that.getView().byId("t_comment2").destroyItems();
									var counter = oData.results.length;
									var i = 0;
									for (i = 0; i < counter; i++) {
										var table = that.getView().byId("t_comment2");
										var vedit = oData.results[i].EDIT;
										if (eform_status !== "Data Saved" && eform_status !== "Withdrawn") {
											vedit = Boolean(0);
										}
										var data = new sap.m.ColumnListItem({
											cells: [
												new sap.m.Text({
													text: oData.results[i].SEQUENCE
												}),
												new sap.m.TextArea({
													value: oData.results[i].COMMENTS,
													rows: 2,
													cols: 70,
													enabled: vedit
												}),
												new sap.m.Text({
													text: oData.results[i].CREATOR
												}),
												new sap.m.Text({
													text: oData.results[i].CR_DATE
												})
											]
										})
										table.addItem(data);
									}
								},
								error: function (oError) {
									var response = JSON.parse(oError.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
									sap.ui.core.BusyIndicator.hide();
								}
							});
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
				} else {
					var Commentcannotbedeleted = i18ntext_bundle.getText("Commentcannotbedeleted");
					MessageBox.alert(Commentcannotbedeleted);
				}
			}
		},
		//************************************************************************************************************
		//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
		//-------Start of Change Description: SPTN ProCard Payment Request Methods
		//************************************************************************************************************

		// Method for selectionChange event of business/purchase type/form type combo box
		onSelectionChangeCombo: function (oEvent) {
			var sItemId = oEvent.getParameter("selectedItem").data("ID");
			oEvent.getSource().data("sItemId", sItemId);
		},

		// Method to hide the STPN request fields
		hideSTPNFields: function (oInstance) {
			oInstance.getView().byId("stpn_fe_ChargeDate").setVisible(false);
			oInstance.getView().byId("stpn_fe_fundingDept").setVisible(false);
			oInstance.getView().byId("stpn_fe_sapVendor").setVisible(false);
			oInstance.getView().byId("stpn_fe_business").setVisible(false);
			oInstance.getView().byId("stpn_fe_purchaseType").setVisible(false);
			oInstance.getView().byId("stpn_fe_formType").setVisible(false);
			oInstance.getView().byId("stpn_fe_or").setVisible(false);
			oInstance.getView().byId("compcode").getAggregation("label").setRequired(false);
			oInstance.getView().byId("wbs").getAggregation("label").setRequired(true);

			// Summary Tab Fields

			oInstance.getView().byId("compcode_s").getAggregation("label").setRequired(false);
			oInstance.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
			oInstance.getView().byId("stpn_fe_sapVendor_summary").setVisible(false);
			oInstance.getView().byId("stpn_fe_fundingDept_summary").setVisible(false);
			oInstance.getView().byId("stpn_fe_business_summary").setVisible(false);
			oInstance.getView().byId("stpn_fe_purchaseType_summary").setVisible(false);
			oInstance.getView().byId("stpn_fe_formType_summary").setVisible(false);
		},

		// Method for STPN request fields validation
		STPNFieldsvalidation: function (messageFlag, action) {
			var iPurpose = this.getView().byId("text_purpose");
			var iInstruction = this.getView().byId("text_instruction");
			var iRequestDate = this.getView().byId("stpn_dp_RequestDate");
			var iChargeDate = this.getView().byId("stpn_dp_ChargeDate");
			var iCompanyCode = this.getView().byId("input_compcode");
			var iSAPVendor = this.getView().byId("stpn_ip_sapVendor");
			var iLob = this.getView().byId("input_lob");
			var iSubLob = this.getView().byId("input_sublob");
			var iGlAccount = this.getView().byId("input_glaccount");
			var iWbsElement = this.getView().byId("input_wbs");
			var iFundingDept = this.getView().byId("stpn_ip_fundingDept");
			var iAmount = this.getView().byId("input_amount");
			var iCurrency = this.getView().byId("CURRENCY");
			var iAmountUsd = this.getView().byId("AMOUNT_DONATION_USD");
			var iInvoiceDescription = this.getView().byId("text_invoice");
			var iBusiness = this.getView().byId("stpn_cb_business");
			var iPurchaseType = this.getView().byId("stpn_cb_purchaseType");
			var iFormType = this.getView().byId("stpn_cb_formType");

			var desc = this.getView().byId("text_desc");
			var onbehalfof = this.getView().byId("input_on_behalf_of");
			var phone = this.getView().byId("input_business_phone");
			var email = this.getView().byId("input_emailid");

			var validationCounter = 0;
			var aControl = [iPurpose, iInstruction, iRequestDate, iCompanyCode, iSAPVendor, iLob, iSubLob, iGlAccount, iAmount,
				iInvoiceDescription, iBusiness, iPurchaseType, desc, onbehalfof, phone, email
			];
			aControl.forEach(function (item, index) {
				if (item.getValue() === "") {
					validationCounter++;
					item.setValueState('Error');
					item.setValueStateText('Required');
				} else if (item.getValue() !== "") {
					item.setValueState('None');
					item.setValueStateText('');
				}
			}, this);

			if (((iWbsElement.getValue() !== "" && iWbsElement.getValue() !== " ()") && (iFundingDept.getValue() !== "" && iFundingDept.getValue() !==
					" ()")) || ((iWbsElement.getValue() === "" || iWbsElement.getValue() === " ()") && (iFundingDept.getValue() ===
					"" || iFundingDept.getValue() === " ()"))) {
				messageFlag = false;
				if (messageFlag !== 'true') {
					var warning = i18ntext_bundle.getText("Error");
					var messageText = i18ntext_bundle.getText("WBSFundingBlankValidation");
					sap.m.MessageBox.show(messageText, {
						title: warning,
						icon: sap.m.MessageBox.Icon.ERROR,
					});
					iWbsElement.setValue("");
					iFundingDept.setValue("");
					if (action !== "Save") {
						return;
					}
				}
			}

			var cLOB = (iLob.getValue() === "SPT - NETW");
			var cSubLOB = (iSubLob.getValue() === "CRACKLE, MOVIE CHANNEL & OTHER NETWORKS");
			var cAmount = (Number(iAmount.getValue().split(',').join('')) > 60000);
			var cAmountUsd = (Number(iAmountUsd.getText().split(',').join('')) > 60000);
			var cCurrency = (iCurrency.getValue() === "USD");
			if (iLob && cSubLOB && cAmount && cCurrency) {

				iAmount.setValueState('Error');
				iAmount.setValueStateText('Please enter an amount less than $60,000');
				var error = i18ntext_bundle.getText("Error");
				var messageText = i18ntext_bundle.getText("amountValidation");
				sap.m.MessageBox.show(messageText, {
					title: error,
					icon: sap.m.MessageBox.Icon.ERROR
				});
				if (action !== "Save") {
					return;
				}

			} else if (iLob && cSubLOB && cAmountUsd) {
				iAmount.setValueState('Error');
				iAmount.setValueStateText('Less than 60,000 USD');
				var error = i18ntext_bundle.getText("Error");
				var messageText = i18ntext_bundle.getText("amountValidation");
				sap.m.MessageBox.show(messageText, {
					title: error,
					icon: sap.m.MessageBox.Icon.ERROR
				});
				if (action !== "Save") {
					return;
				}

			} else {
				iAmount.setValueState('None');
				iAmount.setValueStateText('');
			}

			if (iFormType.getSelectedKey() !== "1") {
				var warning = i18ntext_bundle.getText("Error");
				var messageText = i18ntext_bundle.getText("GiftFormValidation");
				sap.m.MessageBox.show(messageText, {
					title: warning,
					icon: sap.m.MessageBox.Icon.ERROR,
				});
				if (action !== "Save") {
					return;
				}
			}

			if (validationCounter > 0) {
				if (messageFlag != 'true') {
					var warning = i18ntext_bundle.getText("Error");
					var messageText = i18ntext_bundle.getText("PleaseEnterMandatoryParameters");
					sap.m.MessageBox.show(messageText, {
						title: warning,
						icon: sap.m.MessageBox.Icon.ERROR,
					});

				}
				return (action === "Submit") ? undefined : 'true';
			} else {
				return 'true';
			}

		},

		// Method for selectionChange event of Icon tab bar
		onSelectIconTabBar: function (oEvent) {

				var itbKey = oEvent.getParameter("selectedKey");
				var reqType = this.getView().byId("input_RequestType").getValue();
				var tabRows = this.getView().byId("approver_table").getItems().length;
				var btnAdd = this.getView().byId("btnApproverAdd");

				if (itbKey === "itbApprovalFlow" && reqType === "SPTN ProCard Payment Request" && tabRows === 0) {
					btnAdd.setEnabled(false);
				} else {
					btnAdd.setEnabled(true);
				}

			}
			//************************************************************************************************************
			//-------Request Number:REQ034679------------------------- Description:SPTN ProCard Payment Request
			//-------End of Change Description: SPTN ProCard Payment Request Methods
			//************************************************************************************************************

	});
});