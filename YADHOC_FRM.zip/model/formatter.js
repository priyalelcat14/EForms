sap.ui.define([], function () {
	"use strict";
	return {

		chkBoxValidation: function (sFlag) {

			if (sFlag === "X") {
				return true;
			} else {
				return false;
			}
		}
	};
});