sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, JSONModel, MessageBox, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.spe.YPROFCENTER_REQFORM.controller.SearchPc", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.spe.YPROFCENTER_REQFORM.view.SearchPc
		 */
		onInit: function () {
			this._component = this.getOwnerComponent();
			this._serverModel = this._component.getModel();
			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);

		},
		_onObjectMatched: function (oEvent) {
			var searchModel = new JSONModel();
			this._component.setModel(searchModel, "searchModel");
			this.getView().byId("form_status").setSelectedKey("");
			this.getView().byId("fromDate").setValue("");
			this.getView().byId("toDate").setValue("");
			this.getView().byId("created_by").setValue("");
			this.getView().byId("form_num").setValue("");
			this.getView().byId("request_type").setSelectedKey("");

		},

		addFilter: function (filterArray, filteredField, filterValueArray, filterOperator) {
			var oFilter;
			if (filterOperator === "EQ") {
				oFilter = new Filter(
					filteredField,
					FilterOperator.EQ, filterValueArray[0]
				);
				filterArray.push(oFilter);
			} else if (filterOperator === "BT") {
				oFilter = new Filter(
					filteredField,
					FilterOperator.BT, filterValueArray[0], filterValueArray[1]
				);
				filterArray.push(oFilter);
			}
		},

		search_records: function () {

			var filterArray = [];

			var fromDate = this.getView().byId("fromDate").getValue();
			var toDate = this.getView().byId("toDate").getValue();
			if (this.getView().byId("created_by").getCustomData()[0] != undefined && this.getView().byId("created_by").getCustomData()[0] !==
				null) {
				var created_by = this.getView().byId("created_by").getCustomData()[0].getValue();
			}

			var form_num = this.getView().byId("form_num").getValue();
			var form_status = "";
			if (this.getView().byId("form_status").getSelectedItem() !== null) {
				form_status = this.getView().byId("form_status").getSelectedKey();
			}
			var request_type = "";
			if (this.getView().byId("request_type").getSelectedItem() !== null) {
				request_type = this.getView().byId("request_type").getSelectedKey();
			}

			// this.addFilter(filterArray, "crdat", [fromDate, toDate], "BT");
			// this.addFilter(filterArray, "crnam", [created_by], "EQ");
			// this.addFilter(filterArray, "mdmnr", [form_num], "EQ");
			// this.addFilter(filterArray, "Status_text", [form_status], "EQ");
			// this.addFilter(filterArray, "crdat", [request_type], "EQ");
			// var oFilter1 = new sap.ui.model.Filter(
			// 	"crdat",
			// 	sap.ui.model.FilterOperator.BT, fromDate, toDate
			// );
			var oFilter2 = new sap.ui.model.Filter("mdmnr", sap.ui.model.FilterOperator.Contains, form_num);
			var oFilter3 = new sap.ui.model.Filter("crnam", sap.ui.model.FilterOperator.EQ, created_by);
			// var oFilter4 = new sap.ui.model.Filter("crdat", sap.ui.model.FilterOperator.BT, [fromDate, toDate]);
			var oFilter5 = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, form_status);
			var oFilter6 = new sap.ui.model.Filter("rtype", sap.ui.model.FilterOperator.EQ, request_type);
			var myfilter = [];
			var oFilter4 = new sap.ui.model.Filter(
				"crdat",
				sap.ui.model.FilterOperator.BT, fromDate, toDate
			);
			if (oFilter4.oValue1 != "") {
				myfilter.push(oFilter4);
			}
			// if(oFilter1!=""){
			// myfilter.push(oFilter1);
			//   }
			if (oFilter2.oValue1 != "") {
				myfilter.push(oFilter2);
			}
			if (oFilter3.oValue1 != "" && oFilter3.oValue1 != undefined) {
				myfilter.push(oFilter3);
			}
			//   if(oFilter4.oValue1 != ""){
			// myfilter.push(oFilter4);
			//   }
			if (oFilter5.oValue1 != "") {
				myfilter.push(oFilter5);
			}
			if (oFilter6.oValue1 != "") {
				myfilter.push(oFilter6);
			}

			var that = this;
			var url = "/YFPSFICDS0033_MDMA_H";
			this._serverModel.read(url, {
				filters: myfilter,
				success: function (oData) {
					var data = {
						searchData: oData.results,
						totalCount: oData.results.length
					};
					var searchModel = new JSONModel();
					that._component.setModel(searchModel, "searchModel");
					that._component.getModel("searchModel").setData(data);
				},
				error: function (error) {
					var response = JSON.parse(error.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
				}
			});
			this.getView().byId("created_by").destroyCustomData();
			fromDate = "";
			toDate = "";

		},
		onSelection: function (oEvent) {
			var oTable = oEvent.getSource().getSelectedItem().getBindingContext("searchModel");
			var Row = oTable.oModel.getProperty(oTable.sPath);
			Row.__metadata = '';
			var a = JSON.stringify(Row);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo('CreatePCValue', {
				context: a
			});
		},

		// onPressFormNumber: function (oEvent) {
		// 	var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// 	oRouter.navTo('CreatePCValue', {
		// 		context: oEvent.oSource.mProperties.text
		// 	});
		// },
		createdValueHelpRequest: function (oEvent) {
			var userName = oEvent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: "Choose Value Created By",
				items: {
					path: "/YfpsfishlpUsernameSet",
					template: new sap.m.StandardListItem({
						title: "{nametextc}",
						description: "{bname}",
						//active: true
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"mcnamefir",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter([oFilter]);
				},

				confirm: function (oEvent) {
					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
						userName.setValue(oSelectedItem.getTitle());
						userName.data("key", oSelectedItem.getDescription());
					}
				}
			});
			// }
			var model = this.getOwnerComponent().getModel();
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();

		},
		onPress: function (oEvent) {
			var oItem = oEvent.getSource();
			var oTable = oItem.getBindingContext("searchModel");
			var Row = oTable.oModel.getProperty(oTable.sPath);
			// Row.__metadata = '';
			// var a = JSON.stringify(Row);
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo('CreatePCValue', {
				context: Row.mdmnr
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.spe.YPROFCENTER_REQFORM.view.SearchPc
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.spe.YPROFCENTER_REQFORM.view.SearchPc
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.spe.YPROFCENTER_REQFORM.view.SearchPc
		 */
		//	onExit: function() {
		//
		//	}

	});

});