sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/m/Token",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast"
], function (Controller, Fragment, JSONModel, MessageBox, Token, Filter, FilterOperator, DateFormat, MessageToast) {
	"use strict";
	// var sResponsivePaddingClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer";
	var form_number = "";
	var file_size;
	return Controller.extend("com.spe.YPROFCENTER_REQFORM.controller.CreatePC", {

		onInit: function () {

			this._component = this.getOwnerComponent();
			var model = this._component.getModel("oDataModel");
			var CreateProfitModel = new JSONModel();

			this._component.setModel(CreateProfitModel, "CreateProfitModel");
			// CreateProfitModel.setProperty("/extend_cc", true);
			var EnableModel = new JSONModel();

			this._component.setModel(EnableModel, "EnableModel");

			var approverModel = new JSONModel();
			this._component.setModel(approverModel, "approverModel");

			var commentModel = new JSONModel();
			this._component.setModel(commentModel, "commentModel");
			var EditProfitModel = new JSONModel();
			this._component.setModel(EditProfitModel, "EditProfitModel");

			this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.oRouter.attachRouteMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function (oEvent) {
			// this.getView().byId("summary").setVisible(false);
			this.form_number = "";
			//clearing company code values already entered
			this.getView().byId("comp_code2").setTokens([]); //create form
			this.getView().byId("ccomp_code2").setTokens([]); //change form
			this.valueStateSet();
			//clearing attachment section :START
			// var selected_item = this.getView().byId("t_attachment1").getSelectedItem();
			// this.getView().byId("t_attachment1").removeItem(selected_item);
			this.getView().byId("t_attachment1").destroyItems();
			//End
			var CreateProfitModel = new JSONModel();
			this._component.setModel(CreateProfitModel, "CreateProfitModel");
			// CreateProfitModel.setProperty("/extend_cc",true);
			var approverModel = new JSONModel();
			this._component.setModel(approverModel, "approverModel");
			var commentModel = new JSONModel();
			this._component.setModel(commentModel, "commentModel");
			var EnableModel = new JSONModel();
			this._component.setModel(EnableModel, "EnableModel");
			//Setting values of name ,lastname and email from current session
			var email = new sap.ushell.Container.getService("UserInfo").getUser().getEmail();
			var fname = new sap.ushell.Container.getService("UserInfo").getUser().getEmail().split("@")[0].split("_")[0];
			var lname = new sap.ushell.Container.getService("UserInfo").getUser().getEmail().split("@")[0].split("_")[1];
			//Setting them to the model
			CreateProfitModel.setProperty("/smtp_addr", email);
			CreateProfitModel.setProperty("/mc_namefir", fname);
			CreateProfitModel.setProperty("/mc_namelas", lname);
			//setting the buttons visibilty false for approve and reject 
			this.getView().byId("B03").setVisible(false);
			this.getView().byId("B05").setVisible(false);
			//Actions needs to be done if the form is Change form
			if (oEvent.getParameters().name == "EditPC") {
				EnableModel = this._component.getModel("EnableModel");
				this.basicAllow(true, false);
				EnableModel.setProperty("/edit", false);
				EnableModel.setProperty("/allow_edit", false);
				//deep change
				EnableModel.setProperty("/allow_val_seg", true);
				//deep change end

				this.getView().byId("ref_pc_label").setText("Profit Center");
				this.getView().byId("comp_code21").setText("Extending company codes");
				this.getView().byId("pageId").setTitle("Change Profit Center");
				this.getView().byId("ref_pc_label").setRequired(true);
				this.required_fields(false);
				this.getView().byId("summary").setVisible(true);
				// this.getView().byId("fromDate").setEnabled(false);
				CreateProfitModel = this._component.getModel("CreateProfitModel");
				CreateProfitModel.setProperty("/rtype", "ED");
			} else {
				//setting validity date by default :START
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});
				var datab = dateFormat.format(new Date());
				var datbi = dateFormat.format(new Date("12/31/9999"));
				CreateProfitModel.setProperty("/datab", datab);
				CreateProfitModel.setProperty("/datbi", datbi);
				// this.getView().byId("fromDate").setValue(datab);
				// this.getView().byId("toDate").setValue(datbi);
				//setting validity date by default :START						
				//new additionfor change
				this.getView().byId("ref_pc_label").setText("Reference Profit Center Number/Series");
				this.getView().byId("ref_pc_label").setRequired(false);
				this.required_fields(true);
				this.getView().byId("comp_code21").setText("Please indicate the applicable Company Code(s)");
				this.getView().byId("pageId").setTitle("Create Profit Center");
				CreateProfitModel.setProperty("/rtype", "CR");
				// this.getView().byId("fromDate").setEnabled(false);
				this.getView().byId("summary").setVisible(false);
				//new additionfor change

				this.basicAllow(true, false);
				EnableModel.setProperty("/create", true);
				EnableModel.setProperty("/edit", true);
				EnableModel.setProperty("/allow_edit", true);
				//deep change
				EnableModel.setProperty("/allow_val_seg", true);
				//deep change end

				// this.getView().byId("appr_req").setSelectedKey("No");
				// this.onAppovalChange();
				this._component.setModel(CreateProfitModel, "CreateProfitModel");
				var contextName = oEvent.getParameters().arguments.context;
				this.mdmnr_appr = contextName;
				// var contextName = (oEvent.getParameters().arguments.context);
				this.getView().byId("pageId").setTitle('Create Profit Center');
				//Goes in the loop when we search form through search page:start
				if (contextName !== undefined) {
					var n = new sap.ui.model.Filter("mdmnr", sap.ui.model.FilterOperator.EQ, contextName);

					var myFilter = [];
					myFilter.push(n);

					var that = this;
					var oModel = this.getOwnerComponent().getModel();
					oModel.read("/YFPSFICDS0033_MDMA_H", {
						filters: myFilter,
						success: function (oData, response) {
							if (oData.results.length > 0) {
								var Row = oData.results[0];
								Row.__metadata = '';
								var a = JSON.stringify(Row);
								var c = a.toString();
								var d = c.slice(2, 18);
								c = c.replace(d, "");
								that.obj = JSON.parse(c);
								// that.obj = oData.results[0];
								that.mdma_name = oData.results[0].mdma_name;

								// 				
								// 				var aDataSet = [];

								// var c = contextName.toString();
								// var d = c.slice(2, 18);
								// c = c.replace(d, "");
								// that.obj = JSON.parse(c);
								//when validity date  is not fillled and set empty 
								that.statuss = that.obj.status;
								if (that.obj.datab_c == "00000000" && that.obj.datbi_c == "00000000") {
									that.obj.datab_c = "";
									that.obj.datbi_c = "";
								}
								CreateProfitModel.setData(that.obj);
								if (that.obj.rtype == "ED") {
									//used for property make visibilitydecision which are not required for change form 
									that.edit = false;
									that.getView().byId("pageId").setTitle('Change Profit Center - ' + that.obj.mdmnr);
									that.getView().byId("summary").setVisible(true);
									that.getView().byId("ref_pc_label").setText("Profit Center");
									that.getView().byId("ref_pc_label").setRequired(true);
									that.required_fields(false);
									// this.getView().byId("comp_code21").setText("Extending company codes");
								} else {
									that.getView().byId("pageId").setTitle('Create Profit Center - ' + that.obj.mdmnr);
									that.edit = true;
									that.getView().byId("summary").setVisible(false);
								}
								if ((that.obj.mdma_name == "" && that.obj.crnam == sap.ushell.Container.getService("UserInfo").getUser().getId()) && that.obj
									.status ==
									"01") {
									that.basicAllow(true, false);
									//deep change
									EnableModel.setProperty("/allow_val_seg", true);
									//deep change end
									EnableModel.setProperty("/edit", that.edit);
									EnableModel.setProperty("/allow_edit", that.edit);

								} else if ((that.obj.mdma_name == "" && that.obj.crnam == sap.ushell.Container.getService("UserInfo").getUser().getId()) &&
									that.obj.status == "02") {
									that.basicAllow(false, false);
									EnableModel.setProperty("/edit", that.edit);

								} else if (that.obj.mdma_name == sap.ushell.Container.getService("UserInfo").getUser().getId() && that.obj.status == "04") {

									that.basicAllow(false, true);
									EnableModel.setProperty("/edit", that.edit);
									EnableModel.setProperty("/allowvis_appr", true);

								} else if (that.obj.crnam != sap.ushell.Container.getService("UserInfo").getUser().getId()) {
									that.basicAllow(false, false);
									EnableModel.setProperty("/edit", that.edit);
								} else {
									that.basicAllow(false, false);
									EnableModel.setProperty("/edit", that.edit);
								}

								that.getProfitCenterData(that.obj.mdmnr, that.obj.status);
								that.getCompanyCode(that.obj.mdmnr, that.obj.rtype, that.obj.status);
								that.getComments(that.obj.mdmnr);
								that.getattachments(that.obj.mdmnr);
								//deep change
								// this.getView().byId("validPeriod").setRequired(false);
								// this.getView().byId("fromDate").setEnabled(true);
								// this.getView().byId("toDate").setEnabled(true);
								// this.getView().byId("Segment").setRequired(false);
								// this.getView().byId("segment").setEnabled(true);
								//deep change end
							}
						}
					});
				}
				//Goes in the loop when we search form through search page:end
			}
		},
		valueStateSet: function () {
			this.byId("lob").setValueState("None");
			this.byId("conarea").setValueState("None");
			this.byId("ktext").setValueState("None");
			this.byId("ltext").setValueState("None");
			this.byId("stan_hier").setValueState("None");
			this.byId("segment").setValueState("None");
			this.byId("fromDate").setValueState("None");
			this.byId("toDate").setValueState("None");
			this.byId("bri").setValueState("None");
			this.getView().byId("comp_code2").setValueState("None");
		},
		//visibilty function on the basis of user and forms
		basicAllow: function (t, f) {
			var EnableModel = this._component.getModel("EnableModel");
			//all the property which is used in create form
			EnableModel.setProperty("/allow", t);
			//all the propery which are used in both create and change form:Enabling
			EnableModel.setProperty("/allow_edit", t);
			//property which needs to be enabled for mdma
			EnableModel.setProperty("/allow_mdma", f);
			//property for add and delete button used in approver table
			EnableModel.setProperty("/allowvis_appr", t);
			//proprty for submit button
			EnableModel.setProperty("/allowvis_sub", t);
			//property for save buttton
			EnableModel.setProperty("/allowvis_save", t);
			//deep change
			//property for validity period and segment
			EnableModel.setProperty("/allow_val_seg", f);

		},

		//getting approver details after navigating to form from search page : Deep entity set
		getattachments: function (contextName) {
			debugger;
			var n = new sap.ui.model.Filter("MDMNR", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			//var model = this.getOwnerComponent().getModel("oDataModel");
			var relPath = "/eFormAttachments";
			var that = this;
			// var oFilter = new sap.ui.model.Filter(
			// 	"MDMNR",
			// 	sap.ui.model.FilterOperator.EQ, contextName
			// );
			model.read(relPath, {
				filters: myFilter,
				success: function (oData, response) {
					debugger;
					that.getView().byId("t_attachment1").destroyItems();
					//that.getView().byId("t_attachment2").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table1 = that.getView().byId("t_attachment1");
						//var table2 = that.getView().byId("t_attachment2");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									press: function (oEvent) {
										var that2 = that;
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/eFormAttachments(MDMNR='" + this.form_number + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATED_BY
								})
							]
						});
						// var data2 = new sap.m.ColumnListItem({
						// 	cells: [
						// 		new sap.m.Link({
						// 			text: response.data.results[i].FILE_NAME,
						// 			press: function (oEvent) {
						// 				var that2 = that;
						// 				var oSource = oEvent.getSource();
						// 				var relPath = "/sap/opu/odata/sap/YFPSFIPFRDD0019_PCARD_EFORM_SRV/eFormAttachments(EFORM_NUM='" + form_number + "'" +
						// 					",FILE_NAME='" + oSource.getText() + "')/$value";
						// 				window.open(relPath, '_blank');
						// 			}
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].CREATION_DT
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].CREATION_TIME
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].FILE_SIZE
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].CREATED_BY
						// 		})
						// 	]
						// });
						table1.addItem(data1);
						//table2.addItem(data2);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		getComments: function (contextName) {
			var n = new sap.ui.model.Filter("Mdmnr", sap.ui.model.FilterOperator.EQ, contextName);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/commentsSet", {
				filters: myFilter,
				success: function (oData, response) {
					// var data = oData.results;
					var aDataSet = [];
					oData.results.forEach(function (item, index) {
						aDataSet.push({
							CreatorId: item.CreatorId,
							CreatorName: item.CreatorName,
							CommentDate: item.CommentDate,
							CommentTime: item.CommentTime,
							Comments: item.Comments,
							CommentNo: item.CommentNo

						});

					});
					that.form_number = contextName;
					that._component.getModel("commentModel").setData(aDataSet);

				}
			});
		},
		//getting approver details after navigating to form from search page 
		_onhandleValueChange: function (oEvent) {
			debugger;
			file_size = oEvent.mParameters.files[0].size;
			file_size = (file_size / 1024);
		},
		_onhandleUploadComplete: function (oEvent) {
			debugger;
			var status = oEvent.getParameter("status");
			if (status === 201) {
				var sMsg = "Upload Success";
				oEvent.getSource().setValue("");
				var temp = oEvent.getParameter("response");
				//this.form_number = temp.substr(temp.indexOf("EFORM_NUM='") + 11, 10);
				this.form_number = temp.substr(temp.indexOf("MDMNR=") + 7, 10);
			} else {
				sMsg = "Upload Error";
			}

			//REQ0642207:S4R:NSONI3:GWDK902387:08/05/2021:Attachment Issue resolution:START
			// form_number = temp.slice(115, 125);

			//REQ0642207:S4R:NSONI3:GWDK902387:08/05/2021:Attachment Issue resolution:END

			//var oResourceModel = this.getView().getModel("i18n").getResourceBundle();
			//var msg1 = this.form_number;
			//var oText = oResourceModel.getText("ProcurementApplicationCard", msg1);
			//this.getView().byId("page").setText(oText);
			debugger;
			var viewInstance = this.getView();
			viewInstance.setBusy(false);
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			//var model = this.getOwnerComponent().getModel("oDataModel");
			var relPath = "/eFormAttachments";
			var that = this;
			var oFilter = new sap.ui.model.Filter(
				"MDMNR",
				sap.ui.model.FilterOperator.EQ, this.form_number
			);
			model.read(relPath, {
				filters: [oFilter],
				success: function (oData, response) {
					debugger;
					that.getView().byId("t_attachment1").destroyItems();
					//that.getView().byId("t_attachment2").destroyItems();
					var counter = oData.results.length;
					var i = 0;
					for (i = 0; i < counter; i++) {
						var table1 = that.getView().byId("t_attachment1");
						//var table2 = that.getView().byId("t_attachment2");
						var data1 = new sap.m.ColumnListItem({
							cells: [
								new sap.m.Link({
									text: response.data.results[i].FILE_NAME,
									press: function (oEvent) {
										var that2 = that;
										var oSource = oEvent.getSource();
										var relPath = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/eFormAttachments(MDMNR='" + this.form_number + "'" +
											",FILE_NAME='" + oSource.getText() + "')/$value";
										window.open(relPath, '_blank');
									}
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_DT
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATION_TIME
								}),
								new sap.m.Text({
									text: response.data.results[i].FILE_SIZE
								}),
								new sap.m.Text({
									text: response.data.results[i].CREATED_BY
								})
							]
						});
						// var data2 = new sap.m.ColumnListItem({
						// 	cells: [
						// 		new sap.m.Link({
						// 			text: response.data.results[i].FILE_NAME,
						// 			press: function (oEvent) {
						// 				var that2 = that;
						// 				var oSource = oEvent.getSource();
						// 				var relPath = "/sap/opu/odata/sap/YFPSFIPFRDD0019_PCARD_EFORM_SRV/eFormAttachments(EFORM_NUM='" + form_number + "'" +
						// 					",FILE_NAME='" + oSource.getText() + "')/$value";
						// 				window.open(relPath, '_blank');
						// 			}
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].CREATION_DT
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].CREATION_TIME
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].FILE_SIZE
						// 		}),
						// 		new sap.m.Text({
						// 			text: response.data.results[i].CREATED_BY
						// 		})
						// 	]
						// });
						table1.addItem(data1);
						//table2.addItem(data2);
					}
				},
				error: function (oError) {
					var response = JSON.parse(oError.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},
		_onhandleUploadPress: function (oEvent) {
			debugger;
			if (oEvent.mParameters.id.toLowerCase().indexOf("b_upload1") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploader1");
				if (oFileUploader.getValue() == "") {
					MessageBox.alert("Please select the file");
					return;
				}
			}
			if (oEvent.mParameters.id.toLowerCase().indexOf("b_upload2") > -1) {
				var oFileUploader = this.getView().byId("i_fileUploader2");
				if (oFileUploader.getValue() == "") {
					MessageBox.alert("Please select the file");
					return;
				}
			}
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/";
			var userModel = new sap.ui.model.odata.ODataModel(url, true);
			//var userModel = this.getOwnerComponent().getModel("oDataModel");
			var viewInstance = this.getView();
			if (oFileUploader.getName() == "") {
				return;
			}
			viewInstance.setBusy(true);
			// Set CSRF
			userModel.refreshSecurityToken();
			var csrf = userModel.getSecurityToken();
			//Add to header and upload
			oFileUploader.destroyHeaderParameters();
			oFileUploader.setSendXHR(true);
			var headerParma = new sap.ui.unified.FileUploaderParameter();
			var headerParma2 = new sap.ui.unified.FileUploaderParameter();
			var headerParma3 = new sap.ui.unified.FileUploaderParameter();
			headerParma2.setName('slug');
			headerParma2.setValue(oFileUploader.getValue() + '|' + this.form_number + '|' + file_size + '|' + 'PRC');
			oFileUploader.insertHeaderParameter(headerParma2);
			headerParma3.setName('Content-Type');
			headerParma3.setValue('image/jpeg');
			oFileUploader.insertHeaderParameter(headerParma3);
			headerParma.setName('x-csrf-token');
			headerParma.setValue(csrf);
			oFileUploader.addHeaderParameter(headerParma);
			oFileUploader.upload();
		},
		_onDeleteAttachment: function (oEvent) {
			// debugger;
			// var sContext = oEvent.getSource().getParent().getBindingContextPath();
			// var array = this.getView().getModel("commentModel").getData();
			// if (this.obj != undefined && this.statuss != "01") {
			// 	if (array[sContext.substr(1)].CreatorId != sap.ushell.Container.getService("UserInfo").getUser().getId()) {
			// 		MessageBox.show(
			// 			"You can not delete this comment",
			// 			MessageBox.Icon.ERROR,
			// 			"Error"
			// 		);

			// 	} else {
			// 		var that = this;
			// 		var commentNo = array[sContext.substr(1)].CommentNo;
			// 		var oModel = this.getOwnerComponent().getModel();
			// 		oModel.remove("/commentsSet(Mdmnr='" + that.form_number + "'" + ",CommentNo='" + commentNo +
			// 			"')", {

			// 				success: function (data) {
			// 					array.splice(sContext.substr(1), 1);
			// 					that.getView().getModel("commentModel").setData(array);
			// 				},
			// 				error: function (e) {

			// 				}
			// 			});

			// 		// var array2 = [];

			// 		//   array2 = array.splice(sContext.substr(1), 1);
			// 		// this.getView().getModel("commentModel").setData(array);
			// 	}
			// } else {
			// 	// var sContext = oEvent.getSource().getParent().getBindingContextPath();
			// 	// var array = this.getView().getModel("commentModel").getData();

			// 	array.splice(sContext.substr(1), 1);
			// 	this.getView().getModel("commentModel").setData(array);
			// }
			//change
			debugger;
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/";
			var model = new sap.ui.model.odata.ODataModel(url, true);
			if (oEvent.mParameters.id.toLowerCase().indexOf("b_deleteattachment1") > -1) {
				var selected_item = this.getView().byId("t_attachment1").getSelectedItem();
			}
			// if (oEvent.mParameters.id.toLowerCase().indexOf("b_deleteattachment2") > -1) {
			// 	var selected_item = this.getView().byId("t_attachment2").getSelectedItem();
			// }
			var filename = selected_item.mAggregations.cells[0].mProperties.text;
			if (filename !== "") {
				if (selected_item.mAggregations.cells[4].mProperties.text == sap.ushell.Container.getUser().getId()) {
					var that = this;
					model.remove("/eFormAttachments(MDMNR='" + this.form_number + "'" + ",FILE_NAME='" + filename + "')", {
						success: function (oData, response) {
							that.getView().byId("t_attachment1").removeItem(selected_item);
							//that.getView().byId("t_attachment2").removeItem(selected_item);
							MessageBox.alert("Attachment deleted successfully.");
						},
						error: function (oError) {
							var response = JSON.parse(oError.responseText);
							MessageBox.show(
								response.error.message.value,
								MessageBox.Icon.ERROR,
								"Error"
							);
							sap.ui.core.BusyIndicator.hide();
						}
					});
				} else {
					MessageBox.show(
						"You can not delete this Attachment",
						MessageBox.Icon.ERROR,
						"Error"
					);
				}
			}

		},
		getProfitCenterData: function (contextName, statuss) {
			var n = new sap.ui.model.Filter("MDMNR", sap.ui.model.FilterOperator.EQ, contextName);
			// var n1 = new sap.ui.model.Filter("REVIEWER_TYPE", sap.ui.model.FilterOperator.EQ, "WATCHER");
			var myFilter = [];
			myFilter.push(n);
			// myFilter.push(n1);
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/FormApproverSet", {
				filters: myFilter,
				success: function (oData, response) {
					if (oData.results.length > 0) {
						that.getView().byId("approver").setVisible(true);
						// that.byId("appr_req").setSelectedKey("Yes");
						// var data = oData.results;
						var aDataSet = [];

						oData.results.forEach(function (item, index) {
							var sStatus;
							if (item.ACTION === "A") {
								sStatus = "Approved";
							} else if (item.ACTION === "R") {
								sStatus = "Rejected";
							} else {
								sStatus = "";
							}
							aDataSet.push({
								APPR_ID: item.APPR_ID,
								REVIEWER_TYPE: item.REVIEWER_TYPE,
								APPREMAIL: item.APPREMAIL,
								SEQUENCE: item.SEQUENCE,
								ACTION: sStatus,
								ACTION_DATE: item.ACTION_DATE,
								ACTION_TIME: item.ACTION_TIME,
								ACTION_BY: item.ACTION_BY,
								GRP: item.GRP,
								APPRCONTACT: item.APPRCONTACT,
								APPRDIV: item.APPRDIV,
								APPRNAME: item.APPRNAME,
								isInput: true,
								ACT_NAME: item.ACT_NAME
							});

						});
						var temp = 1;
						// while (temp < oData.results.length)
						if (statuss == "02") {
							for (var i = 0; i < temp; i++) {
								if (oData.results[i].APPRNAME != "MDMA") {
									if (oData.results[i].REVIEWER_TYPE == "APPROVER" && oData.results[i].ACTION == "" && oData.results[i].APPR_ID == sap.ushell
										.Container.getService("UserInfo").getUser().getId()) {
										that.getView().byId("B03").setVisible(true);
										that.getView().byId("B05").setVisible(true);
										that.appr_ids = oData.results[i].APPR_ID;
										that.mdmnrs = contextName;

									} else if (oData.results[i].REVIEWER_TYPE == "WATCHER" || oData.results[i].ACTION == "A") {
										temp++;
									}

								 } 
								//deep change end
								else if (that.mdma_name == sap.ushell
									.Container.getService("UserInfo").getUser().getId()) {
									that.getView().byId("B03").setVisible(true);
									that.getView().byId("B05").setVisible(true);
									that.appr_ids = oData.results[i].APPR_ID;
									that.mdmnrs = contextName;

								}

							}
						}

						that.form_number = contextName;
						// that.getView().byId("pageId").setTitle('Create Profit Center - ' + contextName);
						// // that.getView().byId("userRespon_txt").setText(item.name_text);
						// that._component.getModel("CreateProfitModel").setData(header);

						that._component.getModel("approverModel").setData(aDataSet);
					}

				},
				error: function (error) {
					var response = JSON.parse(error.responseText);
					MessageBox.show(
						response.error.message.value,
						MessageBox.Icon.ERROR,
						"Error"
					);
				}
			});
		},

		//getting company code after searching the form done using deep entity

		getCompanyCode: function (context, rtype, status) {

			var n = new sap.ui.model.Filter("mdmnr", sap.ui.model.FilterOperator.EQ, context);
			var myFilter = [];
			myFilter.push(n);
			var that = this;
			var oModel = this.getOwnerComponent().getModel();
			oModel.read("/companycodesSet", {
				filters: myFilter,
				success: function (oData, response) {
					// var data = oData.results;
					//var aDataSet = [];
					if (response.data.results.length > 0 && status == "01") {
						that.getView().byId("ext_unext").setEnabled(true);

					}
					if (rtype == "ED") {
						oData.results.forEach(function (item, index) {
							var defToken = new sap.m.Token({
								text: item.bukrs_c
							});
							that.byId("ccomp_code2").addToken(defToken);
						});
					} else {
						oData.results.forEach(function (item, index) {
							var defToken = new sap.m.Token({
								text: item.bukrs
							});
							that.byId("comp_code2").addToken(defToken);
						});
					}

				}
			});

		},

		//popup on click of help buttons in the form 

		onPress: function (oEvent) {
			if (oEvent != undefined) {
				var oButton = oEvent.getSource().getId().slice(12);
				var oButton1 = oEvent.getSource();

				if (oButton == "help_ref_pc") {
					this.ref_pc = "A reference profit center exists in SAP system, can be used to copy data for new profit center";
					this.placement = "Bottom";
				}
				if (oButton == "help_ca") {
					this.ref_pc =
						"Profit center are created in the same controlling area in which the company codes to which the new profit center is extended reside i.e. most PCs are created in Controlling area 1000";
					this.placement = "Bottom";

				}
				if (oButton == "help_lock_unlock") {
					this.ref_pc =
						"Select appropriate option if you need to lock or unlock profit center";
					this.placement = "Bottom";

				}
				if (oButton == "help_ext_unext") {
					this.ref_pc =
						"Select appropriate option if you need to extend  or unextend profit center to above mentioned company codes";
					this.placement = "Bottom";

				}
				if (oButton == "help_pc_changes") {
					this.ref_pc =
						"Please fill in the fields where in changes are required.";
					this.placement = "Bottom";

				}
				if (oButton == "help_bri") {
					this.ref_pc =
						"Please provide business requirement and any specific instructions to be considered while creating profit center";
					this.placement = "Bottom";

				}
				if (oButton === "help_name") {
					this.ref_pc = "Profit Center short description should be in range of 20 Characters";
					this.placement = "Bottom";

				}
				if (oButton == "help_desc") {
					this.ref_pc = "Profit Center description should be in range of 40 Characters";
					this.placement = "Bottom";

				}
				if (oButton == "help_pers_resp") {
					this.ref_pc = "Default value is taken as Dept. Head";
					this.placement = "Bottom";

				}
				if (oButton == "help_segment") {
					this.ref_pc = "Segment input is provided by Corporate Finance, please connect with nailah_madyun@spe.sony.com";
					this.placement = "Bottom";

				}
				if (oButton == "help_stan_hier") {
					this.ref_pc = "Profit Center group details for Standard Hierarchy for e.g. PCXXXXXX required for reporting purpose";
					this.placement = "Bottom";

				}
				if (oButton == "help_ownerpc") {
					this.ref_pc =
						"Owner Profit Center is required for tracking revenue for LOB specific titles . Please select 'No' for regular profit center creation";
					this.placement = "Bottom";

				}
				if (oButton == "help_defaultpc") {
					this.ref_pc =
						"Default Profit Center is required for Company Code configuration. Please select 'No' for regular profit center creation";
					this.placement = "Bottom";

				}
				if (oButton == "help_compcode") {
					this.ref_pc =
						"Profit Center will be extended to the selected Company Codes. If the list is large; select one in tab and mention other company codes in comments";
					this.placement = "Left";

				}
				if (oButton == "help_date") {
					this.ref_pc = "In case there is no specific period to be requested, default of 01/01/1900 to 31/12/9999 will be taken";
					this.placement = "Bottom";

				}
				if (oButton == "help_user_resp") {
					this.ref_pc = "Default value is taken as blank";
					this.placement = "Left";

				}
				if (oButton == "help_appr") {
					this.ref_pc = "Corporate Approval required from nailah_madyun@spe.sony.com";
					this.placement = "Left";

				}
				var oPopover = new sap.m.Popover({
					title: "Help",
					// titleAlignment: "Center",
					// width: "200px",
					placement: this.placement,
					content: [
						new sap.m.HBox({
							items: new sap.m.Text({
								text: this.ref_pc
							}),
							width: "200px"
						}).addStyleClass("sapUiSmallMargin")
						// new sap.m.HBox({
						// 	class: "sapUiSmallMargin",
						// 	items: new sap.m.Text({
						// 		text: "Help instructions are provided"
						// 	}),
						// 	width: "200px"
						// }).addStyleClass("sapUiSmallMargin")
					]

				});
				oPopover.openBy(oButton1);
				oButton1.addEventDelegate({
					onmouseover: function () {
						oPopover.openBy(oButton1);
					},
					onmouseout: function () {
						oPopover.close(oButton1);
					}
				}, this);

			}
		},

		//Adding approver row on click of a button

		// onAddApprovers: function (oEvent) {
		// 	//new code to add approvers
		// 	var oToolbar = oEvent.getSource().getParent();
		// 	// var table = this.getView().byId("tblApprover");
		// 	// var tablength=table.getItems().length;
		// 	var sReviewType = oToolbar.getAggregation("content")[2].getProperty("value");
		// 	var approverModel = this._component.getModel("approverModel");
		// 	var oDataSet = approverModel.getData();
		// 	var sIndex = oDataSet.length;
		// 	// var selected_item = this.getView().byId("tblApprover").getSelectedItem();
		// 	// if (selected_item.mAggregations.cells[1].mProperties.value == "MDMA" && this.getView().byId("ENTRY_SEQUENCE").getValue() ==
		// 	// 	"After" && table.indexOfItem(selected_item) != "0") {
		// 	// 	MessageBox.alert("You cannot add Approvers/Watchers after MDMA ");
		// 	// 	return;
		// 	// }
		// 	if (sIndex === undefined) {
		// 		oDataSet = [];
		// 	}
		// 	oDataSet.splice(sIndex, 0, {
		// 		APPR_ID: "",
		// 		APPRNAME: "",
		// 		APPREMAIL: "",
		// 		APPRCONTACT: "",
		// 		APPRDIV: "",
		// 		REVIEWER_TYPE: sReviewType,
		// 		isInput: false,
		// 		ACTION: "",
		// 		ACT_NAME: "",

		// 	});

		// 	this.getView().getModel("approverModel").setData(oDataSet);
		// },

		//Binding data of approver table using factory function
		onAddApprovers: function (oEvent) {
			var selectedType = this.byId("apprType").getValue();
			var positionType = this.byId("ENTRY_SEQUENCE").getValue();
			var table = this.getView().byId("tblApprover");
			var sItem = table.getSelectedItem();
			// var all_entries = table.getItems();
			var num_of_entries = table.getItems().length;
			var sIndex;
			if (num_of_entries === 0 && sItem == undefined) {
				sIndex = 0;
				var oDataSet = [];
				oDataSet.splice(sIndex, 0, {
					APPR_ID: "",
					APPRNAME: "",
					APPREMAIL: "",
					APPRCONTACT: "",
					APPRDIV: "",
					REVIEWER_TYPE: selectedType,
					isInput: false,
					ACTION: "",
					ACT_NAME: "",

				});
				this.getView().getModel("approverModel").setData(oDataSet);
			} else if (sItem != undefined && num_of_entries > 0) {
				if (sItem.getAggregation("cells")[0].mProperties.text != undefined) {
					if (sItem.getAggregation("cells")[0].getProperty("text") == "MDMA" && this.getView().byId("ENTRY_SEQUENCE").getValue() ==
						"After" && table.indexOfItem(sItem) != "0") {
						MessageBox.alert("You cannot add Approvers/Watchers after MDMA ");
						return;
					}
				}

				sIndex = table.getItems().indexOf(table.getSelectedItem());
				sIndex = (positionType === "Before") ? Number(sIndex) : Number(sIndex +
					1);

				var oTableModel = this.getView().getModel("approverModel");
				var oDataSet = oTableModel.getData();
				oDataSet.splice(sIndex, 0, {
					APPR_ID: "",
					APPRNAME: "",
					APPREMAIL: "",
					APPRCONTACT: "",
					APPRDIV: "",
					REVIEWER_TYPE: selectedType,
					isInput: false,
					ACTION: "",
					ACT_NAME: "",

				});
				this.getView().getModel("approverModel").setData(oDataSet);
			} else {
				MessageToast.show("Please select an approver");
			}
			// if (sIndex === 0) {
			// 	var oDataSet = [];
			// } else {
			// 	// 			
			// 	var oTableModel = this.getView().getModel("approverModel");
			// 	var oDataSet = oTableModel.getData();
			// }

		},
		aproverFactory: function (sId, oContext) {
			if (!oContext.getProperty("isInput")) {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Input({
							// id: "apprname",
							showValueHelp: true,
							value: "{approverModel>APPRNAME}",
							// enabled: "{EnableModel>/allow}",
							enabled: true,
							valueHelpRequest: [this.conAreaValueHelpRequest, this]
						}).data("key", "{approverModel>APPR_ID}"),
						new sap.m.Text({
							// enabled: "{EnableModel>/allow}",
							// enabled: true,
							text: "{approverModel>REVIEWER_TYPE}",
							// showValueHelp: false
							//valueHelpRequest: [this.conAreaValueHelpRequest, this]

						}),
						new sap.m.Text({
							// enabled: "{EnableModel>/allow}",

							text: "{approverModel>ACT_NAME}"

						}),
						new sap.m.Text({
							text: "{approverModel>ACTION}"
						})
						// new sap.m.Text({
						// 	text: "{oApproverModel>ACTION_TIME}"
						// })
					]
				});

			} else {
				var oTemplate = new sap.m.ColumnListItem({
					cells: [
						new sap.m.Text({
							// id: "apprname",
							// showValueHelp: true,
							text: "{approverModel>APPRNAME}",
							// enabled: "{EnableModel>/allow}",
							// enabled: true,
							// valueHelpRequest: [this.conAreaValueHelpRequest, this]
						}).data("key", "{approverModel>APPR_ID}"),
						new sap.m.Text({
							// enabled: "{EnableModel>/allow}",
							// enabled: true,
							text: "{approverModel>REVIEWER_TYPE}",
							// showValueHelp: false
							//valueHelpRequest: [this.conAreaValueHelpRequest, this]

						}),
						new sap.m.Text({
							// enabled: "{EnableModel>/allow}",

							text: "{approverModel>ACT_NAME}"

						}),
						new sap.m.Text({
							text: "{approverModel>ACTION}"
						})
						// new sap.m.Text({
						// 	text: "{oApproverModel>ACTION_TIME}"
						// })
					]
				});

			}
			return oTemplate;
		},
		//Deletion of Approver on click of delete button

		deleteAapprover: function (oEvent) {

			var oParent = oEvent.getSource().getParent();
			var oPar_Parent = oParent.getParent().getId();
			var oTableId = sap.ui.getCore().byId(oPar_Parent);
			var selected_item = oTableId.getSelectedItem();
			var array = this.getView().getModel("approverModel").getData();
			var array2 = [];

			//deleting mannually added items

			var sContext = selected_item.getBindingContextPath();

			array2 = array.splice(sContext.substr(1), 1);
			this.getView().getModel("approverModel").setData(array);

		},
		onExit: function () {
			if (this._oPopover) {
				this._oPopover.destroy();
			}
		},
		handleClosePress: function () {
			this._oPopover.close();
		},
		//new window opens on clicking help button
		onHelp: function () {

			var cltstrng = "width=500px,height=600px";
			var wind = window.open("", cltstrng);
			wind.document.write("Help Document");
		},

		//common function for all the value help requests in the form 
		conAreaValueHelpRequest: function (oevent) {
			var multi = false;
			var CreateProfitModel = this._component.getModel("CreateProfitModel");
			this.formtype = CreateProfitModel.getProperty("/rtype");
			var that = this;
			var id = oevent.getSource().getId().split("-")[2];

			var titleFilter;
			var descriptionFilter;
			if (id === "stan_hier" || id === "cstan_hier") {
				this.url = "/FiglcnShPcgroupSet";
				this.mtitle = "Standard Hierarachy";
				this.title = "{Setname}";
				this.descriptions = "{Descript}";
				titleFilter = "Setname";
				descriptionFilter = "";
				//this.filter_path="";
			}
			if (id === "created_pc") {
				this.url = "/FacFhPrctrShlpSet";
				if (that.formtype == "ED") {
					this.mtitle = "Profit Center";
				} else {
					this.mtitle = "Reference Profit Center";
				}
				this.title = "{Prctr}";
				this.descriptions = "{Ktext}";
				titleFilter = "Prctr";
				descriptionFilter = "Ktext";
				//this.conarea = this.getView().byId("conarea").getValue();
				//this.filter_path="Kokrs";
				// var desc="Ktext"
			}
			if (id === "lob") {
				this.url = "";
				this.mtitle = "Line of Business";
				this.title = "{}";
				this.descriptions = "{}";
				titleFilter = "";
				descriptionFilter = "";
				//this.filter_path="";
			}
			if (id === "userRespon" || oevent.getSource().getId() === "apprname" || id === undefined) {
				this.url = "/YfpsfishlpUsernameSet";
				this.mtitle = "Users";
				this.title = "{nametextc}";
				this.descriptions = "{bname}";
				titleFilter = "mcnamefir";
				descriptionFilter = "bname";
				//this.filter_path="";
				var desc = "bname";
				if (oevent.getSource().getId() === "apprname") {
					id = "apprname";
				}
			}
			if (id === "segment" || id === "csegment") {
				this.url = "/FacSegmentSet";
				this.mtitle = "Segment";
				this.title = "{Segment}";
				this.descriptions = "{Name}";
				titleFilter = "Segment";
				descriptionFilter = "Name";
				//this.filter_path="";
			}
			if (id === "comp_code1" || id === "ccomp_code2" || id === "comp_code2") {
				this.url = "/YfpsfishlpBukrsSet"; // old one "/HT001Set"
				this.mtitle = "Company Code";
				this.title = "{Bukrs}";
				this.descriptions = "{Butxt}";
				multi = true;
				titleFilter = "Bukrs";
				descriptionFilter = "Butxt";
				//this.filter_path="";
			}

			// var Con_Area = this.getView().byId("conarea");
			var Con_Area = oevent.getSource();
			var model = this.getOwnerComponent().getModel();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: this.mtitle,
				items: {
					path: this.url,
					// deep change start
					// filters: [new sap.ui.model.Filter({
					// 	filters: [new sap.ui.model.Filter({
					// 		path: this.filter_path,
					// 		operator: sap.ui.model.FilterOperator.EQ,
					// 		value1: this.conarea
					// 	})],
					// 	and: true
					// })],
					//deep change end
					template: new sap.m.StandardListItem({
						title: this.title,
						description: this.descriptions,

					})
				},
				multiSelect: multi,
				search: function (oEvent) {

					var sValue = oEvent.getParameter("value");
					var oTitleFilter = new sap.ui.model.Filter(
						titleFilter,
						sap.ui.model.FilterOperator.Contains, sValue
					);

					var oFilter = new sap.ui.model.Filter([oTitleFilter], false);
					oEvent.getSource().getBinding("items").filter([oFilter]);

				},

				confirm: function (oEvent) {

					if (multi == false) {
						var oSelectedItem = oEvent.getParameter("selectedItem");
						if (oSelectedItem) {
							if (id === "userRespon") {
								Con_Area.setValue(oSelectedItem.getDescription());
								Con_Area.data("key", oSelectedItem.getTitle());
								// that.getView().byId("userRespon_txt").setText(oSelectedItem.getTitle());
							} else {
								Con_Area.setValue(oSelectedItem.getTitle());
								Con_Area.data("key", oSelectedItem.getDescription());
							}
						}
						//Setting values forother field based on reference profit center selected
						if (id == "ref_pc") {

							model.read("/YFPSFI0033_GET_REF_PRCTR('" + oSelectedItem.getTitle() + "')", {
								success: function (odata, response) {
									// debugger;
									if (that.formtype == "ED") {
										that.getView().byId("conarea").setValue(odata.kokrs);
										that.getView().byId("dept").setValue(odata.abtei);
										that.getView().byId("userRespon").setValue(odata.verak_user);
										// that.getView().byId("userRespon_txt").setText(odata.name_text);
										that.getView().byId("perRespon").setValue(odata.verak);
										that.getView().byId("segment").setValue(odata.segment);
										that.getView().byId("csegment").setValue(odata.segment);
										// that.getView().byId("stan_hier").setValue(odata.khinr);
										// that.getView().byId("cstan_hier").setValue(odata.khinr);
										// that.getView().byId("ktext").setValue(odata.ktext);
										// that.getView().byId("cktext").setValue(odata.ktext);
										// that.getView().byId("ltext").setValue(odata.ltext);
										// that.getView().byId("cltext").setValue(odata.ltext);
										var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
											pattern: "MM/dd/yyyy"
										});
										var datab = dateFormat.format(new Date(odata.datab));
										var datbi = dateFormat.format(new Date(odata.datbi));

										that.getView().byId("fromDate").setValue(datab);
										that.getView().byId("toDate").setValue(datbi);
										// that.getView().byId("cfromDate").setValue(datab);
										// that.getView().byId("ctoDate").setValue(datbi);

										// that.EditProfitModel = that._component.getModel("EditProfitModel");
										// that.EditProfitModel.setData(odata);

									} else {
										that.getView().byId("conarea").setValue(odata.kokrs);
										that.getView().byId("dept").setValue(odata.abtei);
										that.getView().byId("userRespon").setValue(odata.verak_user);
										// that.getView().byId("userRespon_txt").setText(odata.name_text);
										that.getView().byId("perRespon").setValue(odata.verak);
										that.getView().byId("segment").setValue(odata.segment);
										that.getView().byId("stan_hier").setValue(odata.khinr);
									}
								},

							});
						}
						if (id === "apprname" || id === undefined) {
							model.read("/getEmailSet('" + oSelectedItem.getDescription() + "')", {
								success: function (odata, response) {
									var appTable = that.getView().byId("tblApprover").getItems();
									for (var i = 0; i < appTable.length; i++) {
										if (appTable[i].getAggregation("cells")[0].data().key === odata.BNAME) {
											// appTable[i].getAggregation("cells")[1].setValue(odata.SMTP_ADDR);
											break;
										}
									}
								},

							});
						}

					} else {
						var oSelectedItem = oEvent.getParameter("selectedItems");
						if (oSelectedItem && oSelectedItem.length > 0) {
							oSelectedItem.forEach(function (oItem) {
								Con_Area.addToken(new Token({
									text: oItem.getTitle()
								}));
							});
							that.getView().byId("ext_unext").setEnabled(true);
						}
					}
				},

				// 		else 

			});

			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		//deep change
		conAreaValueHelpRequest1: function (oevent) {
			var multi = false;
			var CreateProfitModel = this._component.getModel("CreateProfitModel");
			this.formtype = CreateProfitModel.getProperty("/rtype");
			var that = this;
			var id = oevent.getSource().getId().split("-")[2];

			var titleFilter;
			var descriptionFilter;
			if (id === "ref_pc") {
				this.url = "/FacFhPrctrShlpSet";
				if (that.formtype == "ED") {
					this.mtitle = "Profit Center";
				} else {
					this.mtitle = "Reference Profit Center";
				}
				this.title = "{Prctr}";
				this.descriptions = "{Ktext}";
				titleFilter = "Prctr";
				descriptionFilter = "Ktext";
				this.conarea = this.getView().byId("conarea").getValue();
				this.filter_path = "Kokrs";
				// var desc="Ktext"
			}

			var Con_Area = oevent.getSource();
			var model = this.getOwnerComponent().getModel();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: this.mtitle,
				items: {
					path: this.url,
					// deep change start
					filters: [new sap.ui.model.Filter({
						filters: [new sap.ui.model.Filter({
							path: this.filter_path,
							operator: sap.ui.model.FilterOperator.EQ,
							value1: this.conarea
						})],
						and: true
					})],
					//deep change end
					template: new sap.m.StandardListItem({
						title: this.title,
						description: this.descriptions,

					})
				},
				multiSelect: multi,
				search: function (oEvent) {

					var sValue = oEvent.getParameter("value");
					var oTitleFilter = new sap.ui.model.Filter(
						titleFilter,
						sap.ui.model.FilterOperator.Contains, sValue
					);

					var oFilter = new sap.ui.model.Filter([oTitleFilter], false);
					oEvent.getSource().getBinding("items").filter([oFilter]);

				},

				confirm: function (oEvent) {

					if (multi == false) {
						var oSelectedItem = oEvent.getParameter("selectedItem");
						if (oSelectedItem) {
							if (id === "userRespon") {
								Con_Area.setValue(oSelectedItem.getDescription());
								Con_Area.data("key", oSelectedItem.getTitle());
								// that.getView().byId("userRespon_txt").setText(oSelectedItem.getTitle());
							} else {
								Con_Area.setValue(oSelectedItem.getTitle());
								Con_Area.data("key", oSelectedItem.getDescription());
							}
						}
						//Setting values forother field based on reference profit center selected
						if (id == "ref_pc") {

							model.read("/YFPSFI0033_GET_REF_PRCTR('" + oSelectedItem.getTitle() + "')", {
								success: function (odata, response) {
									// debugger;
									if (that.formtype == "ED") {
										that.getView().byId("conarea").setValue(odata.kokrs);
										that.getView().byId("dept").setValue(odata.abtei);
										that.getView().byId("userRespon").setValue(odata.verak_user);
										// that.getView().byId("userRespon_txt").setText(odata.name_text);
										that.getView().byId("perRespon").setValue(odata.verak);
										that.getView().byId("segment").setValue(odata.segment);
										that.getView().byId("csegment").setValue(odata.segment);
										// that.getView().byId("stan_hier").setValue(odata.khinr);
										// that.getView().byId("cstan_hier").setValue(odata.khinr);
										// that.getView().byId("ktext").setValue(odata.ktext);
										// that.getView().byId("cktext").setValue(odata.ktext);
										// that.getView().byId("ltext").setValue(odata.ltext);
										// that.getView().byId("cltext").setValue(odata.ltext);
										var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
											pattern: "MM/dd/yyyy"
										});
										var datab = dateFormat.format(new Date(odata.datab));
										var datbi = dateFormat.format(new Date(odata.datbi));

										that.getView().byId("fromDate").setValue(datab);
										that.getView().byId("toDate").setValue(datbi);
										// that.getView().byId("cfromDate").setValue(datab);
										// that.getView().byId("ctoDate").setValue(datbi);

										// that.EditProfitModel = that._component.getModel("EditProfitModel");
										// that.EditProfitModel.setData(odata);

									} else {
										that.getView().byId("conarea").setValue(odata.kokrs);
										that.getView().byId("dept").setValue(odata.abtei);
										that.getView().byId("userRespon").setValue(odata.verak_user);
										// that.getView().byId("userRespon_txt").setText(odata.name_text);
										that.getView().byId("perRespon").setValue(odata.verak);
										that.getView().byId("segment").setValue(odata.segment);
										that.getView().byId("stan_hier").setValue(odata.khinr);
									}
								},

							});
						}

					} else {
						var oSelectedItem = oEvent.getParameter("selectedItems");
						if (oSelectedItem && oSelectedItem.length > 0) {
							oSelectedItem.forEach(function (oItem) {
								Con_Area.addToken(new Token({
									text: oItem.getTitle()
								}));
							});
							that.getView().byId("ext_unext").setEnabled(true);
						}
					}
				},

				// 		else 

			});

			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
		},
		//deep change end
		//Called on token update on Company Code
		onLiveChange: function (oEvent) {
			if (oEvent.getSource().getAggregation("tokens").length == 1) {
				this.getView().byId("ext_unext").setEnabled(false);
				this.getView().byId("ext_unext").getAggregation("buttons")[0].setSelected(false);
				this.getView().byId("ext_unext").getAggregation("buttons")[1].setSelected(false);
			}
		},
		onChange: function (oEvent) {

			var model = this.getOwnerComponent().getModel();
			var oSelectedItem = this.getView().byId("ref_pc").getValue();
			var that = this;
			model.read("/YFPSFI0033_GET_REF_PRCTR('" + oSelectedItem + "')", {
				success: function (odata, response) {

					that.getView().byId("conarea").setValue(odata.kokrs);
					that.getView().byId("dept").setValue(odata.abtei);
					that.getView().byId("userRespon").setValue(odata.verak_user);
					that.getView().byId("perRespon").setValue(odata.verak);
					that.getView().byId("segment").setValue(odata.segment);
					that.getView().byId("stan_hier").setValue(odata.khinr);
				},

			});
		},

		//onchange request type value
		onChangeRequestType: function (oEvent) {
			var model = this.getOwnerComponent().getModel();
			var EnableModel = this._component.getModel("EnableModel");
			// CreateProfitModel.setProperty("/prctr","01");
			EnableModel.setProperty("/edit", false);
			// this.getView().byId("pcnums").setVisible(true);  
			// this.getView().byId("reqinfo").setVisible(false);    
			var selectedId = oEvent.getSource().getSelectedItem().getKey();
			if (selectedId === 'CR') {
				this.getView().byId("ref_pc_label").setText("Reference Profit Center Number/Series");
				this.getView().byId("ref_pc_label").setRequired(false);
			} else {
				this.getView().byId("ref_pc_label").setText("Profit Center");
				this.getView().byId("ref_pc_label").setRequired(true);
			}
		},
		//on posting comment
		onCommentPost: function (oEvent) {
			var sCurrentUser = sap.ushell.Container.getUser().getId();
			var sCurrentUserName = sap.ushell.Container.getUser().getFullName();
			var sComment = oEvent.getParameter("value");
			// oEntry = {
			// 	FORM_NO: this.Form_Num,
			// 	CREATOR: sCurrentUser,
			// 	CREATOR_NAME: sCurrentUserName,
			// 	COMMENTS: sComment
			// };
			var oDataSets = {
				Mdmnr: this.form_number,
				CreatorId: sCurrentUser,
				CreatorName: sCurrentUserName,
				Comments: sComment
			};
			var commentModel = this._component.getModel("commentModel");
			var oDataSet = commentModel.getData();
			var sIndex = oDataSet.length;
			if (sIndex === undefined) {
				oDataSet = [];
			}
			oDataSet.splice(sIndex, 0, {
				FORM_NO: this.Form_Num,
				CreatorId: sCurrentUser,
				CreatorName: sCurrentUserName,
				Comments: sComment
			});
			if (this.form_number != "" && this.statuss != "01") {
				//          var n = new sap.ui.model.Filter("Mdmnr", sap.ui.model.FilterOperator.EQ, this.form_number);
				// var myFilter = [];
				// myFilter.push(n);
				var that = this;
				var oModel = this.getOwnerComponent().getModel();
				oModel.create("/commentsSet", oDataSets, {
					// filters: myFilter,
					success: function (oData, response) {
						that.getComments(that.form_number);
						MessageBox.show(
							"Comment added Successfully",
							MessageBox.Icon.SUCCESS,
							"Success"
						);

					}
				});

			} else {
				this.getView().getModel("commentModel").setData(oDataSet);
			}

		},
		// binding data to comment section
		commentFactory: function () {
			// var oCommentModel = new JSONModel(oEntry),
			// 			oList = this.byId("commentList");
			// 		oCommentModel.setSizeLimit(1000);
			// 		oList.setModel(oCommentModel);
			// 		oList.bindAggregation("items", {
			// 			path: "/results",

			var oTemplate = new sap.m.FeedListItem({
				senderActive: false,
				sender: "{commentModel>CreatorName}",
				text: "{commentModel>Comments}",
				showIcon: false,
				actions: new sap.m.FeedListItemAction({
					text: "Delete",
					press: [this.onActionPressed, this],
					icon: "sap-icon://delete",
					key: "delete",
					enabled: "{EnableModel>/allow}"
				})
			}).bindProperty("timestamp", {
				parts: [{
					path: 'commentModel>CommentDate'
				}, {
					path: 'commentModel>CommentTime'
				}],
				formatter: function (sDate, sTime) {
					if ((sDate === "00000000" || sDate === null || sDate === undefined) || (sTime === "00000000" || sTime === null ||
							sTime === undefined)) {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"

						});

						return timeFormat.format(new Date());
					} else {
						var timeFormat = DateFormat.getDateTimeInstance({
							pattern: "MM/dd/yyyy hh:mm:ss a"
						});
						var hour = sTime.substring(0, 2);
						var minute = sTime.substring(3, 5);
						var second = sTime.substring(6, 8);
						var sCTime = hour + ":" + minute + ":" + second;
						return timeFormat.format(new Date(sDate + " " + sCTime));
					}
				}
			});
			return oTemplate;

			//that._busyIndicator.close();
			//var that = this;
			//	FinanceApproverModel.submitComment(oEntry, [new Filter("FORM_NO", FilterOperator.EQ, this.Form_Num)], that);
		},
		//on deleting comment 
		onActionPressed: function (oEvent) {
			var sContext = oEvent.getSource().getParent().getBindingContextPath();
			var array = this.getView().getModel("commentModel").getData();
			if (this.obj != undefined && this.statuss != "01") {
				if (array[sContext.substr(1)].CreatorId != sap.ushell.Container.getService("UserInfo").getUser().getId()) {
					MessageBox.show(
						"You can not delete this comment",
						MessageBox.Icon.ERROR,
						"Error"
					);

				} else {
					var that = this;
					var commentNo = array[sContext.substr(1)].CommentNo;
					var oModel = this.getOwnerComponent().getModel();
					oModel.remove("/commentsSet(Mdmnr='" + that.form_number + "'" + ",CommentNo='" + commentNo +
						"')", {

							success: function (data) {
								array.splice(sContext.substr(1), 1);
								that.getView().getModel("commentModel").setData(array);
							},
							error: function (e) {

							}
						});

					// var array2 = [];

					//   array2 = array.splice(sContext.substr(1), 1);
					// this.getView().getModel("commentModel").setData(array);
				}
			} else {
				// var sContext = oEvent.getSource().getParent().getBindingContextPath();
				// var array = this.getView().getModel("commentModel").getData();

				array.splice(sContext.substr(1), 1);
				this.getView().getModel("commentModel").setData(array);
			}
		},
		required_fields: function (cond) {
			//this.getView().byId("stanHier").setRequired(cond);
			this.getView().byId("conArea").setRequired(cond);
			//deep change
			//this.getView().byId("validPeriod").setRequired(cond);
			this.getView().byId("ktext").setRequired(cond);
			this.getView().byId("ltext").setRequired(cond);
			//this.getView().byId("Segment").setRequired(cond);
			//deep change end
		},
		//saving request after clicking save and submit button
		onPressSaveBtn: function (event) {
			var temp = this;
			var data = this._component.getModel("CreateProfitModel").getData();
			// //deep change
			// if(this.byId("stan_hier").getValue()== null || this.byId("segment").getValue()== null)
			// {
			// 	MessageBox.warning("Please verify Segment and Standard Hierarchy field.");
			// }
			// //deep change end

			//when object type is change request, date type needs to be adjusted coming in different format from backend 
			if (data.datab != undefined && data.rtype == "ED" && data.status == undefined && data.datab.length != 8) {
				//formatting the date value coming from backend:START
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyyMMdd"
				});

				var datab = dateFormat.format(new Date(data.datab));
				var datbi = dateFormat.format(new Date(data.datbi));
				//formatting the date value coming from backend :END
				data.datab = datab;
				data.datbi = datbi;

				//When object type is create request
			} else {
				var fromDate = this.getView().byId("fromDate").getValue();
				fromDate = parseInt(fromDate);
				var toDate = this.getView().byId("toDate").getValue();
				toDate = parseInt(toDate);
				// if (fromDate > toDate) {
				// 	MessageBox.show(
				// 		"Validity To Date Should be greater than Validity From Date",
				// 		MessageBox.Icon.ERROR,
				// 		"Error"
				// 	);
				// }
			}
			var buttonText = event.getSource().getProperty("text");
			if (buttonText === "Save") {
				data.status = "01";
			} else if (buttonText === "Submit") {
				data.status = "02";
			} else {
				data.status = "07";
			}
			// data.status = event.getSource().getId().slice(13, 15);
		
			//deep change : START
			MessageBox.warning("Please verify Segment and Standard Hierarchy field.", {
				actions: ["Continue", "Verify"],
				emphasizedAction: "Continue",
				onClose: function (sAction) {
					if (sAction == "Continue") {
						debugger;
						//deep chnage : removing segment and fromdate todate from validation
						// this.byId("segment").getValue() == "" ||
						//this.byId("fromDate").getValue() == "" || this.byId("toDate").getValue() == "" || this.byId("stan_hier").getValue() == "" ||
						if (data.status == "02" && data.rtype == "CR" && (this.byId("lob").getValue() == "" || this.byId("conarea").getValue() == "" || this.getView().byId("req_ownpc").getSelectedItem() == null ||
								this.byId("req_defpc").getSelectedItem() == null || this.byId("ktext").getValue() == "" || this.byId("ltext").getValue() ==
								"" || this.byId("comp_code2").getTokens() == "" || this.byId("bri").getValue() ==
								"")) {
							if (this.byId("lob").getValue() == "") {
								this.byId("lob").setValueState("Error");
								this.byId("lob").setValueStateText("(Required)");
							} else {
								this.byId("lob").setValueState("None");
								this.byId("lob").setValueStateText("");
							}
							if (this.byId("conarea").getValue() == "") {
								this.byId("conarea").setValueState("Error");
								this.byId("conarea").setValueStateText("(Required)");
							} else {
								this.byId("conarea").setValueState("None");
								this.byId("conarea").setValueStateText("");
							}
							if (this.byId("ktext").getValue() == "") {
								this.byId("ktext").setValueState("Error");
								this.byId("ktext").setValueStateText("(Required)");
							} else {
								this.byId("ktext").setValueState("None");
								this.byId("ktext").setValueStateText("");
							}
							if (this.byId("ltext").getValue() == "") {
								this.byId("ltext").setValueState("Error");
								this.byId("ltext").setValueStateText("(Required)");
							} else {
								this.byId("ltext").setValueState("None");
								this.byId("ltext").setValueStateText("");
							}
							//deep change start
							// if (this.byId("stan_hier").getValue() == "") {
							// 	this.byId("stan_hier").setValueState("Error");
							// 	this.byId("stan_hier").setValueStateText("(Required)");
							// } else {
							// 	this.byId("stan_hier").setValueState("None");
							// 	this.byId("stan_hier").setValueStateText("");
							// }
							//deep change : stop
							//deep change : commented : start
							// if (this.byId("segment").getValue() == "") {
							// 	this.byId("segment").setValueState("Error");
							// 	this.byId("segment").setValueStateText("(Required)");
							// } else {
							// 	this.byId("segment").setValueState("None");
							// 	this.byId("segment").setValueStateText("");
							// }
							// if (this.byId("fromDate").getValue() == "") {
							// 	this.byId("fromDate").setValueState("Error");
							// 	this.byId("fromDate").setValueStateText("(Required)");
							// } else {
							// 	this.byId("fromDate").setValueState("None");
							// 	this.byId("fromDate").setValueStateText("");
							// }
							// if (this.byId("toDate").getValue() == "") {
							// 	this.byId("toDate").setValueState("Error");
							// 	this.byId("toDate").setValueStateText("(Required)");
							// } else {
							// 	this.byId("toDate").setValueState("None");
							// 	this.byId("toDate").setValueStateText("");
							// }
							// deep change : end
							if (this.byId("bri").getValue() == "") {
								this.byId("bri").setValueState("Error");
								this.byId("bri").setValueStateText("(Required)");
							} else {
								this.byId("bri").setValueState("None");
								this.byId("bri").setValueStateText("");
							}
							if (this.getView().byId("req_ownpc").getSelectedItem() == "") {
								this.getView().byId("req_ownpc").setValueState("Error");
								this.byId("req_ownpc").setValueStateText("(Required)");
							} else {
								this.getView().byId("req_ownpc").setValueState("None");
								this.byId("req_ownpc").setValueStateText("");
							}
							if (this.getView().byId("req_defpc").getSelectedItem() == "") {
								this.getView().byId("req_defpc").setValueState("Error");
								this.byId("req_defpc").setValueStateText("(Required)");
							} else {
								this.getView().byId("req_defpc").setValueState("None");
								this.byId("req_defpc").setValueStateText("");
							}
							if (this.byId("comp_code2").getTokens() == "") {
								this.getView().byId("comp_code2").setValueState("Error");
								this.byId("comp_code2").setValueStateText("(Required)");
							} else {
								this.byId("comp_code2").setValueState("None");
								this.byId("comp_code2").setValueStateText("");
							}
							MessageBox.show(
								"Please Enter All The Mandatory Fields",
								MessageBox.Icon.ERROR,
								"Error"
							);
						} else if (data.status == "02" && data.rtype == "ED" && (this.byId("bri").getValue() === "" || this.byId("ref_pc").getValue() ===
								"")) {
							MessageBox.show(
								"Please Enter All The Mandatory Fields",
								MessageBox.Icon.ERROR,
								"Error"
							);
							//deep change
							//this.byId("cfromDate").getValue() == "" && this.byId("csegment").getValue() == "" && 
							//this.byId("ctoDate").getValue() == "" && 
							//&& this.byId("cstan_hier").getValue() == ""
						} else if (data.status == "02" && data.rtype == "ED" && this.byId("cltext").getValue() == "" && this.byId("cktext").getValue() == "" && this.byId(
								"ccomp_code2").getTokens() == "" && this.getView().byId("pc_lock").getSelectedKey() ==
							"") {
							MessageBox.show(
								"All fields in Profit Center Changes can not be empty.",
								MessageBox.Icon.ERROR,
								"Error"
							);
						} else if (data.rtype == "ED" && ((this.byId("cfromDate").getValue() == data.datab && this.byId(
									"ctoDate").getValue() == data.datbi) || this.byId("csegment").getValue() == data.segment ||
								this.byId("cltext").getValue() == data.ltext || this.byId("cktext").getValue() == data.ktext || this.byId(
									"cstan_hier").getValue() == data.khinr)) {
							MessageBox.show(
								"New value and old value for the Profit Center Changes are same. Kindly enter the correct values.",
								MessageBox.Icon.ERROR,
								"Error"
							);
							//deep change : added segment and date value
						} else if (this.byId("created_pc").getValue() == "" && data.status == "07" && this.byId("cfromDate").getValue() == "" && this
							.byId("csegment").getValue() == "" && this.byId("ctoDate").getValue() == "") {
							//deep change
							if (this.byId("cfromDate").getValue() == "") {
								this.byId("cfromDate").setValueState("Error");
								this.byId("cfromDate").setValueStateText("(Required)");
							} else {
								this.byId("cfromDate").setValueState("None");
								this.byId("cfromDate").setValueStateText("");
							}
							if (this.byId("csegment").getValue() == "") {
								this.byId("csegment").setValueState("Error");
								this.byId("csegment").setValueStateText("(Required)");
							} else {
								this.byId("csegment").setValueState("None");
								this.byId("csegment").setValueStateText("");
							}
							if (this.byId("ctoDate").getValue() == "") {
								this.byId("ctoDate").setValueState("Error");
								this.byId("ctoDate").setValueStateText("(Required)");
							} else {
								this.byId("ctoDate").setValueState("None");
								this.byId("ctoDate").setValueStateText("");
							}
							//deep change end
							MessageBox.show(
								"Please Enter All The Mandatory Fields",
								MessageBox.Icon.ERROR,
								"Error"
							);
						}
						//Validation check when request type is change and date fields are the change dates 
						else if (data.rtype === "ED" && data.datab_c > data.datbi_c) {
							MessageBox.show(
								"Validity To Date Should be greater than Validity From Date",
								MessageBox.Icon.ERROR,
								"Error"
							);
						}
						//Validation check when request type is create and date fields are the change dates 
						else if (data.rtype === "CR" && fromDate > toDate) {
							MessageBox.show(
								"Validity To Date Should be greater than Validity From Date",
								MessageBox.Icon.ERROR,
								"Error"
							);

						}
						//After all validations check are passesd this is implemented
						else {

							var approverDataModel = this._component.getModel("approverModel").getData();

							//for saving comments
							var commentModel = this._component.getModel("commentModel").getData();
							data.commentsSet = [];

							for (var k = 0; k < commentModel.length; k++) {
								var D = {};
								D.Mdmnr = this.form_number;
								D.Comments = commentModel[k].Comments;
								D.CreatorId = commentModel[k].CreatorId;
								D.CreatorName = commentModel[k].CreatorName;
								D.CommentNo = commentModel[k].CommentNo;
								D.CommentDate = "";
								D.CommentTime = "";
								data.commentsSet[k] = D;
							}

							//for saving the multiple company codes
							data.COMPANYCODESSET = [];
							if (data.rtype != "ED") {
								for (var j = 0; j < this.getView().byId("comp_code2").getTokens().length; j++) {
									var E = {};
									E.bukrs = this.getView().byId("comp_code2").getTokens()[j].getText();
									E.mdmnr = this.form_number;
									data.COMPANYCODESSET[j] = E;
								}
							} else {
								for (var j = 0; j < this.getView().byId("ccomp_code2").getTokens().length; j++) {
									var E = {};
									E.bukrs_c = this.getView().byId("ccomp_code2").getTokens()[j].getText();
									E.mdmnr = this.form_number;
									data.COMPANYCODESSET[j] = E;
								}
							}
							//for saving the multiple approver 
							data.APPROVERSET = [];

							for (var i = 0; i < approverDataModel.length; i++) {
								var D = {};
								D.MDMNR = this.form_number;
								D.APPR_ID = approverDataModel[i].APPR_ID;
								D.APPREMAIL = "";
								D.APPRCONTACT = "";
								D.APPRDIV = "";
								D.REVIEWER_TYPE = approverDataModel[i].REVIEWER_TYPE;
								D.SEQUENCE = String(i + 1);
								D.ACTION = approverDataModel[i].ACTION;
								D.ACTION_DATE = approverDataModel[i].ACTION_DATE;
								D.ACTION_TIME = approverDataModel[i].ACTION_TIME;
								D.ACTION_BY = approverDataModel[i].ACTION_BY;
								D.GRP = "";
								D.ACT_NAME = approverDataModel[i].ACT_NAME;
								D.APPRNAME = approverDataModel[i].APPRNAME;
								data.APPROVERSET[i] = D;
							}

							//set FTYPE
							data.ftype = "PC";
							//now addedd in _objectmatched function:start
							// data.rtype = "CR";
							//now addedd in _objectmatched function:end
							data.mdmnr = this.form_number;
							/*var dateRange = approverDataModel.VALIDITY_RANGE;
							var fromDate = dateRange.split("-")[0].trim();
							var toDate = dateRange.split("-")[1].trim();
							data.DATBI = toDate;
							data.DATAB = fromDate;*/
							//Enabling fields visibility
							var EnableModel = new JSONModel();
							this.getOwnerComponent().setModel(EnableModel, "EnableModel");
							EnableModel.setProperty("/allow", false);
							EnableModel.setProperty("/allow_edit", false);
							EnableModel.setProperty("/allow_mdma", false);
							EnableModel.setProperty("/allowvis", true);
							EnableModel.setProperty("/allowvis_save", false);
							EnableModel.setProperty("/allowvis_sub", false);
							EnableModel.setProperty("/allowvis_appr", false);
							EnableModel.setProperty("/allow_val_seg", false);

							//sending the values to backend
							var oModel = this.getOwnerComponent().getModel();
							var that = this;
							//sending data to backend
							// data.status = event.getSource().getId().slice(13, 15);
							oModel.create("/MDMAFormsSet", data, {
								async: false,
								success: function (response) {
									that.form_number = response.mdmnr;
									if (buttonText === "Save") {
										if (data.rtype == "CR") {
											that.getView().byId("pageId").setTitle('Create Profit Center - ' + that.form_number);
											that.basicAllow(true, false);
											//deep change
											EnableModel.setProperty("/allow_val_seg", true);
											//deep change end
											that.getProfitCenterData(that.form_number, data.status);
										} else {
											EnableModel.setProperty("/edit", false);
											that.getView().byId("pageId").setTitle('Change Profit Center - ' + that.form_number);
											that.basicAllow(true, false);
											//deep change
											EnableModel.setProperty("/allow_val_seg", true);
											//deep change end

											EnableModel.setProperty("/allow_edit", false);
											// that._component.getModel("EditProfitModel").setData(data);
										}

										MessageBox.show(
											"Profit Center request " + response.mdmnr + "  saved successfully.Kindly submit form for sending it to MDMA",
											MessageBox.Icon.SUCCESS,
											"Success"
										);

									} else if (buttonText === "Complete") {
										if (data.rtype == "CR") {
											that.getView().byId("pageId").setTitle('Create Profit Center - ' + that.form_number);
										} else {
											that.getView().byId("pageId").setTitle('Change Profit Center - ' + that.form_number);
										}
										that.basicAllow(false, false);
										EnableModel.setProperty("/allow_edit", false);
										// this.Router.navTo("SearchPc", {
										// 	from: "profitCenter"
										// }, false);
										MessageBox.show(
											"Profit Center request " + response.mdmnr + " Completed successfully", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchPc", true);
												}
											}
										);

									} else {
										if (data.rtype == "CR") {
											that.getView().byId("pageId").setTitle('Create Profit Center - ' + that.form_number);
											that.getProfitCenterData(that.form_number);
										} else {
											that.getView().byId("pageId").setTitle('Change Profit Center - ' + that.form_number);
										}
										that.basicAllow(false, false);
										// this.getView().byId("summary").setVisible(false);
										MessageBox.show(
											"Profit Center request " + response.mdmnr + " submitted successfully", {
												icon: MessageBox.Icon.SUCCESS,
												title: "Success",
												onClose: function (oAction) {
													that.oRouter.navTo("SearchPc", true);
												}
											}
										);

									}
									that.getView().byId("form_status").setSelectedKey(data.status);
								},
								error: function (error) {
									var response = JSON.parse(error.responseText);
									MessageBox.show(
										response.error.message.value,
										MessageBox.Icon.ERROR,
										"Error"
									);
								}

							});
						}
					} else {

					}
				}.bind(this)
			});

		},

		onPressActionBtn: function (event) {
			MessageBox.warning("Please verify Segment and Standard Hierarchy field.", {
				actions: ["Continue", "Verify"],
				emphasizedAction: "Continue",
				onClose: function (sAction) {
					if (sAction == "Continue") {
						var msg_returned = "";

						var sValue = jQuery.sap.getUriParameters().get("SOURCE");

						var msg_returned = "";
						var url = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/";
						var oModelData = new sap.ui.model.odata.ODataModel(url, true);
						// var eform_num = e_form_num;
						var relPath = "/eFormValidateApprovalSet?$filter=EFORM_NUM eq '" + this.mdmnr_appr + "' and ACTION eq 'A'";
						var that = this;
						oModelData.read(relPath, null, [], false, function (oData, response) {

							var msg_type = response.data.results[0].MSG_TYPE;
							if (msg_type == "E") {
								// MessageBox.error(response.data.results[0].MSG);
								msg_returned = response.data.results[0].MSG + ".";
							} else {
								msg_returned = "The eForm has been successfully approved.";
							}
							new Promise(function (fnResolve) {
								sap.m.MessageBox.confirm(msg_returned, {
									title: "Confirm Navigation",
									actions: ["OK"],
									onClose: function (sActionClicked) {
										if (sActionClicked === "OK") {

											that.oRouter.navTo("SearchPc", true);
											// }
										}
									}
								});
							});

							// if (sActionClicked === "No") {
							// 	if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
							// 		  window.history.go(-1);
							// 		// window.close();
							// 		// window.open("https://sharepoint.spe.sony.com/myspe/", "_self");
							// 	} else {
							// 		window.history.go(-1);
							// 	}
							// }
							// 		}
							// 	});
							// }).catch(function (err) {
							// 	if (err !== undefined) {
							// 		MessageBox.error(err);
							// 	}
							// });
							// });

						});
					}
					else
					{
						
					}
				}.bind(this)
			});

		},

		onPressActionBtns: function (event) {
			var msg_returned = "";

			var sValue = jQuery.sap.getUriParameters().get("SOURCE");

			var msg_returned = "";
			var url = "/sap/opu/odata/sap/YFPSFIFRDD0033_MDM_FORM_SRV/";
			var oModelData = new sap.ui.model.odata.ODataModel(url, true);
			// var eform_num = e_form_num;
			var relPath = "/eFormValidateApprovalSet?$filter=EFORM_NUM eq '" + this.mdmnr_appr + "' and ACTION eq 'R'";
			var that = this;
			oModelData.read(relPath, null, [], false, function (oData, response) {

				var msg_type = response.data.results[0].MSG_TYPE;
				if (msg_type == "E") {
					// MessageBox.error(response.data.results[0].MSG);
					msg_returned = response.data.results[0].MSG + ".";
				} else {
					msg_returned = "The eForm has been Rejected.";
				}
				new Promise(function (fnResolve) {
					sap.m.MessageBox.confirm(msg_returned, {
						title: "Confirm Navigation",
						actions: ["OK"],
						onClose: function (sActionClicked) {
							if (sActionClicked === "OK") {

								that.oRouter.navTo("SearchPc", true);	
								// }
							}
						}
					});
				});

				// if (sActionClicked === "No") {
				// 	if (window.top.location.href.toLowerCase().indexOf("fiorilaunchpad") == -1) {
				// 		  window.history.go(-1);
				// 		// window.close();
				// 		// window.open("https://sharepoint.spe.sony.com/myspe/", "_self");
				// 	} else {
				// 		window.history.go(-1);
				// 	}
				// }
				// 		}
				// 	});
				// }).catch(function (err) {
				// 	if (err !== undefined) {
				// 		MessageBox.error(err);
				// 	}
				// });
				// });

			});
		},
	});

});