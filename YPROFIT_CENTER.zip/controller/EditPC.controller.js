sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.spe.YPROFCENTER_REQFORM.controller.EditPC", {

		onInit: function () {

		},
	
		onPress: function (oEvent) {
			// var oButton = oEvent.getSource();
			var oButton=this.getView().byId("help");
			var oPopover = new sap.m.Popover({
				title: "Help",
				width: "200px",
				content: [
					new sap.m.HBox({
						items: new sap.m.Text({
							text: "Help instructions are provided"
						}),
						width: "200px"
					}).addStyleClass("sapUiSmallMargin"),
					new sap.m.HBox({
						class: "sapUiSmallMargin",
						items: new sap.m.Text({
							text: "Help instructions are provided"
						}),
						width: "200px"
					}).addStyleClass("sapUiSmallMargin")
				]

				// 	// footer: [new sap.m.Button({
				// 	// text: "Click me!"
				// })]
			});
			oPopover.openBy(oButton);
             oButton.addEventDelegate({
				onmouseover: function(){
				oPopover.openBy(oButton);	
				},
				onmouseout: function(){
				oPopover.close(oButton);
               }
			}, this);
			// var oButton = oEvent.getSource();

			// if (!this._oPopover) {
			// 	Fragment.load({
			// 		name: "com.spe.YPROFCENTER_REQFORM.Fragments.help_Popover",
			// 		controller: this
			// 	}).then(function (pPopover) {
			// 		this._oPopover = pPopover;
			// 		this.getView().addDependent(this._oPopover);

			// 		this._oPopover.openBy(oButton);
			// 	}.bind(this));
			// } else {
			// 	this._oPopover.openBy(oButton);
			// }

		},
		onPressDetail:function(){
		 this.getView().byId("busInfoReq").setExpanded(true);
		 this.getView().byId("Appr").setExpanded(true);
		 this.getView().byId("ena").setExpanded(true);
		},
		
		onHelp:function(){
			
			var cltstrng = "width=500px,height=600px";
			var wind = window.open("", cltstrng);
			wind.document.write("Help Document");
		},
			onAppovalChange: function () {
			var req = this.getView().byId("appr_req").getSelectedItem().getKey();
			if (req === "No") {
				this.getView().byId("approver").setVisible(false);
			} else if (req === "Yes") {
				this.getView().byId("approver").setVisible(true);
			}
			this.getView().byId("approver").setVisible("true");
		},
		onAddApprovers: function () {
			var table = this.getView().byId("tblApprover");
			var oTemplate = new sap.m.ColumnListItem({
				cells: [
					new sap.m.Input({
						showValueHelp: true,
						value: "{CreateProfitModel>/name}"
					}),
					new sap.m.Input({
						enabled: true,
						value: "{CreateProfitModel>/appr_email}",
						showValueHelp: true,
						valueHelpRequest: [this.onHandleSapProjectValueHelp, this]

					}),
					new sap.m.Input({

						value: ""
					}),
					new sap.m.Input({

						value: ""
					})
				]
			});
			table.addItem(oTemplate);
		},
		deleteAapprover: function () {
			var table = this.getView().byId("tblApprover");
			var selected_item = this.getView().byId("tblApprover").getSelectedItem();
			table.removeItem(selected_item);
		},
		conAreaValueHelpRequest: function (oevent) {
			debugger;
			var id = oevent.getSource().getId().split("-")[2];
			var that=this;
		   var titleFilter;
			var descriptionFilter;
				if (id === "pcnum") {
				this.url = "/FacFhPrctrShlpSet";
				this.mtitle = "Reference Profit Center";
				this.title = "{Prctr}";
				this.descriptions = "{Ktext}";
				titleFilter = "Prctr";
				descriptionFilter = "Ktext";
				// var desc="Ktext"
			}
			var Con_Area = oevent.getSource();
			var oValueHelpDialog_RespDiv = new sap.m.SelectDialog({
				title: this.mtitle,
				items: {
					path: this.url,
					template: new sap.m.StandardListItem({
						title: this.title,
						description: this.descriptions,
						active: true,
						mode: "MultiSelect"
					})
				},
				//Shipping Point can be searched using Search Bar
				search: function (oEvent) {
					var sValue = oEvent.getParameter("value");
					var oFilter = new sap.ui.model.Filter(
						"AccNum",
						sap.ui.model.FilterOperator.Contains, sValue
					);
					oEvent.getSource().getBinding("items").filter(oFilter);
				},

				confirm: function (oEvent) {

					var oSelectedItem = oEvent.getParameter("selectedItem");
					if (oSelectedItem) {
					Con_Area.setValue(oSelectedItem.getTitle());
					Con_Area.data("key", oSelectedItem.getDescription());
					}
					if (id == "pcnum") {
                           	
							model.read("/YFPSFI0033_GET_REF_PRCTR('" + oSelectedItem.getTitle() + "')", {
								success: function (odata, response) {
									// debugger;
									that.getView().byId("conarea").setValue(odata.kokrs);
									that.getView().byId("dept").setValue(odata.abtei);
									that.getView().byId("userRespon").setValue(odata.verak_user);
									that.getView().byId("userRespon_txt").setText(odata.name_text);
									that.getView().byId("perRespon").setValue(odata.verak);
									that.getView().byId("segment").setValue(odata.segment);
									that.getView().byId("stan_hier").setValue(odata.khinr);
								},

							});
						}
				}

			});

			var model = this.getOwnerComponent().getModel();
			oValueHelpDialog_RespDiv.setModel(model);
			oValueHelpDialog_RespDiv.open();
			
		},
	
	});

});