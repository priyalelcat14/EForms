sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.spe.YPROFCENTER_REQFORM.controller.SideNavBar", {

		onInit: function () {
           this.Router = sap.ui.core.UIComponent.getRouterFor(this);
		},
			onItemSelect: function (oEvent) {
			var oItem = oEvent.getParameter("item");
			this.byId("pageContainer").to(this.getView().createId(oItem.getKey()));
			
		},
        onPressPcard: function (oEvent) {
			var sAction = oEvent.getSource().getProperty("text");
			switch (sAction) {

			case "Create new Profit Center":

				this.Router.navTo("CreatePC", {
					from: "SideNavBar"
				}, false);
				break;
			case "Home":

				this.Router.navTo("Home", {
					from: "SideNavBar"
				}, false);
				break;
				case "Change Profit Center":

				this.Router.navTo("EditPC", {
					from: "profitCenter"
				}, false);
				break;
				
				// case "Extend/Unextend Company code to Profit Center":

				// this.Router.navTo("ExtendPC", {
				// 	from: "profitCenter"
				// }, false);
				// break;
				// case "Lock/Unlock Profit Center":

				// this.Router.navTo("LockPc", {
				// 	from: "profitCenter"
				// }, false);
				// break;
				case "Search Profit Center Request Form":

				this.Router.navTo("SearchPc", {
					from: "SearchPc"
				}, false);
				break;
			

			}
		},
			onSideNavButtonPress: function () {
			var oToolPage = this.byId("toolPage");
			var bSideExpanded = oToolPage.getSideExpanded();

			this._setToggleButtonTooltip(bSideExpanded);

			oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
		},
		
		_setToggleButtonTooltip: function (bLarge) {
			var oToggleButton = this.byId('sideNavigationToggleButton');
			if (bLarge) {
				oToggleButton.setTooltip('Large Size Navigation');
			} else {
				oToggleButton.setTooltip('Small Size Navigation');
			}
		}
		
	});

	});

