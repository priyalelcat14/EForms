sap.ui.define([
	"com/spe/YPROFCENTER_REQFORM/test/unit/controller/Home.controller"
], function () {
	"use strict";
});